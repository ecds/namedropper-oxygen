/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.contentcompletion.xml;

import ro.sync.annotations.obfuscate.SkipObfuscate;
import ro.sync.annotations.obfuscate.SkipLevel;
import java.util.List;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.Extension;

/**
 * Interface for objects used to filter the editor content completion 
 * schema manager proposals. This should be implemented if the
 * list of content completion proposals must be filtered based on some criteria or 
 * some new entries need to be added.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
@SkipObfuscate(classes = SkipLevel.NOT_SPECIFIED, fields = SkipLevel.NOT_SPECIFIED, methods = SkipLevel.PUBLIC)
public interface SchemaManagerFilter extends Extension {
  /**
   * Filters the elements proposed by the editor content completion schema manager.
   * The original list of elements is obtained by examining the current document
   * schema and determining what possible elements can be inserted in the
   * current context.
   * For example if <code>person</code> is the current <code>CIElement</code>,
   * and the list of children contains the elements <code>name</code>
   * and <code>address</code>, the result of choosing
   * the <b>person</b> entry from the content completion window
   * will be the insertion of the following sequence:
   * <code>
   * <pre>
   * &lt;person>
   *     &lt;name>...&lt;/name>
   *     &lt;address>...&lt;/address>
   * &lt;/person>
   * </pre>
   * </code>
   * Given this example, the original <code>name</code> CIElement can be replaced
   * by a new one which returns a list with two new CIElements, <code>firstName</code> and
   * <code>lastName</code>, on the {@link CIElement#getGuessElements()} method call. 
   * The new generated sequence would be:
   * <code>
   * <pre>
   * &lt;person>
   *     &lt;name>
   *         &lt;firstName>...&lt;/firstName>
   *         &lt;lastName>...&lt;/lastName>
   *     &lt;/name>
   *     &lt;address>...&lt;/address>
   * &lt;/person>
   * </pre>
   * </code>
   *
   * @param elements The list of elements ({@link CIElement}) to be filtered.
   * @param context The {@link WhatElementsCanGoHereContext} where the list of 
   * elements is requested.
   * If <code>null</code> then the given list of content completion elements contains
   * global elements.
   * @return The filtered list of {@link CIElement} or <code>null</code> if all elements
   * are rejected by the filter.
   */
  List<CIElement> filterElements(List<CIElement> elements, WhatElementsCanGoHereContext context);
  
  /**
   * Filters the attributes proposed by the editor content completion schema manager.
   * The original list of attributes is obtained by examining the current document
   * schema and determining what attributes can be inserted in the current element
   * and taking into account the list of existing attributes.
   *
   * @param attributes The list of attributes ({@link CIAttribute}) to be filtered. Can be NULL
   * @param context The {@link WhatAttributesCanGoHereContext} where the list of
   * attributes is requested.
   * @return The filtered list of {@link CIAttribute} or <code>null</code> if all attributes
   * are rejected by the filter.
   */
  List<CIAttribute> filterAttributes(List<CIAttribute> attributes, WhatAttributesCanGoHereContext context);
  
  /**
   * Filters the attribute values proposed by the editor content completion schema manager.
   * The original list of attribute values is obtained by examining the current 
   * document schema and determining what values are permitted for the current attribute.
   * If the attribute type was an enumeration, then a list with the tokens of the
   * enumeration will be returned for that attribute.
   *
   * @param attributeValues The list of attribute values ({@link CIValue}) to be filtered.  
   * @param context The {@link WhatPossibleValuesHasAttributeContext} where the 
   * list of attribute values is requested.
   * @return The filtered list of {@link CIValue} representing possible values of 
   * the attribute or <code>null</code> if all values are rejected by the filter.
   */
  List<CIValue> filterAttributeValues(List<CIValue> attributeValues, WhatPossibleValuesHasAttributeContext context);

  /**
   * Filters the element values proposed by the editor content completion schema manager.
   * The original list of element values is obtained by examining the current 
   * document schema and determining what values are permitted for the current element.
   * If the element type was an enumeration, then a list with the values of the
   * enumeration will be returned for that element.
   * 
   * @param elementValues The list of element values ({@link CIValue}) to be filtered. 
   * @param context The {@link Context} where the list of element values is requested.
   * @return The filtered list of {@link CIValue} representing the possible values
   * of the element or <code>null</code> if all values are rejected by the filter.
   */
  List<CIValue> filterElementValues(List<CIValue> elementValues, Context context);
}