/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.node.AuthorDocument;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Event received by an {@link AuthorListener} when changes have been made 
 * in the content of the {@link AuthorDocument}.
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface DocumentContentChangedEvent extends AuthorDocumentEvent {
  /**
   * Insert simple text event type.
   */
  int INSERT_TEXT_EVENT = 131;
  
  /**
   * Insert node event type.
   */
  int INSERT_NODE_EVENT = 132;
  
  /**
   * Insert fragment event type.
   */
  int INSERT_FRAGMENT_EVENT = 133;
  
  /**
   * Delete simple text event type.
   */
  int DELETE_TEXT_EVENT = 141;
  
  /**
   * Delete fragment event type.
   */
  int DELETE_FRAGMENT_EVENT = 142;
  
  /**
   * Returns the length of the change.
   * 
   * @return the length of the change. Zero in case of an attribute change.
   */
  int getLength();

  /**
   * Returns the start offset at which the change occurred.
   * 
   * @return the offset at which the change occurred. 
   * 0 in case of an attribute change.
   */
  int getOffset();
  
  /**
   * Returns the {@link AuthorNode} containing the change.
   * 
   * @return The node containing the change.
   */
  AuthorNode getParentNode();

  /**
   * Needed to verify if the change was a simple text edit and no node structure was affected. 
   * 
   * @return <code>true</code> if the edit was a simple text edit, no node structure was affected.
   * @deprecated Use {@link #getType()} to determine the type of edit.
   */
  @Deprecated
  boolean isSimpleTextEdit();
  
  /**
   * Returns the type of this event. 
   * It can be one of the constants:
   * {@link #INSERT_TEXT_EVENT}, {@link #INSERT_FRAGMENT_EVENT}, {@link #INSERT_NODE_EVENT}
   * {@link #DELETE_TEXT_EVENT}, {@link #DELETE_FRAGMENT_EVENT}
   * 
   * @return The document changed event type.
   */
  int getType();
}