/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.table.operations;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorOperationException;
import ro.sync.ecss.extensions.api.AuthorSelectionModel;
import ro.sync.ecss.extensions.api.SelectionInterpretationMode;
import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * Handler for Author table operations.
 * It should be implemented when the author extension being developed offers
 * support for editing data in tabular form. 
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions,
 * comments about it, please let us know.</p>
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class AuthorTableOperationsHandler {
  
  /**
   * Handles insert column operation.
   * <br/>
   * This method is called when pasting or dropping content for which the 
   * {@link SelectionInterpretationMode#TABLE_COLUMN} interpretation mode was imposed.
   * <br/>
   * <br/>
   * The {@link SelectionInterpretationMode#TABLE_COLUMN} interpretation mode is 
   * already set by default by the application when a table column is selected.
   * It can be also imposed from the {@link AuthorSelectionModel#setSelectionInterpretationMode(SelectionInterpretationMode)}
   * method, for any selection content.
   * <br/>
   * For instance, when two paragraphs are copied, the clipboard object contains 
   * a list with two Author document fragments (one for each paragraph).
   * If the selection interpretation mode is imposed to {@link SelectionInterpretationMode#TABLE_COLUMN},
   * when pasting the fragments this method is called. The fragments array are included in the 
   * argument object.
   * 
   * @param arguments The arguments for insert column operation like: 
   * the offset where the column is inserted, the array containing the cells fragments
   * that compose an Author table column, information about column width specification, 
   * the Author access.
   * 
   * @return <code>true</code> if the insert column operation succeeds.
   * 
   * @throws AuthorOperationException An insert column operation exception.
   * If the {@link AuthorOperationException#isOperationRejectedOnPurpose()} method 
   * of this exception returns true, the exception is presented to the user.   
   */
  public boolean handleInsertColumn(AuthorTableInsertColumnArguments arguments) throws AuthorOperationException {
    return false;
  }
  
  /**
   * Handles delete column operation.
   * <br/>
   * This method is called when deleting content  (by drag and drop or cut operations)  
   * for which the {@link SelectionInterpretationMode#TABLE_COLUMN} interpretation mode was imposed.
   * <br/>
   * <br/>
   * The {@link SelectionInterpretationMode#TABLE_COLUMN} interpretation mode is 
   * already set by default by the application when a table column is selected.
   * It can be also imposed from the {@link AuthorSelectionModel#setSelectionInterpretationMode(SelectionInterpretationMode)}
   * method, for any selection content.
   * <br/>
   * For instance, when two paragraphs are copied, the clipboard object contains 
   * a list with two Author document fragments (one for each paragraph).
   * If the selection interpretation mode is imposed to {@link SelectionInterpretationMode#TABLE_COLUMN},
   * when deleting the fragments this method is called. The fragments array are included in the 
   * argument object.
   * 
   * @param arguments  The arguments for delete column operation (like the Author access
   * and the column cells start and end offsets). 
   * @return <code>true</code> if the delete column operation succeeds.
   * 
   * @throws AuthorOperationException A delete column operation exception.
   * If the {@link AuthorOperationException#isOperationRejectedOnPurpose()} method 
   * of this exception returns true, the exception is presented to the user.   
   */
  public boolean handleDeleteColumn(AuthorTableDeleteColumnArguments arguments) throws AuthorOperationException {
    return false;
  }

  /**
   * Handles delete row operation.
   * <br/>
   * This method is called when deleting content (by drag and drop or cut operations) 
   * for which the {@link SelectionInterpretationMode#TABLE_ROW} interpretation mode was imposed.
   * <br/>
   * <br/>
   * The {@link SelectionInterpretationMode#TABLE_ROW} interpretation mode is 
   * already set by default by the application when a table row is selected.
   * It can be also imposed from the {@link AuthorSelectionModel#setSelectionInterpretationMode(SelectionInterpretationMode)}
   * method, for any selection content.
   * <br/>
   * For instance, when two paragraphs are copied, the clipboard object contains 
   * a list with two Author document fragments (one for each paragraph).
   * If the selection interpretation mode is imposed to {@link SelectionInterpretationMode#TABLE_ROW},
   * when deleting the fragments this method is called. The fragments array are included in the 
   * argument object.
   * 
   * @param arguments  The arguments for delete row operation (like the Author access and 
   * the content interval of the row element that must be deleted). 
   * @return <code>true</code> if the delete row operation succeeds.
   * 
   * @throws AuthorOperationException A delete row operation exception.
   * If the {@link AuthorOperationException#isOperationRejectedOnPurpose()} method 
   * of this exception returns true, the exception is presented to the user.   
   */
  public boolean handleDeleteRow(AuthorTableDeleteRowArguments arguments) throws AuthorOperationException {
    return false;
  }

  /**
   * Returns the element representing the table that contains the given offset.
   * This method can be used to obtain the closest table that contains the given 
   * offset.
   *  
   * @param access Access to Author operations. 
   * @param offset The offset to search the parent table element for.
   * @return The table node that contains the given offset.
   */
  public AuthorElement getTableElementContainingOffset(AuthorAccess access, int offset) {
    return null;
  }
  
  /**
   * Returns the column specification information of a table column.
   * <br/> 
   * This information is requested when a column is copied or dragged and 
   * it can be used when the column must be inserted in the document (on paste or
   * drop). The column specification is send as an argument to the 
   * {@link #handleInsertColumn(AuthorTableInsertColumnArguments)} method.
   * 
   *  
   * @param access Access to Author operations. 
   * @param tableElement The table that contains the column. 
   * @param columnIndex The column index, <code>0</code> based.
   * @return The column specification element. It can be <code>null</code> if 
   * there is no specification for this column.
   */
  public TableColumnSpecificationInformation getColumnSpecification(AuthorAccess access, 
      AuthorElement tableElement, int columnIndex) {
    return null;
  }
}
