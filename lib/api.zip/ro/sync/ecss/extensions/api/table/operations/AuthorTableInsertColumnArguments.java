/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.table.operations;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;

/**
 * Holds the arguments for {@link AuthorTableOperationsHandler#handleInsertColumn(AuthorTableInsertColumnArguments)} 
 * method. 
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions,
 * comments about it, please let us know.</p>
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public class AuthorTableInsertColumnArguments {
  /**
   * The offset where the column is inserted.
   */
  private int insertOffset;
  /**
   * The array containing the cells nodes that compose an Author table column.
   */
  private AuthorDocumentFragment[] columnFragments;
  /**
   * <code>true</code> if the given column fragments represents the cells nodes 
   * or only the content of the cells nodes.   
   */
  private boolean fragmentsWrappedInCells;
  /**
   * The Author access. 
   */
  private AuthorAccess authorAccess;
  
  /**
   * Table column specification information that is requested when a column is copied or dragged, from
   * {@link AuthorTableOperationsHandler#getColumnSpecification(AuthorAccess, ro.sync.ecss.extensions.api.node.AuthorElement, int)}
   * method.
   * <br/>
   * It can be <code>null</code> if no information is specified for table column.
   */
  private TableColumnSpecificationInformation columnSpecification;
  
  /**
   * Constructor.
   * 
   * @param insertOffset The offset where the column is inserted.
   * @param columnFragments The array containing the cells nodes that compose an Author table column.
   * @param fragmentsWrappedInCells <code>true</code> if the given column fragments represents the cells nodes 
   * or only the content of the cells nodes.   
   * @param authorAccess The Author access.
   * @param columnSpecification Table column specification information that is requested
   * when a column is copied or dragged, from {@link AuthorTableOperationsHandler#getColumnSpecification(AuthorAccess, ro.sync.ecss.extensions.api.node.AuthorElement, int)}
   * method. It can be <code>null</code> if no information is specified for table column.
   */
  public AuthorTableInsertColumnArguments(int insertOffset, AuthorDocumentFragment[] columnFragments, 
      boolean fragmentsWrappedInCells,  AuthorAccess authorAccess, TableColumnSpecificationInformation columnSpecification) {
    this.insertOffset = insertOffset;
    this.columnFragments = columnFragments;
    this.fragmentsWrappedInCells = fragmentsWrappedInCells;
    this.authorAccess = authorAccess;
    this.columnSpecification = columnSpecification;
  }
  

  /**
   * @return Returns the access to Author operation.
   */
  public AuthorAccess getAuthorAccess() {
    return authorAccess;
  }
  
  /**
   * @return Returns the array containing the cells nodes that compose an Author table column.
   */
  public AuthorDocumentFragment[] getColumnFragments() {
    return columnFragments;
  }
  
  /**
   * @return Returns the offset where the column is inserted.
   */
  public int getInsertOffset() {
    return insertOffset;
  }
  
  /**
   * @return Returns <code>true</code> if the given column fragments represents the cells nodes 
   * or only the content of the cells nodes.   
   */
  public boolean areFragmentsWrappedInCells() {
    return fragmentsWrappedInCells;
  }
  
  /**
   * Returns the column specification information of a table column. 
   * This information is requested when a column is copied or dragged, from
   * {@link AuthorTableOperationsHandler#getColumnSpecification(AuthorAccess, ro.sync.ecss.extensions.api.node.AuthorElement, int)}
   * method.
   * 
   * @return Returns information about column specification (like column specified width).
   * It can be <code>null</code> if no information is specified for table column.
   */
  public TableColumnSpecificationInformation getColumnSpecificationInformation() {
    return columnSpecification;
  }
}
