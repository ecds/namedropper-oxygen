/**
 * Filter certain attributes from being displayed in certain parts of the Author editor 
 * (the Attributes view, the Attributes editor, the Outline).
 */
package ro.sync.ecss.extensions.api.attributes;