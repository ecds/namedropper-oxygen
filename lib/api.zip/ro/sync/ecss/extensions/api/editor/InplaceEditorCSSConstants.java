/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.editor;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.contentcompletion.xml.CIValue;

/**
 * Arguments of the oxy_editor function as well as built-in values for some of 
 * these arguments.
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface InplaceEditorCSSConstants {
  //////////////////////////////////////
  // CSS 'editor' extension function arguments
  /**
   * Indicates the editor that should be used to edit. One of TYPE_ constants or 
   * a class name. This is a shorthand to specify a built-in type of renderer 
   * and editor as opposed to using properties PROPERTY_RENDERER_CLASS_NAME, 
   * PROPERTY_SWING_EDITOR_CLASS_NAME and PROPERTY_SWT_EDITOR_CLASS_NAME.
   */
  String PROPERTY_TYPE = "type";
  /**
   * Indicates if we should edit an attribute value or the text value of the element.
   * To edit an attribute value the value of the property is "@attr_name".
   * To edit the text content the value should be equal with EDIT_TEXT_CONTENT.
   */
  String PROPERTY_EDIT = "edit";
  /**
   * A set of values to be presented as choices. If not present these values will be 
   * taken from the schema. The processed value for this property is a list of 
   * {@link CIValue}.
   */
  String PROPERTY_VALUES = "values";
  /**
   * Used only when {@link #PROPERTY_TYPE} is set to {@link #TYPE_CHECKBOX}.
   * These are the values that are committed for a checkbox when it is un-checked.
   * If missing, an un-checked button will commit no value.
   *  
   * The processed value for this property is a list of {@link CIValue}.
   */
  String PROPERTY_UNCHECKED_VALUES = "uncheckedValues";
  /**
   * A set of labels to be associated with PROPERTY_VALUES.
   */
  String PROPERTY_LABELS = "labels";
  /**
   * The number of rows that the editor should have. It's interpretation is dependent
   * to the editor being used.
   */
  String PROPERTY_ROWS = "rows";
  /**
   * The number of columns that the editor should have. It's interpretation is dependent
   * to the editor being used.
   */
  String PROPERTY_COLUMNS = "columns";
  /**
   * Used only when {@link #PROPERTY_TYPE} is set to {@link #TYPE_CHECKBOX}.
   * 
   * This is the separator that will be used to compose the values from the
   * check-boxes into one string that will be committed into the document.
   * 
   * If no separator is specified, a space will be used. 
   */
  String PROPERTY_SEPARATOR = "resultSeparator";
  /**
   * Only applies when the editor is a combo box and marks the combo as being 
   * editable or not. possible values are Boolean.TRUE and Boolean.FALSE.
   */
  String PROPERTY_EDITABLE = "editable";
  /**
   * Only applies to the {@link #TYPE_BUTTON} and represents the ID of the action
   * that must be invoked when the button is pressed. It's processed value is 
   * an {@link IAuthorExtensionAction}.
   */
  String PROPERTY_ACTION_ID = "actionID";
  /**
   * Class name of the renderer. This must be a SWING implementation for both 
   * the Oxygen stand alone or Eclipse plugin version.
   */
  String PROPERTY_RENDERER_CLASS_NAME = "rendererClassName";
  /**
   * Class name of the editor. The SWING implementation is used for the Oxygen stand alone.
   */
  String PROPERTY_SWING_EDITOR_CLASS_NAME = "swingEditorClassName";
  /**
   * Class name of the editor. The SWT implementation is used for the Eclipse plugin version.
   */
  String PROPERTY_SWT_EDITOR_CLASS_NAME = "swtEditorClassName";
  //////////////////////////////////////
  
  //////////////////////////////////////
  // Editor type values.
  /**
   * Possible value for PROPERTY_TYPE. Indicates that a combo box should be 
   * used to render and edit.
   */
  String TYPE_BUTTON = "button";
  /**
   * Possible value for PROPERTY_TYPE. Indicates that a combo box should be 
   * used to render and edit.
   */
  String TYPE_COMBOBOX = "combo";
  /**
   * Possible value for PROPERTY_TYPE. Indicates that a text field with 
   * content completion support should be used to render and edit.
   */
  String TYPE_TEXT = "text";
  /**
   * Possible value for PROPERTY_TYPE. Indicates that a check box panel should be 
   * used to render and edit.
   */
  String TYPE_CHECKBOX = "check";
  /////////////////////////////////////
  /**
   * Value of the PROPERTY_EDIT that indicates that the text content of the 
   * element must be edited.
   */
  String EDIT_TEXT_CONTENT = "#text";
  ////////////////////////////////////
  /**
   * Possible value for PROPERTY_EDITABLE that marks the combo as NOT being editable.
   */
  String EDITABLE_FALSE = "false";
  /**
   * Possible value for PROPERTY_EDITABLE that marks the combo as being editable.
   */
  String EDITABLE_TRUE = "true";
}