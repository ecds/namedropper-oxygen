/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.editor;

import java.util.Map;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorSchemaManager;
import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * Context where an edit component will be used. Contains all the information 
 * required to build the editor.
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public class AuthorInplaceContext {
  /**
   * The arguments from the oxy_editor function as well as some others. The keys 
   * are the constants from class {@link InplaceEditorArgumentKeys}.
   */
  private Map<String, Object> arguments;
  /**
   * The element being edited.
   */
  private final AuthorElement elem;
  /**
   * Provides support for obtaining information about what elements, attributes can be inserted 
   * in a given context.
   */
  private AuthorSchemaManager schemaManager;
  /**
   * Provides access to different functions.
   */
  private AuthorAccess authorAccess;
  /**
   * The parent host in which the editor will be added or the renderer will be 
   * painted. If we are in the stand-alone Oxygen version this will be a JPanel.
   * If we are in the Oxygen Eclipse plug-in this will be a Composite.
   * 
   * For SWT, an editor will require the parent in order to create itself.
   */
  private Object parentHost;
  /**
   * An error message encountered while building the context.
   */
  private String errorMessage;
  
  /**
   * The editor context.
   * 
   * @param arguments The editor arguments
   * @param elem The element being edited.
   * @param schemaManager Provides support for obtaining information about what elements, attributes can be inserted 
   * in a given context.
   * @param authorAccess Provides access to different functions.
   * @param parentHost The parent host in which the editor will be added or the renderer will be 
   * painted. If we are in the stand-alone Oxygen version this will be a JPanel.
   * If we are in the Oxygen Eclipse plug-in this will be a Composite. For SWT, 
   * an editor will require the parent in order to create itself.
   */
  public AuthorInplaceContext(
      Map<String, Object> arguments, 
      AuthorElement elem, 
      AuthorSchemaManager schemaManager, 
      AuthorAccess authorAccess,
      Object parentHost) {
    this.arguments = arguments;
    this.elem = elem;
    this.schemaManager = schemaManager;
    this.authorAccess = authorAccess;
    this.parentHost = parentHost;
  }
  
  /**
   * @return The arguments from the oxy_editor function as well as some others. The keys 
   * are the constants from class {@link InplaceEditorArgumentKeys}.
   */
  public Map<String, Object> getArguments() {
    return arguments;
  }
  
  /**
   * @return The attribute being edited as extracted from the oxy_editor arguments. 
   * 
   * <code>null</code> no attribute was specified in which case the text should be edited.
   */
  public String getAttributeToEdit() {
    final String toEdit = (String) arguments.get(InplaceEditorCSSConstants.PROPERTY_EDIT);
    
    return getAttributeToEdit(toEdit);
  }
  
  /**
   * Checks if the property {@link InplaceEditorCSSConstants#PROPERTY_EDIT} specifies 
   * an attribute to be edited.
   * 
   * @param toEdit The value of the property {@link InplaceEditorCSSConstants#PROPERTY_EDIT}
   * 
   * @return The attribute being edited as extracted from the oxy_editor arguments. 
   * <code>null</code> if no attribute name was specified.
   */
  public static String getAttributeToEdit(String toEdit) {
    String attributeToEdit = null;
    if (toEdit != null && toEdit.length() > 0) {
      // The edit property is present.
      if (toEdit.charAt(0) == '@') {
        attributeToEdit = toEdit.substring(1);
      }
    }
    
    return attributeToEdit;
  }
  
  /**
   * @return The element being edited.
   */
  public AuthorElement getElem() {
    return elem;
  }
  
  /**
   * @return Returns the schemaManager.
   */
  public AuthorSchemaManager getSchemaManager() {
    return schemaManager;
  }
  
  /**
   * @return Provides access to different author functions.
   */
  public AuthorAccess getAuthorAccess() {
    return authorAccess;
  }
  
  /**
   * The parent host in which the editor will be added or the renderer will be 
   * painted. If we are in the stand-alone Oxygen version this will be a JPanel.
   * If we are in the Oxygen Eclipse plug-in this will be a Composite.
   * 
   * For SWT, an editor will require the parent in order to create itself.
   * 
   * @return The JPanel or Composite of the author.
   */
  public Object getParentHost() {
    return parentHost;
  }
  
  /**
   * Sets an error message encountered while building the context.
   * 
   * @param errorMessage An error message encountered while building the context.
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }
  
  /**
   * @return An error message encountered while building the context.
   */
  public String getErrorMessage() {
    return errorMessage;
  }
}