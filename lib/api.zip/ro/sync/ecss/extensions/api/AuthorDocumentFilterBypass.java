/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Used as a way to circumvent calling back into the <code>AuthorDocumentController</code> to
 * change the <code>AuthorDocument</code>.
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorDocumentFilterBypass {
  /**
   * Inserts a text at the given offset. After the operation the caret will be 
   * positioned at the end of the inserted text.
   * 
   * @param offset The insert position, 0 based.
   * @param text The text to be inserted.
   */
  void insertText(int offset, String text);
  
  /**
   * Insert an {@link AuthorDocumentFragment} at the given offset.
   * 
   * @param offset The offset where the fragment will be inserted, 0 based.
   * @param frag The {@link AuthorDocumentFragment} to be inserted.
   */
  void insertFragment(int offset, AuthorDocumentFragment frag);
  
  /**
   * Insert the specified node at the given offset.
   * 
   * @param offset The offset where the node will be inserted. 0 based.
   * @param node The {@link AuthorNode} to insert.
   * @return <code>true</code> if the operation was successful.
   */
  boolean insertNode(int offset, AuthorNode node);

  /**
   * Insert multiple elements at the given offsets.
   * <br>
   * Note: <i>The offsets and elements must be in document order.</i>
   * 
   * @param parentElement The parent element that contains all the new inserted 
   * elements. 
   * @param elementNames The element names to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted. 0 based.
   * @param namespace The namespace of the new inserted elements.
   */
  void insertMultipleElements(AuthorElement parentElement, String[] elementNames,
      int[] offsets, String namespace);

  /**
   * Insert multiple fragments at the given offsets.
   * <br>
   * Note: <i>The offsets and fragments must be in document order.</i>
   * 
   * @param parentElement The parent element that contains all the new inserted 
   * elements. 
   * @param fragments The fragments to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted. 0 based.
   * @return <code>true</code> if the operation succeed.
   *  
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>  
   */
  boolean insertMultipleFragments(AuthorElement parentElement,
      AuthorDocumentFragment[] fragments, int[] offsets);
  
  /**
   * Deletes a document fragment between the start and end offset.
   * 
   * @param startOffset Start offset, 0 based and inclusive.
   * @param endOffset End offset, 0 based and inclusive.
   * @param withBackspace <code>true</code> if <code>BACKSPACE</code> key was used when deleting the fragment.
   * @return <code>true</code> if the delete operation was successful.
   */
  boolean delete(int startOffset, int endOffset, boolean withBackspace);
  
  /**
   * Deletes the specified node from the document.
   * 
   * @param node The {@link AuthorNode} to delete.
   * @return <code>true</code> if the delete node operation was successful. 
   */
  boolean deleteNode(AuthorNode node);
  
  /**
   * Deletes the given intervals.
   * <br>
   * Note: <i>The offsets must be in document order and the intervals must not 
   * intersect with each other.</i>
   * 
   * @param parentElement The element that contains all the deleted intervals.
   * @param startOffsets The start offset for each interval.
   * Must be in document order. 0 based and inclusive.
   * @param endOffsets The end offset for each interval.
   * Must be in document order. 0 based and inclusive.
   */
  void multipleDelete(
      AuthorElement parentElement, 
      int[] startOffsets, 
      int[] endOffsets);

  /**
   * Rename the given element.
   * 
   * Any compound must be handled externally.
   * 
   * @param element The {@link AuthorElement} that is renamed.
   * @param newName The new name for the element.
   * @param infoProvider Information provider used for internal processing.
   */
  void renameElement(AuthorElement element, String newName, Object infoProvider);
  
  /**
   * Sets the value of an attribute in the specified element. 
   * Attributes set in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) 
   * will be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute being changed.
   * @param value New {@link AttrValue} for the attribute. If <code>null</code>, the attribute is 
   * removed from the element.
   * @param element The {@link AuthorElement} whose attribute is changing.
   */
  void setAttribute(String attributeName, AttrValue value, AuthorElement element);

  /**
   * Removes an attribute from the given element. 
   * Attributes removed in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) will 
   * be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute to remove.
   * @param element The {@link AuthorElement} whose attribute will be removed.
   */  
  void removeAttribute(String attributeName, AuthorElement element);

  /**
   * Splits the specified node at the given offset.
   * The attributes of the splitted node will also be copied excepting the 
   * unique ones. The unique attributes are identified by the {@link UniqueAttributesRecognizer}.
   * 
   * @param toSplit The {@link AuthorNode} to split.
   * @param splitOffset The split offset. The offset must be greater or equal 
   * to 1 and less than the current document length.
   * @return <code>true</code> if the node was split.
   */
  boolean split(AuthorNode toSplit, int splitOffset);
  
  /**
   * Surrounds the fragment between the specified offset with the specified node.
   * The fragment between the start and end offsets will become the node actual content.
   * 
   * @param node The {@link AuthorNode} that will surround the fragment.
   * @param startOffset Start offset of the surrounded fragment. 0 based and inclusive.
   * @param endOffset End offset of the surrounded fragment. 0 based and inclusive.
   * @param leftToRight <code>true</code> if after the operation the selection 
   * in the author page is done from the left to the right.
   */
  void surroundWithNode(AuthorNode node, int startOffset, int endOffset, boolean leftToRight);
  
  /**
   * Surround the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * 
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the content between start and end offset could not be surrounded.
   */
  void surroundInFragment(String xmlFragment, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Surround the content between the given offsets with plain text fragments(without XML parsing). 
   * The method inserts the <code>header</code> at <code>startOffset</code> and 
   * the <code>footer</code> at <code>endOffset</code>.
   * 
   * @param header The header to be inserted before the surrounded text.
   * @param footer The footer to be inserted after the surrounded text.
   * @param startOffset The start offset of the text to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the text to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the operation failed.
   */
  void surroundInText(String header, String footer, int startOffset, int endOffset) throws AuthorOperationException;

  /**
   * Set a new internal document type to the Author content.
   * 
   * This is a good method to add new entities (regular or unparsed) to the internal document type of the document.
   * 
   * WARNING: if these modifications affect regular entities already inserted and expanded,
   * they will not be re-parsed and their old content will remain rendered as such. 
   * 
   * @param docType The document type information.
   */
  void setDoctype(AuthorDocumentType docType);

  /**
   * Surround the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * 
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException 
   * 
   * @since 12.1
   */
  void surroundInFragment(AuthorDocumentFragment xmlFragment, int startOffset, int endOffset) throws AuthorOperationException ;
}