/**
 * API which allows access to the internal Author hierarchical structure.
 */
package ro.sync.ecss.extensions.api.node;