/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.node;

import org.apache.log4j.Logger;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Contains informations about an attribute value.
 * 
 * WARNING: This class should be immutable. Objects of this class are sometimes cached in the AuthorDocumentHandler
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class AttrValue {
  
  /**
   * Logger for logging. 
   */
  private static Logger logger = Logger.getLogger(AttrValue.class.getName());
  
  /**
   * Empty attribute value constant.
   */
  public final static AttrValue EMPTY_VALUE = new AttrValue("");
  
  /**
   * Attribute normalized value (with entities expanded and WS's collapsed).
   * 
   * Usually the raw and normalized values point to the same string.
   */
  private final String normalizedValue;
  
  /**
   * Attribute raw value (as it is specified in text with no WS's collapsed).
   * 
   * Usually the raw and normalized values point to the same string.
   */
  private final String rawValue;
  
  /**
   * <code>true</code> if the attribute value specified.
   */
  private final boolean isSpecified;

  /**
   * Constructor for the attribute value.
   * 
   * @param specifiedValue The simple attribute value which will be used both as
   * raw value and normalized value. 
   */
  public AttrValue(String specifiedValue) {
    this(specifiedValue, specifiedValue, true);
  }
  
  /**
   * Constructor for the attribute value.
   * 
   * @param normalizedValue Attribute normalized value (with entities expanded 
   * and WS's collapsed).
   * @param rawValue Attribute raw value (as it is specified in text with no WS's
   * collapsed).
   * @param isSpecified <code>true</code> if specified in XML, <code>false</code> 
   * if this is a default value.
   */
  public AttrValue(String normalizedValue, String rawValue, final boolean isSpecified) {
    // EXM-12044 Replace " with &quot; in attribute value.
    if (rawValue != null && rawValue.indexOf('"') != -1) {
      rawValue = rawValue.replace("\"", "&quot;");
    }
    //EXM-18655 Extra checks to ensure that if an AttrValue was created, it has not-null Value inside.
    if(normalizedValue == null) {
      logger.warn("NULL value set to Normalized AttrValue", new Exception());
      normalizedValue = "";
    }
    if(rawValue == null) {
      logger.warn("NULL value set to Raw AttrValue", new Exception());
      rawValue = "";
    }

    this.normalizedValue = normalizedValue;
    this.rawValue = rawValue;
    this.isSpecified = isSpecified;
  }

  /**
   * Get the attribute normalized value.
   * 
   * @return The attribute normalized value (with entities expanded and WS's collapsed).
   */
  public String getValue() {
    return normalizedValue;
  }
  
  /**
   * Get the attribute's raw value.
   * 
   * @return Attribute raw value (as it is specified in text with no WS's collapsed).
   */
  public String getRawValue() {
    return rawValue;
  }

  /**
   * Checks if the attribute was specified in the XML document or comes as a default value from 
   * the schema, DTD, etc..
   * 
   * @return  <code>true</code> if the element is specified in XML, <code>false</code> if this is 
   * a default value.
   */
  public boolean isSpecified() {
    return isSpecified;
  }
  
  /**
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof AttrValue) {
      return ((AttrValue) obj).getValue().equals(getValue());
    }
    return super.equals(obj);
  }
}