/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.node;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorDocumentController;
import ro.sync.ecss.extensions.api.AuthorElementBaseInterface;

/**
 * The Author Element represents an XML element.
 * <br/>
 * The author content contains the entire XML document text and special marker characters.
 * Each author node points in the content to the start and end marker characters which are used to  
 * delimit it's range.
 * The start and end offsets pointed to by the AuthorNode can be retrieved using the
 * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
 * <br/>
 * <img src="AuthorDocumentFragmentArchitecture.gif"/>
 * <br/>
 * The image represents part of the document content and red markers represent special control
 * characters which represent the node ranges.
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorElement extends AuthorElementBaseInterface {

  /**
   * Returns the value of an attribute with the given name. If no such
   * attribute exists, returns <code>null</code>.
   *
   * @param name Name of the attribute.
   * @return The {@link AttrValue}, or <code>null</code> if the attribute does not exist.
   */
  AttrValue getAttribute(String name);

  /**
   * @return The namespace of this element. Empty string is returned if element has no namespace.
   */
  String getNamespace();

  /**
   * Returns the local part of the qualified name of this element.
   *  
   * @return The local name of the element.
   */
  String getLocalName();
  
  /**
   * Search into the list of the children the first node that has specified local name.
   * 
   * @param childLocalName The local name of the searched children.
   * @return The searched node or <code>null</code> if not found.
   * @deprecated Use {@link #getElementsByLocalName(String)}[0] instead.
   */
  @Deprecated
  AuthorNode getChild(String childLocalName);

  /**
   * Gets the children elements having the specified local name.
   * 
   * @param localName The local name of the searched children.
   * @return The list of children (<code>AuthorElement</code>s) having the 
   * specified local name or an empty array if none found. 
   * if not found.
   */
  AuthorElement[] getElementsByLocalName(String localName);

  
  /**
   * Returns the number of the element attributes.
   * 
   * @return The number of the element attributes..
   */
  int getAttributesCount();

  /**
   * Returns the name of the attribute at the specified index.
   * <p>
   * Note: <i>the attributes are not given in document order.</i>
   * </p> 
   * 
   * @param index The index of the searched attribute, 0 based. 
   * @return The name of the attribute at the specified index, 
   * or <code>null</code> if the attribute was not set correctly.
   * @throws ArrayIndexOutOfBoundsException if the specified index is not in range.
   */
  String getAttributeAtIndex(int index) throws ArrayIndexOutOfBoundsException;
  
  /**
   * Sets the value of an attribute for this element.
   * <b>Warning:</b> Use this only when the element is not from a the existing 
   * {@link AuthorDocument} content, for example a cloned element.
   * All operations on nodes from the document model must be done using the 
   * {@link AuthorDocumentController} methods.
   *
   * @param qName The qualified name of the attribute to be set.
   * @param attributeValue The {@link AttrValue} to set. Must not be <code>null</code>.
   */
   void setAttribute(String qName, AttrValue attributeValue);
   
   /**
    * Removes the given attribute from the element list of attributes.
    * <b>Warning:</b> Use this only when the element is not from a the existing 
    * {@link AuthorDocument} content, for example a cloned element.
    * All operations on nodes from the document model must be done using the 
    * {@link AuthorDocumentController} methods.
    *
    * @param qName The qualified name of the attribute to remove.
    */
   void removeAttribute(String qName);
   
   /**
    * Get an attribute's namespace.
    * 
    * @param attributePrefix Prefix of attribute.
    * @return The attribute's namespace.
    * 
    * @since 13.2
    */
   String getAttributeNamespace(String attributePrefix);
}