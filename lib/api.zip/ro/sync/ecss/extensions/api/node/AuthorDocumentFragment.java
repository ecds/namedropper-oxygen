/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.node;

import java.util.List;

import javax.swing.text.BadLocationException;

import org.apache.log4j.Logger;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorDocumentController;
import ro.sync.ecss.extensions.api.AuthorReviewController;
import ro.sync.ecss.extensions.api.Content;
import ro.sync.ecss.extensions.api.highlights.AuthorPersistentHighlight;
import ro.sync.ecss.extensions.api.highlights.AuthorPersistentHighlight.PersistentHighlightType;
import ro.sync.ecss.extensions.api.highlights.AuthorPersistentHighlighter;

/**
 * Represents a fragment of an XML document. It holds a copy of the content of a document fragment. 
 * A change in the fragment does not change the edited document. For changing the edited document 
 * use insert  methods of {@link AuthorDocumentController}.   
 * <br/>
 * <br/>
 * For the following XML code fragment:
 * <br/>
 * <code>
 * &lt;person&gt;&lt;name&gt;Mr.&lt;family&gt;Smith&lt;/family&gt;&lt;given&gt;John&lt;/given&gt;&lt;/name&gt;&lt;email&gt;john@gmail.com&lt;/email&gt;&lt;/person&gt;
 * </code>
 * <br/>
 * the corresponding document fragment structure can be represented as:
 * <br/>
 * <br/>
 * <img src="AuthorDocumentFragmentArchitecture.gif"/>
 * <br/>
 * The image represents the content of the fragment and the red markers represent special control characters which are used 
 * to point to the start and the end offsets of the fragment containing nodes.  
 *
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public class AuthorDocumentFragment {
  
  /** 
   * Logger for logging. 
   */
  private static Logger logger = Logger.getLogger(AuthorDocumentFragment.class.getName());

  /**
   * Content holding the fragment characters.
   */
  private final Content content;

  /**
   * Nodes that make up this fragment.
   */
  private final List<AuthorNode> nodes;

  /**
   * Number of elements it splits to the right.
   */
  private int righSplits;

  /**
   * Number of elements it splits to the left.
   */
  private int leftSplits;
  
  /**
   * The insert/delete change marks for this fragment, can be null.
   * 
   * If the fragment is created when change tracking is turned OFF and the 
   * selection contains Track Changes then the fragment will contain 
   * the list of changes which intersected its region, made relative to the 
   * fragment content.
   * 
   * If the fragment is created when change tracking in turned ON then the 
   * fragment will contain the selection with all changes accepted (so the 
   * list will be always NULL).
   */
  private List<AuthorPersistentHighlight> changeMarks;
  
  /**
   * The comment marks for this fragment, can be null.
   * 
   * The fragment will contain the list of comments which intersected its region, made relative to the 
   * fragment content.
   */
  private List<AuthorPersistentHighlight> persistentMarks;
  
  /**
   * Constructor.
   *
   * @param content The {@link Content} holding the fragment's content.
   * @param elements Elements that make up this fragment.
   * @param leftSplits Number of elements it splits to the left.
   * @param righSplits Number of elements it splits to the right.
   */
  public AuthorDocumentFragment(Content content, List<AuthorNode> elements, int leftSplits, int righSplits) {
    this(content, elements, leftSplits, righSplits, null, null);
  }
  
  /**
   * Constructor.
   *
   * @param content The {@link Content} holding the fragment's content.
   * @param elements Elements that make up this fragment.
   * @param leftSplits Number of elements it splits to the left.
   * @param righSplits Number of elements it splits to the right.
   * @param changeMarkers The list of change markers
   * @param commentMarkers Comment markers
   */
  public AuthorDocumentFragment(
      Content content, List<AuthorNode> elements, int leftSplits, int righSplits, 
      List<AuthorPersistentHighlight> changeMarkers, List<AuthorPersistentHighlight> commentMarkers) {
    this.content = content;
    this.nodes = elements;
    this.leftSplits = leftSplits;
    this.righSplits = righSplits;
    this.changeMarks = changeMarkers;
    this.persistentMarks = commentMarkers;
  }

  /**
   * @return the {@link Content} object holding this fragment's content.
   */
  public Content getContent() {
    return content;
  }
  
  /**
   * @return The number of characters, including sentinels (element start and end markers), 
   * present in the fragment. If there are delete change markers, they are treated as accepted
   */
  public int getAcceptedLength() {
    int len = getLength();
    if(changeMarks != null) {
      for (int i = 0; i < changeMarks.size(); i++) {
        AuthorPersistentHighlight cm = changeMarks.get(i);
        if(cm.getType() == PersistentHighlightType.CHANGE_DELETE) {
          len -= (cm.getEndOffset() - cm.getStartOffset() + 1);
        }
      }
    }
    return len;
  }

  /**
   * @return The number of characters, including sentinels (element start and end markers), 
   * present in the fragment.
   */
  public int getLength() {
    return content.getLength();
  }

  /**
   * @return The nodes that make up this fragment.
   */
  public List<AuthorNode> getContentNodes() {
    return nodes;
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    String toString = "";
    try {
      toString = "Fragment content '" + content.getString(0, content.getLength()).replace((char)0, 'X') +
      "'\n Elements '" + nodes + "\nRight splits:" + righSplits + " Left splits:" + leftSplits;
    } catch (BadLocationException e) {
      // Ignored
    }
    return toString;
  }

  /**
   * @return Number of nodes the fragment splits to the left.
   */
  public int getLeftSplits() {
    return leftSplits;
  }

  /**
   * @return Number of nodes the fragment splits to the right.
   */
  public int getRightSplits() {
    return righSplits;
  }

  /**
   * Set the number of the elements the fragment splits to the left.
   * 
   * @param leftSplits The left splits count.
   */
  public void setLeftSplits(int leftSplits) {
    this.leftSplits = leftSplits;
  }
  
  /**
   * Set the number of the elements the fragment splits to the right.
   * 
   * @param righSplits The right splits count.
   */
  public void setRighSplits(int righSplits) {
    this.righSplits = righSplits;
  }
  
  /**
   * Returns the list with the fragment change tracking highlights.
   * <br/><br/>
   * If the fragment is created when change tracking is turned <b>OFF</b> and the 
   * fragment contains Track Changes, then the returned list will contain the changes
   * which intersected the fragment region, made relative to the fragment content.
   * <br/>
   * If the fragment is created when change tracking in turned <b>ON</b> then the 
   * fragment will contain the selection with all changes accepted (so the 
   * list will be always <code>NULL</code>).
   * <br/><br/>
   * To get the list with all change tracking highlights from the document 
   * use the {@link AuthorReviewController#getChangeHighlights()} method. 
   * 
   * @return Returns list with the fragment change tracking highlights. 
   * <br/>
   * The start and end offset of the returned change tracking highlights are 
   * relative to the start offset of this document fragment.
   * <br/> 
   * The type of the highlights can be one of {@link PersistentHighlightType#CHANGE_INSERT} or 
   * {@link PersistentHighlightType#CHANGE_DELETE}
   * @since 12
   */
  public List<AuthorPersistentHighlight> getChangeHighlights() {
    return changeMarks;
  }
  
  /**
   * Returns the list with the fragment comment highlights or custom highlights.
   * <br/><br/>
   * If the fragment contains comments or custom highlights then the returned list
   * will contain the comments which intersected the fragment, made relative to 
   * the fragment content.
   * <br/><br/>
   * To get the list with all the comments or persistent highlights from the document 
   * see the {@link AuthorReviewController#getCommentHighlights()} and 
   * {@link AuthorPersistentHighlighter#getHighlights()} methods. 
   * 
   * @return Returns the fragment comment highlights or custom highlights list. 
   * The type for a returned {@link AuthorPersistentHighlight} can be {@link PersistentHighlightType#COMMENT} 
   * or {@link PersistentHighlightType#CUSTOM_HIGHLIGHT}. The custom highlights 
   * can be inserted and managed by using the {@link AuthorPersistentHighlighter}.   
   * @since 12
   */
  public List<AuthorPersistentHighlight> getCommentsAndCustomHighlights() {
    return persistentMarks;
  }

  /**
   * Set the list with the fragment comment highlights or custom highlights.
   * 
   * @param highlights The comment highlights or custom highlights list.
   * @since 12
   */
  public void setCommentAndCustomHighlights(List<AuthorPersistentHighlight> highlights) {
    persistentMarks = highlights;
  }

  /**
   * Set the list with the change tracking highlights.
   * 
   * @param markers The change tracking highlights list.
   * @since 12
   */
  public void setChangeHighlights(List<AuthorPersistentHighlight> markers) {
    changeMarks = markers;
  }
  
  /**
   * @return <code>true</code> If the fragment is empty.
   */
  public boolean isEmpty() {
    return content.getLength() == 0;
  }
  
  /**
   * Check if an author document fragment content contains simple text.
   * 
   * @return  <code>True</code> if the content of the given author document fragment contains 
   * simple text (the whitespaces are ignored).
   */
  public boolean containsSimpleText() {
    boolean containsSimpleText = false;
    try {
      // Get the fragment content nodes to determine the content intervals (between the start and 
      // end tag of the content nodes) that must be ignored. 
      List<AuthorNode> contentNodes = getContentNodes();
      Content content = getContent();
      if (contentNodes == null || contentNodes.size() == 0) {
        // No elements in fragment, analyze text. 
        String textContent = content.getString(0, content.getLength());
        // Ignore the text whitespaces.   
        containsSimpleText = textContent.trim().length() > 0;
      } else {
        // The fragment contains elemens
        int lastOffset = 0;
        for (AuthorNode authorNode : contentNodes) {
          // Find the text content offsets
          int currentOffset = authorNode.getStartOffset();
          if (currentOffset >= lastOffset) {
            if (currentOffset != lastOffset) {
              String textContent = content.getString(lastOffset, currentOffset - lastOffset);
              if (textContent.trim().length() > 0) {
                // The fragment contains simple text.
                containsSimpleText = true;
                break;
              }
            }
            lastOffset = authorNode.getEndOffset() + 1;
          }
        }
        // Verify the content between the end offset of the fragment last child node and the end 
        // offset of the fragment content 
        String textContent = content.getString(lastOffset, content.getLength() - lastOffset);
        if (textContent.trim().length() > 0) {
          // The fragment contains simple text.
          containsSimpleText = true;
        }
      }
    } catch (BadLocationException e) {
      logger.error(e, e);
    }
    return containsSimpleText;
  }
}