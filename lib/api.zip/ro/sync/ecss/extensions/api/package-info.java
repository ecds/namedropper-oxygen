/**
 * Main API package used for controlling the Author page (making modifications, adding listeners).
 */
@SkipObfuscate(classes = SkipLevel.PRIVATE, fields = SkipLevel.PRIVATE, methods = SkipLevel.PRIVATE, recursive = true)
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.obfuscate.SkipLevel;
import ro.sync.annotations.obfuscate.SkipObfuscate;
