/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * This is an interface for classes which are responsible for providing information 
 * about the cell spanning.
 * It should be implemented when the author extension being developed offers
 * support for editing data in tabular form.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorTableCellSpanProvider extends Extension {
  /**
   * Get the number of columns the given cell spans across.
   * For example, for the DocBook CALS tables the number of columns the cell spans across
   * is computed by looking at the <code>spanspec</code> attribute. In case the <code>spanspec</code> 
   * attribute is missing then the column span is defined by the <code>namest</code> and <code>nameend</code> attribute.
   * 
   * @param cellElement The node that represents a table cell in CSS.
   * @return The number of columns this cell spans across (the minimum returned value must be 1) 
   * or <code>null</code> if not specified.
   */
  Integer getColSpan(AuthorElement cellElement);
  
  /**
   * Get the number of rows that the given cell spans across.
   * For example, for the DocBook CALS tables this value is computed
   * by looking at the <code>morerows</code> attribute.
   * 
   * @param cellElement The {@link AuthorElement} that represents a table cell in CSS.
   * @return The number of rows this cell spans across (the minimum returned value must be 1)
   * or <code>null</code> if not specified.
   */
  Integer getRowSpan(AuthorElement cellElement);
  
  /**
   * This method is called when starting to compute the layout for a table. Its intended
   * to extract information from the element representing the table only once, not on every 
   * getColSpan() or getRowSpan() call. Example: for a DocBook table we identify and cache
   * the <code>colspec</code> and <code>spanspec</code> elements from that table.
   * 
   * A new instance of the table cell span provider is used for every table in a document so 
   * cached data cannot be used between different tables..
   * 
   * @param tableElement The {@link AuthorElement} representing a table (it has the CSS display property 
   * set on 'table').
   */
  void init(AuthorElement tableElement);
  
  /**
   * This method tells if the table contains column specifications. For example the 
   * CALS table model requires <code>colspec</code> elements to be present.
   * 
   * @param tableElement The {@link AuthorElement} that is rendered as a table.
   * 
   * @return <code>true</code> if some column specification info is present or if the table doesn't
   * require any column specification info.
   */
  boolean hasColumnSpecifications(AuthorElement tableElement);
}