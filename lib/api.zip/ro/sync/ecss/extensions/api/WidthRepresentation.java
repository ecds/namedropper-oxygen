package ro.sync.ecss.extensions.api;

import java.io.Serializable;
import java.util.StringTokenizer;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Specifies the fixed and relative width determined from the value of width/colwidth 
 * attribute of the col.
 * 
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class WidthRepresentation implements Serializable {
  
  /**
   * The default width representation.
   */
  public static WidthRepresentation DEFAULT_WIDTH_REPRESENTATION = new WidthRepresentation(0, null, 0, false); 
  
  /**
   * The serial version UID.
   */
  private static final long serialVersionUID = -7141751698158508637L;

  /**
   * The fixed width unit. 
   */
  public enum Unit {
    /**
     * Centimeters are converted to inches and then multiplied with the dots per inch.
     * The value is <code>cm</code>.
     */
    CENTIMETER("cm"), 
    /**
     * The EM is relative to the font size. 1 is the font size.
     * The value is <code>em</code>. 
     */
    EM("em"), 
    /**
     * The EX is relative the the height of the "x" character.
     * The value is <code>ex</code>.
     */
    EX("ex"), 
    /**
     * Value in inches are multiplied with the dots per inch value.
     * The value is <code>in</code>.
     */
    INCH("in"), 
    /**
     * Value in millimeter is converted to inches and then to pixels. 
     * The value is <code>mm</code>.
     */
    MILLIMETER("mm"), 
    /**
     * Pica is a unit of measure equal to 12 points or one sixth of an inch.
     * The value is <code>pc</code>.
     */
    PICA("pc"),
    /**
     * Directly in pixels. No conversion needed.
     * The value is <code>px</code>.
     */
    PIXEL("px"), 
    /**
     * A point is approximately 1/72 inch.
     * The value is <code>pt</code>.
     */
    POINT("pt");

    /**
     * A string representation of the unit.
     */
    private String unitRepresentation;

    /**
     * Constructor.
     * 
     * @param representation The string representation of the unit.
     */
    private Unit(String representation) {
      this.unitRepresentation = representation;
    }

    /**
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
      return unitRepresentation;
    }
  }

  /**
   * The fixed width value. For instance 2.5. In combination with the fixedWidthUnit represents a width.
   */
  private float fixedWidthValue;

  /**
   * The fixed width unit.
   */
  private Unit fixedWidthUnit = Unit.PIXEL;

  /**
   * The relative width. This value can be relative to the parent width, 
   * or relative to the other siblings. Ex: 3.2
   * 
   */
  private float relativeWidthValue;

  /**
   * If <code>true</code> then the relativeWidth represents a percentage of the   
   * parent width, otherwise the relativeWidth will be computed taking into account 
   * the other siblings widths.
   */
  private boolean isRelativeToParent;

  /**
   * Constructor.
   * 
   * @param fixedWidthValue   The fixed width value. Ex: 2.5 
   * @param fixedWidthUnit    The unit of fixed width. Defaults to PIXEL.
   * @param relativeWidth     The relative width part. Ex: 0.33
   * @param isRelativeToParent  If <code>true</code> then the relative width represents
   *        a percentage of the parent table width, otherwise the relative value
   *        represent a proportional width which is evaluated taking into account 
   *        the proportional values of the other columns.    
   *        <br/>For example, if there are two columns with 70% and 30% relative widths then
   *        the table total width will be divided according with this values. 
   *        <br/>If the relative widths for the two columns are specified in proportional units and,
   *        for example, have the values 1 for the first column and 2 for the second column
   *        then the second column will be twice as large as the first one.
   */
  public WidthRepresentation(float fixedWidthValue, Unit fixedWidthUnit, float relativeWidth, boolean isRelativeToParent) {
    this.fixedWidthValue = fixedWidthValue;
    if (fixedWidthUnit != null) {
      this.fixedWidthUnit = fixedWidthUnit;
    }
    this.relativeWidthValue = relativeWidth;
    this.isRelativeToParent = isRelativeToParent;
  }
  
  /**
   * Constructor.
   * Create a ColWidth corresponding to the given width representation.
   * 
   * @param widthString The string representation of the Width. The 
   *      representation format must be a sum of terms with the following format: 
   *      n(*|%|units). If there are more that one terms with the same form (fixed 
   *      or relative) then corresponding width (fixed or relative) will be reseted.
   * @param acceptPercents If <code>true</code> then percentage values are
   *      accepted
   */
  public WidthRepresentation(String widthString, boolean acceptPercents) {
    // The fixed width value.
    this.fixedWidthValue = 0f;
    // The fixed width unit.
    this.fixedWidthUnit = Unit.PIXEL;
    // The relative width. This value can be relative to the parent width, 
    // or relative to the other siblings.
    this.relativeWidthValue = 0f;
    // If <code>true</code> then the relativeWidth represents a percentage of the   
    // parent width, otherwise the relativeWidth will be computed taking into account 
    // the other siblings widths.
    this.isRelativeToParent = false;
    
    if (widthString != null) {

      // The string will be tokenized by the "+" delimiter
      StringTokenizer tokenizer = new StringTokenizer(widthString, "+");
      boolean fixedSpecified = false;
      boolean relativeSpecified = false;
      boolean resetRelativeWidth = false;
      boolean resetFixedWidth = false;

      while (tokenizer.hasMoreElements()) {
        String token = ((String) tokenizer.nextElement()).trim();
        if (token.length() > 0) {
          char lastChar = token.charAt(token.length() - 1);
          // Try to find the percentage part of the width
          if (lastChar == '%') {
            // Verify if the relative part of the width has already been specified
            if (!relativeSpecified) {
              relativeSpecified = true;
              // Verify if the percentage values are allowed
              if (acceptPercents) {
                String percentage = token.substring(0, token.length() - 1);
                try {
                  // Find the relative width value.
                  relativeWidthValue = Float.parseFloat(percentage) / 100;
                  // The relative with is relative to the parent (percentage value)
                  isRelativeToParent = true;
                } catch (NumberFormatException e) {
                  resetRelativeWidth = true;
                }
              } else {
                resetRelativeWidth = true; 
              }
            } else {
              // If the percentage width are not allowed reset the relative width.
              resetRelativeWidth = true;
            }
          } else if (lastChar == '*') {
            // Try to find the proportion part of the width
            if (!relativeSpecified) {
              relativeSpecified = true;
              String proportion = token.substring(0, token.length() - 1);
              try {
                // Find the relative width value.
                if (proportion.length() == 0) {
                  // '*' it means '1*'
                  relativeWidthValue = 1;
                } else {
                  relativeWidthValue = Float.parseFloat(proportion);
                }
                // The relativeWidth will be computed taking into account 
                // the other siblings widths (proportion value)
                isRelativeToParent = false;
              } catch (NumberFormatException e) {
                // Reset the relative width if there was specified a value with 
                // wrong format
                resetRelativeWidth = true; 
              }
            } else {
              // Reset the relative width if a relative value has already been computed 
              resetRelativeWidth = true;
            }
          } else {
            if (!fixedSpecified) {
              fixedSpecified = true;
              // Try to obtain a lexicalUnit.
              int tokenLength = token.length();
              if (tokenLength > 1) {
                try {
                  String unit = token.substring(tokenLength - 2);
                  // By default, the unit lenght is 2
                  int unitLength = 2;
                  if ("cm".equals(unit)) {
                    fixedWidthUnit = Unit.CENTIMETER;
                  } else if ("em".equals(unit)) {
                    fixedWidthUnit = Unit.EM;
                  } else if ("ex".equals(unit)) {
                    fixedWidthUnit = Unit.EX;
                  } else if ("in".equals(unit)) {
                    fixedWidthUnit = Unit.INCH;
                  } else if ("mm".equals(unit)) {
                    fixedWidthUnit = Unit.MILLIMETER;
                  } else if ("pc".equals(unit)) {
                    fixedWidthUnit = Unit.PICA;
                  } else if ("px".equals(unit)) {
                    fixedWidthUnit = Unit.PIXEL;
                  } else if ("pt".equals(unit)) {
                    fixedWidthUnit = Unit.POINT;
                  } else {
                    // unit length is 0
                    unitLength = 0;
                    fixedWidthUnit = Unit.PIXEL;
                  }
                  if (unitLength == 0) {
                    fixedWidthValue = Float.parseFloat(token);
                  } else {
                    fixedWidthValue = Float.parseFloat(token.substring(0, tokenLength - unitLength));
                  }
                } catch (NumberFormatException e) {
                  // No valid fixed width detected. 
                }
              }
            } else {
              resetFixedWidth = true;
            }
          }
        }
      }

      // Reset the relative width.
      if (resetRelativeWidth) {
        relativeWidthValue = 0;
      } 

      // Reset the relative width.
      if (resetFixedWidth) {
        fixedWidthValue = 0;
      } 
    }
  }

  /**
   * @return Returns the fixed width part of the width representation. Ex: 2.5
   */
  public float getFixedWidth() {
    return fixedWidthValue;
  }
  
  /**
   * @return Returns the fixed width unit. Ex: Unit.CENTIMETER
   */
  public Unit getFixedWidthUnit() {
    return fixedWidthUnit;
  }
  
  /**
   * @return Returns the relative width part of the width representation.
   */
  public float getRelativeWidth() {
    return relativeWidthValue;
  }
  
  /**
   * @return Returns <code>true</code> if the relative part of the width is expressed
   * relative to the parent width, <code>false</code> if is expressed relative to other siblings.
   */
  public boolean isRelativeToParent() {
    return isRelativeToParent;
  }

  /**
   * @return <code>true</code> if the current width representation should be taken
   * into account when building the layout. 
   */
  public boolean isApplicable() {
    return relativeWidthValue > 0 || fixedWidthValue > 0;
  }

  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return (isRelativeToParent ? ("(" + relativeWidthValue + ")" + (relativeWidthValue * 100) + "%") : (relativeWidthValue + "*")) + " + " + fixedWidthValue + fixedWidthUnit;
  }
  
  /**
   * @return The string representation of the width. The format of the width is 
   * <br/>
   * <code>
   * [fixed_width][fixed_width_unit] + [relative_width %|*] 
   * </code>
   * 
   */
  public String getWidthRepresentation() {
    String toReturn = null;
    boolean hasRelativePart = relativeWidthValue > 0;
    boolean hasFixedPart = fixedWidthValue > 0;
    if (hasRelativePart) {
      toReturn = 
        (isRelativeToParent() ? 
            Math.round(relativeWidthValue * 100) + "%" 
            : ((relativeWidthValue == (int)relativeWidthValue ? 
                (int)relativeWidthValue + "" : relativeWidthValue + "") + "*"));
      if (hasFixedPart) {
        if(fixedWidthValue == (int)fixedWidthValue) {
          //Round it, looks nicer
          toReturn += " + " + (int)fixedWidthValue + fixedWidthUnit;
        } else {
          toReturn += " + " + fixedWidthValue + fixedWidthUnit;
        }
      }
    } else if (hasFixedPart) {
      if(fixedWidthValue == (int)fixedWidthValue) {
        //Round it, looks nicer
        toReturn = String.valueOf((int)fixedWidthValue) + fixedWidthUnit;
      } else {
        toReturn = String.valueOf(fixedWidthValue) + fixedWidthUnit;
      }
    }
    return toReturn;
  }
}