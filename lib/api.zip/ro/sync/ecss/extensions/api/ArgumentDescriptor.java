/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Descriptor class for an author operation argument.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class ArgumentDescriptor {
  /**
   * String argument type.
   * The value is <code>0</code>.
   */
  public static final int TYPE_STRING = 0;
  /**
   * XML fragment argument type. It is represented as a {@link String}
   * The value is <code>1</code>.
   */
  public static final int TYPE_FRAGMENT = 1;
  /**
   * Xpath expression argument type. It is represented as a {@link String}
   * The value is <code>2</code>.
   */
  public static final int TYPE_XPATH_EXPRESSION = 2;
  /**
   * List of constant strings argument type.
   * The value is <code>3</code>.
   */
  public static final int TYPE_CONSTANT_LIST = 3;  
  /**
   * The argument name.
   */
  protected String name = null;
  /**
   * The argument type, can be one of:
   * {@link ArgumentDescriptor#TYPE_STRING},
   * {@link ArgumentDescriptor#TYPE_FRAGMENT},
   * {@link ArgumentDescriptor#TYPE_XPATH_EXPRESSION},
   * {@link ArgumentDescriptor#TYPE_CONSTANT_LIST},
   */
  protected int type = -1;
  /**
   * The string argument description.
   */
  protected String description = null;
  /**
   * The array containing the allowed values for the arguments with type
   * TYPE_CONSTANTS_LIST.
   */
  protected String[] allowedValues;
  /**
   * The default value of the argument. 
   */
  protected String defaultValue;
  
  /**
   * Constructor of the argument descriptor class.
   * 
   * @param name The name of the argument.
   * @param type The type of the argument, one of:
   * {@link ArgumentDescriptor#TYPE_STRING},
   * {@link ArgumentDescriptor#TYPE_FRAGMENT},
   * {@link ArgumentDescriptor#TYPE_XPATH_EXPRESSION},
   * {@link ArgumentDescriptor#TYPE_CONSTANT_LIST},
   * @param description The description of the argument.
   */
  public ArgumentDescriptor(String name, int type, String description) {
    this(name, type, description, null, null);
  }
  
  /**
   * Constructor of the argument descriptor class.
   * 
   * @param name The name of the argument.
   * @param type The type of the argument, one of:
   * {@link ArgumentDescriptor#TYPE_STRING},
   * {@link ArgumentDescriptor#TYPE_FRAGMENT},
   * {@link ArgumentDescriptor#TYPE_XPATH_EXPRESSION},
   * {@link ArgumentDescriptor#TYPE_CONSTANT_LIST},
   * @param description The description of the argument.
   * @param allowedValues The allowed values for the defined argument.
   * @param defaultValue The default value of the argument.
   */
  public ArgumentDescriptor(String name, int type, String description, String[] allowedValues, String defaultValue) {
    this.name = name;
    this.type = type;
    this.description = description;
    this.allowedValues = allowedValues;
    this.defaultValue = defaultValue;
    if (name == null || name.trim().length() == 0) {
      throw new IllegalArgumentException("Argument name unspecified");
    } else if (type ==TYPE_CONSTANT_LIST && (allowedValues == null || allowedValues.length == 0)) {
      throw new IllegalArgumentException("For a TYPE_CONSTANT_LIST argument you must also provide the allowed values.");
    }
  }
  
  /**
   * @return The name of the argument.
   */
  public String getName() {
    return name;
  }

  /**
   * @return The type of the argument, one of:
   * {@link ArgumentDescriptor#TYPE_STRING},
   * {@link ArgumentDescriptor#TYPE_FRAGMENT},
   * {@link ArgumentDescriptor#TYPE_XPATH_EXPRESSION},
   * {@link ArgumentDescriptor#TYPE_CONSTANT_LIST},
   */
  public int getType() {
    return type;
  }
  
  /**
   * @return The description of the argument.
   */
  public String getDescription() {
    return description;
  }

  /**
   * Returns a {@link String} description of the given argument type.
   * 
   * @param type The argument type, one of:
   * {@link ArgumentDescriptor#TYPE_STRING},
   * {@link ArgumentDescriptor#TYPE_FRAGMENT},
   * {@link ArgumentDescriptor#TYPE_XPATH_EXPRESSION},
   * {@link ArgumentDescriptor#TYPE_CONSTANT_LIST},
   * @return The type description, or <code>null</code> if the type is not valid.
   */
  public static String decodeType(int type) {
    String toReturn = null;
    switch (type) {
      case TYPE_STRING:
        toReturn = "String";
        break;
      case TYPE_FRAGMENT:
        toReturn = "Fragment";
        break;
      case TYPE_XPATH_EXPRESSION:
        toReturn = "XPathExpression";
        break;
      case TYPE_CONSTANT_LIST:
        toReturn = "ConstantList";
        break;
    }
    return toReturn;
  }

  /**
   * @return The array with allowed values. 
   * Is used for <code>TYPE_CONSTANTS_LIST</code> arguments.
   */
  public String[] getAllowedValues() {
    return allowedValues;
  }

  /**
   * @return The default value of the argument.
   */
  public String getDefaultValue() {
    return defaultValue;
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return getName() + "|" + getType() + "|" + getDescription();
  }
}