/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.callouts.AuthorCalloutsController;
import ro.sync.ecss.extensions.api.highlights.AuthorPersistentHighlight;
import ro.sync.ecss.extensions.api.highlights.PersistentHighlightRenderer;
import ro.sync.exml.view.graphics.Color;

/**
 * Controller that can be used to toggle the change tracking state, modify the review 
 * highlight author name, the highlight painting or to obtain information
 * about the properties used in the serialization and representation of the review 
 * highlight (author name, reviewer auto color or the current time stamp in a format
 * identical to the one used by Oxygen for insert, delete and comment review highlights).  
 * 
 * @since 12
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorReviewController extends AuthorChangeTrackingController {

  /**
   * Set the current reviewer author name, used in the processing instruction 
   * that results when a 
   * <br/>
   * <code>Tracked Change</code>
   * <br/> 
   * <code>
   * (&lt;?oxy_insert_start author="reviewer_name"...?>xml content&lt;?oxy_insert_end?>)
   * </code> 
   * <br/>
   * or
   * <br/>
   * <code>Comment</code>
   * <br/>
   * <code>
   * (&lt;?oxy_comment_start author="reviewer_name"...?>xml content&lt;?oxy_comment_end?>)
   * </code>
   * <br/> 
   * is serialized, as value of the "author" attribute. 
   * By default the author name specified in the Oxygen Preferences is used 
   * for serialization.
   * 
   * @param authorName The reviewer author name. 
   * If set to <code>null</code>, the default author name (as set in the Oxygen Preferences) 
   * will be used in Change Tracking and Comments serialization.    
   */
  public void setReviewerAuthorName(String authorName);
  
  /**
   * Get the current reviewer author name. 
   * <br/>
   * By default, the reviewer author name is the author name specified in the Oxygen Preferences but it
   * can be changed by using {@link #setReviewerAuthorName(String)}.
   * 
   * @return The current reviewer author name.
   */
  public String getReviewerAuthorName();
  
  /**
   * The callouts are representations of Track Changes insert and delete highlights, 
   * review comment highlights and the custom review highlights in Author mode.
   * <br/>
   * This controller can be used to check what types of callouts are presented in 
   * Author mode. It also can be used to override the callouts display options 
   * from Oxygen Preferences.
   * 
   * @return The Author review callouts controller.
   * 
   * @since 14
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  public AuthorCalloutsController getAuthorCalloutsController();
  
  /**
   * Get the current time stamp in a format identical to the one used by Oxygen for 
   * insert and delete review highlights.
   * <br/>
   * Form: <code>yyyyMMdd'T'HHmmssZ</code>
   * <br/>
   * 
   * @return the current time stamp.
   */
  public String getCurrentTimestamp();
  
  /**
   * Get a color assigned automatically to the reviewer author name.
   * <br/>
   * It is used when in the Oxygen Preferences <b>Auto</b> coloring is set for the <code>Insert</code>, <code>Delete</code> or <code>Comment</code> reviews.
   * 
   * @param reviewerAuthorName The reviewer author name.
   * @return The color automatically assigned to the specified author. Never null.
   */
  public Color getReviewerAutoColor(String reviewerAuthorName);
  
  /**
   * Set a renderer for customizing the way that the review highlights (<code>Insert</code>, <code>Delete</code> or <code>Comment</code>) are displayed.
   * 
   * @param renderer the renderer used to customize painting for the review highlights.
   */
  public void setReviewRenderer(PersistentHighlightRenderer renderer);
  
  /**
   * Fetches the list of comment highlights.
   *
   * @return The comment highlights array.
   * @since 12
   */
  public AuthorPersistentHighlight[] getCommentHighlights(); 
}
