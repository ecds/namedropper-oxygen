/**
 * API Access to different parts of the Author editor and of the entire application workspace.
 */
package ro.sync.ecss.extensions.api.access;