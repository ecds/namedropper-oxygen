/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.util.List;

import javax.swing.text.BadLocationException;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * If Schema Aware mode is active in Oxygen, all actions that can generate invalid content will be redirected toward
 * this handler. The handler can either resolve a specific case, let the default implementation take place or reject the
 * edit entirely by throwing an {@link InvalidEditException}.   
 * <p>
 * It is recommended to extend class {@link AuthorSchemaAwareEditingHandlerAdapter} in order to be protected from any
 * API additions that may occur in interface {@link AuthorSchemaAwareEditingHandler}.
 * </p>
 * 
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorSchemaAwareEditingHandler {
  /**
   * Typing action.
   */
  static int ACTION_ID_TYPING = 1;
  /**
   * Delete action through delete key.
   */
  static int ACTION_ID_DELETE = 2;
  /**
   * Delete action through backspace key.
   */
  static int ACTION_ID_BACKSPACE = 3;
  /**
   * Paste action.
   */
  static int ACTION_ID_PASTE = 4;
  /**
   * Cut action. 
   */
  static int ACTION_ID_CUT = 5;
  /**
   * DND action.
   */
  static int ACTION_ID_DND = 6;
  /**
   * Insert document fragment action by an action other than PASTE or DND.
   */
  static int ACTION_ID_INSERT_FRAGMENT = 7;
  
  /**
   * Handle a keyboard delete event at the given offset (using Delete or Backspace keys) in the Author edit area. 
   *  
   * @param offset Offset where the delete event happened.
   * @param deleteType <code>ACTION_ID_DELETE</code> if Delete key was used or <code>ACTION_ID_BACKSPACE</code> for Backspace.
   * @param authorAccess Access class to the author functions.
   * @param wordLevel <code>true</code> if the user requested a delete for a whole word. 
   * @return <code>true</code> if the event was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handleDelete(int offset, int deleteType, AuthorAccess authorAccess, boolean wordLevel) throws InvalidEditException;
  
  /**
   * Handle a delete nodes event coming from the Outline or Bread crumb.
   * @param nodes The nodes to delete.
   *  
   * @param deleteType <code>ACTION_ID_DELETE</code> if the nodes were deleted directly by the user or <code>ACTION_ID_DND</code> if the nodes were deleted as a result of a drag and drop move operation in the Outline.
   * @param authorAccess Access class to the author functions.
   * @return <code>true</code> if the event was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   * 
   * @since 12.1
   */
  boolean handleDeleteNodes(AuthorNode[] nodes, int deleteType, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Handle a delete selection event in the Author edit area. 
   * The event is generated when a selection exists inside the document and one of following actions takes place:
   * <ul> 
   * <li>typing (insert a new character in document by typing);</li>
   * <li>cut;</li> 
   * <li>DND move;</li>
   * <li>delete or backspace.</li>
   * </ul>
   * 
   * @param selectionStart Selection start offset. 
   * @param selectionEnd Selection end offset.
   * @param generatedByActionId An id identifying the action that generated this event. One of the following constants are possible:
   * ACTION_ID_TYPING, ACTION_ID_DELETE, ACTION_ID_PASTE, ACTION_ID_CUT, ACTION_ID_DND, ACTION_ID_INSERT_FRAGMENT.
   * @param authorAccess Access class to the author functions.
   * @return <code>true</code> if the event was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handleDeleteSelection(int selectionStart, int selectionEnd, int generatedByActionId, AuthorAccess authorAccess) throws InvalidEditException;
  /**
   * Handle an insert fragment event generated by:
   * <ul>
   * <li>a Paste action. In this case, selection removal is handled before calling this method.</li> 
   * <li>a DND action. In this case source  removal is handled after calling this method (unless an exception was thrown).</li> 
   * <li>an insert fragment event occurred as a result of an schema aware insert event, 
   * like {@link AuthorDocumentController#insertXMLFragmentSchemaAware(String, int)}. Selection removal is handled 
   * before calling this method.</li>
   * </ul>
   * 
   * @param offset Offset where the event occurred.
   * @param fragmentsToInsert Fragments to be inserted.
   * @param actionId  ACTION_ID_PASTE if event was generated by paste action, ACTION_ID_DND if it was generated by 
   * a DND event or ACTION_ID_INSERT_FRAGMENT if the event was generated by an {@link AuthorDocumentController} schema aware insert method.
   * @param authorAccess Access class to the author functions.
   * 
   * @return <code>true</code> if the insertion was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handlePasteFragment(int offset, AuthorDocumentFragment[] fragmentsToInsert, int actionId, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Handle a typing event. If the event is not handled, the default implementation 
   * of a handler will be given a chance to handle the event. If that fails to
   * provide a solution, {@link #handleTypingFallback(int, char, AuthorAccess)}
   * will get called.
   * 
   * @param offset Offset where the typing occurred.
   * @param ch The typed character. 
   * @param authorAccess Access class to the author functions.
   * 
   * @return code>true</code> if the typing was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handleTyping(int offset, char ch, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Give a fallback solution for a typing event. This call comes when this object's
   * {@link #handleTyping(int, char, AuthorAccess)} method did not handle the 
   * typing event and neither did the {@link #handleTyping(int, char, AuthorAccess)} from
   * the default implementation. 
   * <p>As a fallback solution, a paragraph can be inserted at the given offset 
   * (if allowed) and then the typed character can be inserted inside it.</p>
   * 
   * @param offset Offset where the typing occurred.
   * @param ch The typed character. 
   * @param authorAccess Access class to the author functions.
   * 
   * @return <code>true</code> if the typing was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   * @since 13.2
   */
  boolean handleTypingFallback(int offset, char ch, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Handle delete element tags event. (Unwrapping)
   * 
   * @param nodeToUnwrap The node to delete element tags.
   * @param authorAccess Access class to the author functions.
   * @return code>true</code> if the event was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handleDeleteElementTags(AuthorNode nodeToUnwrap, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Handle a join event between the given nodes.
   *
   * @param targetNode The node where the content of the other nodes must migrate.
   * @param nodesToJoin The nodes that must be joined in the target node.
   * @param authorAccess Access class to the author functions.
   * @return <code>true</code> if the event was handled.
   * @throws InvalidEditException This is an invalid edit and must be rejected.
   */
  boolean handleJoinElements(AuthorNode targetNode, List<AuthorNode> nodesToJoin, AuthorAccess authorAccess) throws InvalidEditException;
  
  /**
   * Create a fragment for copy.
   */
  static int CREATE_FRAGMENT_PURPOSE_COPY = 0;
  
  /**
   * Create a fragment for cut.
   */
  static int CREATE_FRAGMENT_PURPOSE_CUT = 1;

  /**
   * Create a fragment for DND copy.
   */
  static int CREATE_FRAGMENT_PURPOSE_DND_COPY = 2;
  
  /**
   * Create a fragment for DND move.
   */
  static int CREATE_FRAGMENT_PURPOSE_DND_MOVE = 3;
  
  /**
   * Create an AuthorDocumentFragment for a purpose
   * @param authorAccess Access to the Author API.
   * @param startOffset Start offset of fragment
   * @param endOffset End offset of fragment
   * @param creationPurposeID One of the CREATE_FRAGMENT_* constants in this class.
   * @return The created fragment or null if the event was not handled.
   * @throws BadLocationException 
   * 
   * @since 12.1
   */
  AuthorDocumentFragment handleCreateDocumentFragment(int startOffset, int endOffset, int creationPurposeID, AuthorAccess authorAccess) throws BadLocationException;
}
