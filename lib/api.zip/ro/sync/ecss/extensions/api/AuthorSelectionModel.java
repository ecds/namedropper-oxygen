/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.util.List;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Get the Author selection model containing access to all Author selection 
 * intervals and methods for adding simple and multiple selections. 
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p>   
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorSelectionModel {
  
  /**
   * Impose the interpretation mode of the actual selection from the Author 
   * editor page. 
   * <br/>
   * See {@link SelectionInterpretationMode} for more details about the interpretation
   * of selection in Author mode.
   * <br/> 
   * This interpretation mode is reseted when the next caret moved is performed or
   * another interpretation mode is imposed.
   * 
   * @param interpretationMode The selection interpretation mode.
   */
  void setSelectionInterpretationMode(SelectionInterpretationMode interpretationMode);
  
  /**
   * Get the interpretation mode of the actual selection from the Author 
   * editor page. 
   * <br/>
   * See {@link SelectionInterpretationMode} for more details about the interpretation
   * of selection in Author mode.
   * <br/> 
   * This interpretation mode is reseted when the next caret moved is performed or
   * another interpretation mode is imposed.
   * 
   * @return The selection interpretation mode.
   */
  SelectionInterpretationMode getSelectionInterpretationMode();
  
  /**
   * Get all Author editor page selection intervals. 
   * Each {@link ContentInterval} contains the <b>inclusive</b> 
   * start selection offset and the <b>exclusive</b> end selection offset.
   * <br/>
   * <br/>
   * The selection intervals are added to the list in the same order in which 
   * the selections are made in the Author editor page. If the caret is not inside 
   * a selection the last selection interval points to the caret offset 
   * (both {@link ContentInterval#getStartOffset()} and {@link ContentInterval#getEndOffset()}
   * will return the caret position). Otherwise, the last {@link ContentInterval} 
   * from the list corresponds with the last selection made in the editor.
   * <br/>
   * <br/>
   * This method never returns <code>null</code>. If there is no selection,
   * the list contains a single {@link ContentInterval} that points to the caret offset.
   * 
   * @return the list containing all the Author editor page selection intervals.
   */
  List<ContentInterval> getSelectionIntervals();
  
  /**
   * Get the current selection interval. This is the last selection made in the
   * Author editor page (the last selection from the {@link #getSelectionIntervals()}
   * selections list). If the caret offset is not included in a selection range, 
   * the selection interval points to the caret offset (both {@link ContentInterval#getStartOffset()}
   * and {@link ContentInterval#getEndOffset()} will return the caret position).
   * <br/>
   * The {@link ContentInterval} contains the <b>inclusive</b> start selection
   * offset and the <b>exclusive</b> end selection offset.
   * <br/>
   * <br/>
   * This method never returns <code>null</code>. If there is no selection,
   * both the start and end offset of the interval will be the caret position.
   * 
   * @return The interval of the current selection.
   */
  ContentInterval getSelectionInterval();
  
  /**
   * Check if the Author editor page has selection.
   * 
   * @return <code>true</code> if there is a selection in Author editor page.
   */
  boolean hasSelection();
  
  /**
   * Check if the Author editor page has multiple selections.
   * 
   * @return <code>true</code> if there are at least two selections in 
   * Author editor page.
   */
  boolean hasMultipleSelection();
  
  /**
   * Select the interval between start and end offset.
   * <br/>
   * This selection interval is considered to be the current one (the one that 
   * will be returned by the {@link AuthorSelectionModel#getSelectionInterval()} 
   * method). 
   * <br/> 
   * <br/>
   * The previous Author selections are discarded.
   *  
   * @param startOffset <b>Inclusive</b> start offset 
   * @param endOffset  <b>Exclusive</b> end offset
   */
  void setSelection(int startOffset, int endOffset);

  /**
   * Select the interval between start and end offset. 
   * <br/> 
   * This selection interval is considered to be the current one (the one that 
   * will be returned by the {@link AuthorSelectionModel#getSelectionInterval()} 
   * method).  
   * <br/>
   * <br/>  
   * The previous Author selections are kept.
   * Call {@link AuthorSelectionModel#getSelectionIntervals()} method to get all 
   * the selection intervals from Author editor page.  
   *  
   * @param startOffset <b>Inclusive</b> start offset 
   * @param endOffset  <b>Exclusive</b> end offset
   */
  void addSelection(int startOffset, int endOffset);
  
  /**
   * Clears all selections from Author editor page and resets the selection interpretation mode (see 
   * {@link AuthorSelectionModel#getSelectionInterpretationMode()}).
   * The caret will remain in the same position.
   * <br/>
   * <br/>
   * After this method is executed, {@link AuthorSelectionModel#getSelectionIntervals()} will return a single
   * selection interval that points to the caret offset (both {@link ContentInterval#getStartOffset()}
   * and {@link ContentInterval#getEndOffset()} will return the caret position).
   */
  void clearSelection();
}
