/**
 * API used to process the Author content.
 */
package ro.sync.ecss.extensions.api.content;