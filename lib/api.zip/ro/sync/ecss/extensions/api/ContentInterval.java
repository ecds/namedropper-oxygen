package ro.sync.ecss.extensions.api;

/**
 * A content interval containing the <b>inclusive</b> start offset and 
 * <b>exclusive</b> end offset.  
 */
public class ContentInterval {
  /**
   * Interval <b>inclusive</b> start offset.
   */
  private int startOffset;
  /**
   * Interval <b>exclusive</b> end offset.  
   */
  private int endOffset;

  /**
   * Constructor.
   * 
   * @param startOffset Interval <b>inclusive</b> start offset.
   * @param endOffset Interval <b>exclusive</b> end offset.  
   */
  public ContentInterval(int startOffset, int endOffset) {
    this.startOffset = startOffset;
    this.endOffset = endOffset;
  }

  /**
   * @return Returns the content interval <b>inclusive</b> start offset.
   */
  public int getStartOffset() {
    return startOffset;
  }

  /**
   * @return Returns the content interval <b>exclusive</b> end offset.  
   */
  public int getEndOffset() {
    return endOffset;
  }
}