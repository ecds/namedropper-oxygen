/**
 * Used for implementing navigation between links and their targets.
 */
package ro.sync.ecss.extensions.api.link;