package ro.sync.ecss.extensions.api;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Impose how the selection is interpreted by the application. 
 * <br/>
 * <br/>
 * The {@link SelectionInterpretationMode#TABLE_COLUMN} interpretation mode is 
 * already set by default by the application when a table column is selected. 
 * In this case, when the column is pasted, it is also interpreted as a table column 
 * by the application built-in document types. 
 * <br/>
 * To obtain this behavior for any selection, the {@link SelectionInterpretationMode#TABLE_COLUMN} 
 * interpretation mode must be imposed from 
 * {@link AuthorSelectionModel#setSelectionInterpretationMode(SelectionInterpretationMode)}
 * method.
 * <br/>
 * For instance, when two paragraphs are copied, the clipboard object contains 
 * a list with two Author document fragments (one for each paragraph).
 * If the selection interpretation mode is imposed to {@link SelectionInterpretationMode#TABLE_COLUMN},
 * when pasting the fragments a table column is created, each paragraph being
 * the content of a column cell.
 * <br/>
 * <br/>
 * For a custom document type, when a content with an imposed {@link SelectionInterpretationMode#TABLE_COLUMN} 
 * interpretation mode is pasted the AuthorTableOperationsHandler#handlePasteColumn(AuthorTablePasteColumnArguments)
 * method is called. If there is no implementation for this extension, the default paste 
 * behavior is invoked.
 * <br/>
 * See {@link ExtensionsBundle#getAuthorTableOperationsHandler()} for handling the
 * paste column operation.
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public enum SelectionInterpretationMode {
  /**
   * Table column selection interpretation.
   */
  TABLE_COLUMN,
  
  /**
   * Table row selection interpretation.
   */
  TABLE_ROW,
  
  /**
   * Table selection interpretation.
   */
  TABLE
}