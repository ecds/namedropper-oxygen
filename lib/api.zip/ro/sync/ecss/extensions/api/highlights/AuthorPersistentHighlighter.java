/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.highlights;

import java.util.LinkedHashMap;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.access.AuthorEditorAccess;
import ro.sync.ecss.extensions.api.callouts.AuthorCalloutsController;
import ro.sync.ecss.extensions.api.callouts.CalloutsRenderingInformationProvider;

/**
 * Manage the user custom persistent highlights which get serialized in the XML as processing
 * instructions with the form:
 * <br/>
 * <code>&lt;?oxy_custom_start prop1="val1"....?> xml content &lt;?oxy_custom_end?></code>
 * <br/>
 * The Highlighter is accessible from {@link AuthorEditorAccess#getPersistentHighlighter()}.
 * 
 * @since 12
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorPersistentHighlighter {

  /**
   * Add a persistent highlight
   * @param startOffset Start offset
   * @param endOffset End offset
   * @param properties name/value pairs which will get serialized to disk. 
   * <p>Notes:<br/>
   * 1. Each property name must be a valid XML attribute name.<br/>
   * 2. Each property value will be escaped to be a valid XML attribute value.<br/>
   * 3. In order to change the properties for a highlight you have to use the method: {@link #setProperties(AuthorPersistentHighlight, LinkedHashMap)}.<br/>
   * </p>
   * @return The added highlight or null if the highlight cannot be added.
   * @throws IllegalArgumentException Thrown when a property name is not a valid XML attribute name. 
   */
  public AuthorPersistentHighlight addHighlight(int startOffset, int endOffset, LinkedHashMap<String, String> properties) throws IllegalArgumentException;
  
  /**
   * Removes a highlight from the view.
   *
   * @param highlight the highlight to remove
   */
  public void removeHighlight(AuthorPersistentHighlight highlight);

  /**
   * Removes all custom persistent highlights.
   */
  public void removeAllHighlights();
  
  /**
   * Fetches the list of custom persistent highlights.
   *
   * @return the highlight array.
   */
  public AuthorPersistentHighlight[] getHighlights();
  
  /**
   * Set new properties of a specific highlight.<br/> 
   * A copy of the initial properties can be obtained from {@link AuthorPersistentHighlight#getClonedProperties()}
   * 
   * @param highlight The highlight for which the properties will be set.
   * @param newProperties The new highlight properties.
   * <p>Notes:<br/>
   * 1. Each property name must be a valid XML attribute name.
   * <br/>
   * 2. Each property value will be escaped to be a valid XML attribute value.
   * </p>
   * @throws IllegalArgumentException Thrown when a property name is not a valid XML attribute name.
   */
  public void setProperties(AuthorPersistentHighlight highlight, LinkedHashMap<String, String> newProperties) throws IllegalArgumentException;
  
  /**
   * Set a renderer for customizing the way that the custom persistent highlights are displayed.
   * 
   * @param renderer The renderer defining the way in which the highlights are painted.
   */
  public void setHighlightRenderer(PersistentHighlightRenderer renderer);

  /**
   * Set the provider for the actions that are available for a specific highlight.
   * The actions are currently displayed in the persistent highlights associated callouts popup menu,
   * but in future could be also used as actions presented for a highlight in the contextual menu 
   * of the main editing area.
   * <br/>
   * The callouts are representations of Track Changes insert and delete highlights, 
   * review comment highlights and custom review highlights in Author mode.
   * To associate callout information to a custom highlight the 
   * {@link AuthorCalloutsController#setCalloutsRenderingInformationProvider(CalloutsRenderingInformationProvider)}
   * method must be used.
   * 
   * @param provider The highlights callout rendering information provider.
   * @throws IllegalArgumentException Thrown when a property name is not a valid XML attribute name. 
   * 
   * @since 14
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  public void setHighlightsActionsProvider(AuthorPersistentHighlightActionsProvider provider);
}
