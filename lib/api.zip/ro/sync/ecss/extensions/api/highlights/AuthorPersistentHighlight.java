/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.highlights;

import java.util.LinkedHashMap;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.ecss.extensions.api.AuthorReviewController;

/**
 * Defines the Author Persistent Highlight which get serialized in the XML as 
 * processing instruction. 
 * The Author Persistent Highlight has one of the following types defined in 
 * {@link PersistentHighlightType}:
 * <ul>
 * <li>
 * {@link PersistentHighlightType#CUSTOM_HIGHLIGHT} represents the <code>Custom defined 
 * highlights</code> that can be managed by using the {@link AuthorPersistentHighlighter}.
 * The name of the processing instruction markers corresponding to this type of highlight are
 * <code>oxy_custom_start</code> and <code>oxy_custom_end</code>
 * </li>
 * <li>
 * {@link PersistentHighlightType#COMMENT} represents the <code>Comment highlights</code>
 * which get serialized using the <code>oxy_comment_start</code> and 
 * <code>oxy_comment_end</code> processing instruction names.
 * </li>
 * <li>
 * {@link PersistentHighlightType#CHANGE_INSERT} represents the <code>Insert 
 * highlight from Change Tracking</code>, with the <code>oxy_insert_start</code>
 * and <code>oxy_insert_end</code> corresponding processing instruction names.
 * </li>
 * <li>
 * {@link PersistentHighlightType#CHANGE_DELETE} represents the <code>Delete 
 * highlight from Change Tracking</code>, which get serialized by using the 
 * <code>oxy_delete</code> processing instruction name.
 * <br/>
 * </li>
 * </ul>
 * The <code>Comment</code>, <code>Insert</code> and <code>Delete</code> 
 * persistent highlights can be accessed and customized by using the 
 * {@link AuthorReviewController}.  
 * 
 * @since 12
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorPersistentHighlight extends AuthorPersistentHighlightConstants {
  /**
   * The <code>Author Persistent Highlight</code> type.
   * <br/>
   * <br/>
   * {@link #CUSTOM_HIGHLIGHT} represents the <code>Custom defined 
   * highlights</code> that can be managed by using the {@link AuthorPersistentHighlighter}.
   * The name of the processing instruction markers corresponding to this type of highlight are
   * <code>oxy_custom_start</code> and <code>oxy_custom_end</code>
   * <br/>
   * {@link #COMMENT} represents the <code>Comment highlights</code>
   * which get serialized using the <code>oxy_comment_start</code> and 
   * <code>oxy_comment_end</code> processing instruction names.
   * <br/>
   * {@link #CHANGE_INSERT} represents the <code>Insert 
   * highlight from Change Tracking</code>, with the <code>oxy_insert_start</code>
   * and <code>oxy_insert_end</code> corresponding processing instruction names.
   * <br/>
   * {@link #CHANGE_DELETE} represents the <code>Delete 
   * highlight from Change Tracking</code>, which get serialized by using the 
   * <code>oxy_delete</code> processing instruction name.
   */
  public enum PersistentHighlightType {
    /**
     * Comment persistent highlight
     */
    COMMENT, 
    /**
     * Custom persistent highlight
     */
    CUSTOM_HIGHLIGHT, 
    /**
     * Insert change highlight
     */
    CHANGE_INSERT,
    /**
     * Delete change highlight
     */
    CHANGE_DELETE
  }
  
  /**
   * Get the highlight start offset.
   * 
   * @return The start offset (inclusive). 
   */
  public int getStartOffset();

  /**
   * Get the highlight end offset.
   * 
   * @return The end offset (inclusive).
   */
  public int getEndOffset();
  
  /**
   * Returns a copy of the internal properties map. The properties can contain 
   * details about the highlight author or the highlight modification timestamp, 
   * depending on the highlight type:
   * <br/>
   * <ul>
   * <li>The properties names for <i>change tracking highlights</i> are:
   * {@link AuthorPersistentHighlightConstants#AUTHOR_NAME_ATTRIBUTE} and 
   * {@link AuthorPersistentHighlightConstants#MODIFICATION_TIME}.
   * </li>
   * <li>For <i>comment highlights</i> the properties names are: 
   * {@link AuthorPersistentHighlightConstants#AUTHOR_NAME_ATTRIBUTE},
   * {@link AuthorPersistentHighlightConstants#MODIFICATION_TIME} and 
   * {@link AuthorPersistentHighlightConstants#COMMENT_ATTRIBUTE}</li>
   * <li>The properties for <i>custom persistent highlights</i> are specified 
   * when the highlight is added (@see {@link AuthorPersistentHighlighter#addHighlight(int, int, LinkedHashMap)}) 
   * and can be changed using the {@link AuthorPersistentHighlighter#setProperties(AuthorPersistentHighlight, LinkedHashMap)}
   * method.
   * </li>
   * </ul>
   * 
   * @return The copy of highlight properties.
   */
  public LinkedHashMap<String, String> getClonedProperties();
  
  /**
   * The persistent highlight type.
   * 
   * @return The {@link PersistentHighlightType} corresponding to this author 
   * persistent highlight.
   */
  public PersistentHighlightType getType();
}
