/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.highlights;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.view.graphics.Color;
import ro.sync.exml.view.graphics.Graphics;

/**
 * Painter that can be used to customize the way that a highlight is displayed by setting
 * custom text decoration, text decoration stroke, background color or stroke color.  
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class ColorHighlightPainter implements TextForegroundHighlighterPainter {

  /**
   * The color.
   */
  private Color color = Color.COLOR_RED_DARKER;
  
  /**
   * The decoration added to text.
   */
  public static enum TextDecoration {
    /**
     * Normal text. No decoration.
     */
    NONE,
    /**
     * A line is drawn below the text.
     */
    UNDERLINE,
    /**
     * A line is drawn through the text.
     */
    STRIKEOUT,
    /**
     * Similar to the {@link #UNDERLINE} decoration, except that the line is drawn
     * a bit lower, in the lower part of the highlight rectangle.  
     */
    BOTTOM
  }
  
  /**
   * The height of the highlight line. This may be smaller than the total height. 
   * If it is, the extra space will remain under the line.
   */
  private int height = -1;
  
  /**
   * The height of the highlight.
   */
  private int totalHeight = 1;
  
  /**
   * The text decoration.
   */
  private TextDecoration decoration = TextDecoration.UNDERLINE;

  /**
   * The stroke used when the text decoration is different from {@link TextDecoration#NONE}.
   */
  private int textDecorationStroke = Graphics.STROKE_NORMAL;
  /**
   * The BG color.
   */
  private Color bgColor;
  
  /**
   * The foreground color.
   */
  private Color foregroundColor;

  /**
   * Default constructor. The color is red.
   */
  public ColorHighlightPainter() {
  }

  /**
   * Constructor. 
   * 
   * @param color The color to use for highlight.
   * @param  height The height of the highlight line. 
   * This may be smaller than the total height. If it is, the extra space will remain under the line.
   * @param totalHeight The height of the highlight.
   */
  public ColorHighlightPainter(Color color, int height, int totalHeight) {
    this.color = color;
    this.height = height;
    this.totalHeight = totalHeight;
  }

  /**
   * @see ro.sync.ecss.extensions.api.highlights.HighlightPainter#paint(ro.sync.ecss.extensions.api.highlights.HighlightPainterInfo)
   */
  @Override
  public void paint(HighlightPainterInfo pi) {
    int strokeWidth = height;
    if(strokeWidth == -1) {
      //The height is not specified so we'll have to determine it from the font size.
      strokeWidth = (int) Math.max(1, Math.round(((double)pi.getFontSize())/16));
      totalHeight = strokeWidth + 1;
    }

    //Strike out or underline.
    if(decoration != TextDecoration.NONE) {
      pi.getGraphics().setDrawColor(color);
      int y = pi.getOrigin().y;
      if(decoration == TextDecoration.STRIKEOUT) {
        //Strike out.
        y += pi.getTextYPadding() + pi.getBaseLine() - pi.getFontAscent()/3;
      } else if(decoration == TextDecoration.UNDERLINE) {
        y += pi.getTextYPadding();
        //Underline.
        if(useBaseLineForUnderline() && pi.isHighlightOverText()) {
          y += pi.getBaseLine() + 1; 
        } else {
          y += pi.getCurrentBoxHeight() - totalHeight;
        }
      } else {
        // Bottom
        y += pi.getCurrentBoxHeight() - strokeWidth - 1;
      }
      
      // Draw line
      int oldStrokeType = pi.getGraphics().getStrokeType();
      int oldStrokeWidth = pi.getGraphics().getStrokeWidth();
      
      pi.getGraphics().setStroke(strokeWidth, textDecorationStroke);      
      pi.getGraphics().drawLine(pi.getOrigin().x + pi.getRelativeX(),y , pi.getOrigin().x + pi.getRelativeX() + pi.getLength(), y);
      
      pi.getGraphics().setStroke(oldStrokeWidth, oldStrokeType);
    }
        
    if(bgColor != null) {
      //Also fill background.
      Color toUseForBG = bgColor;
      if(pi.isHighlightOverImage()) {
        if(bgColor.getAlpha() > 50) {
          toUseForBG = new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 
              //EXM-23830 We need to force some high alpha, otherwise the image will be fully obscured.
              50);
        }
      }
      pi.getGraphics().setFillColor(toUseForBG);
      pi.getGraphics().fillRect(pi.getOrigin().x + pi.getRelativeX(), pi.getOrigin().y, 
          pi.getLength(), pi.getCurrentBoxHeight());
    }
  }

  /**
   * Set the color used for decoration (strike out or underline)
   * @param c  The decoration color.
   */
  public void setColor(Color c) {
    this.color = c; 
  }
  
  /**
   * Set the text decoration. If is set to {@link TextDecoration#NONE} no line will be drawn.
   * 
   * @param decoration The new text decoration.
   */
  public void setTextDecoration(TextDecoration decoration) {
    this.decoration = decoration;
  }
  
  
  /**
   * @param bgColor The background color to set.
   */
  public void setBgColor(Color bgColor) {
    this.bgColor = bgColor;
  }
  
  /**
   * @return true if use the base line for underlining
   */
  public boolean useBaseLineForUnderline() {
    return false;
  }

  /**
   * Set the text decoration stroke.
   * 
   * @param stroke The new Stroke type. Constants are defined in {@link Graphics}.
   */
  public void setTextDecorationStroke(int stroke) {
    this.textDecorationStroke = stroke;
  }
  
  /**
   * @param strikeOut Set this highlight as strike out.
   * 
   * @deprecated Use {@link #setTextDecoration(TextDecoration)} instead.
   */
  @Deprecated
  public void setStrikeOut(boolean strikeOut) {
    if (strikeOut) {
      setTextDecoration(TextDecoration.STRIKEOUT);
    } else {
      setTextDecoration(TextDecoration.UNDERLINE);
    }
  }
  
  /**
   * @return Returns the background color.
   */
  public Color getBgColor() {
    return bgColor;
  }
  
  /**
   * @return Returns the color used for decoration (strike out or underline)
   */
  public Color getColor() {
    return color;
  }

  /**
   * Set the text foreground color.
   * 
   * @param foregroundColor The foreground color to set.
   * 
   * @since 13.2
   */
  public void setTextForegroundColor(Color foregroundColor) {
    this.foregroundColor = foregroundColor;
  }

  /**
   * Get the text foreground color.
   * 
   * @since 13.2
   * @see ro.sync.ecss.extensions.api.highlights.TextForegroundHighlighterPainter#getTextForegroundColor()
   */
  @Override
  public Color getTextForegroundColor() {
    return foregroundColor;
  }
}
