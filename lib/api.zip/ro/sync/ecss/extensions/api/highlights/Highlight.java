package ro.sync.ecss.extensions.api.highlights;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * The highlight interface.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface Highlight {

  /**
   * Gets the starting model offset for the highlight.
   *
   * @return the starting offset >= 0
   */
  public int getStartOffset();

  /**
   * Gets the ending model offset for the highlight.
   *
   * @return the ending offset >= 0 (inclusive).
   */
  public int getEndOffset();
  
  /**
   * @return Additional data for the highlight.
   */
  public Object getAdditionalData();

  /**
   * Gets the painter for the highlighter.
   *
   * @return the painter
   */
  public HighlightPainter getPainter();
}