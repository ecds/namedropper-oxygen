package ro.sync.ecss.extensions.api.highlights;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;


/**
 * Highlight renderer.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface HighlightPainter {

  /**
   * Renders the highlight.
   * @param pi Information used by highlight
   */
  public void paint(HighlightPainterInfo pi);
}