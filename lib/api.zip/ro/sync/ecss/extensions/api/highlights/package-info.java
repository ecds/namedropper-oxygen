/**
 * API used to interact with persistent (change tracking, comments, user persistent highlights)
 * and non persistent highlights in the Author page
 */
package ro.sync.ecss.extensions.api.highlights;