/**
 * Schema aware processing (smart typing, smart delete, smart paste).	 
 */
package ro.sync.ecss.extensions.api.schemaaware;