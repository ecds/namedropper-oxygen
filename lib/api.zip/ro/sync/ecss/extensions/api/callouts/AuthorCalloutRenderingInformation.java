/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.callouts;

import java.util.Map;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.view.graphics.Color;

/**
 * The callouts are representations of Track Changes insert and delete highlights, 
 * review comment highlights and custom review highlights in Author mode.
 * <br/>
 * By default, the callouts visibility in Author mode is controlled from Oxygen
 * Preferences but it can be changed by using the {@link AuthorCalloutsController} methods.
 * <br/>
 * The AuthorReviewCalloutInformation object holds the data that will be rendered
 * as a callout, in Author mode. 
 * <br/>
 * To render a custom highlight as a callout in Author mode, a callouts information 
 * provider must be set from 
 * {@link AuthorCalloutsController#setCalloutsRenderingInformationProvider(CalloutsRenderingInformationProvider)} method.
 * 
 * @since 14
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p>
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)  
public abstract class AuthorCalloutRenderingInformation {

  /**
   * Provides the reviewer author name that will be presented in the callout header part. 
   * 
   * @return the reviewer author name.
   * Can be <code>null</code> if the author is not relevant.
   */
  public abstract String getAuthor();

  /**
   * Provides the review creation or modification time. 
   * <br/>
   * 
   * @return the review creation or modification time. 
   * Returns the number of milliseconds since January 1, 1970, 00:00:00 GMT
   * <p>
   * Can be <code>-1</code> if the modification time was not set. In this case, 
   * the callout will not present any information regarding the review creation or
   * modification time. 
   */
  public abstract long getTimestamp();
  
  /**
   * Provides the review comment that will be presented in the callout content part.
   * This could be a part of the real comment stored in the change or persistent highlight. 
   * 
   * @param limit the suggested text limit (in characters). This value comes from the 
   * Callouts Options (user preferences). Examples: 80 or 160 characters.
   * 
   * @return the review comment.
   * Can be <code>null</code> if a comment is not available for this callout.
   */
  public abstract String getComment(int limit);  

  /**
   * Provides a section from the document content that is covered by this callout.
   * This will be presented in the content part of the callout. Note that it is not
   * necessary to provide the entire content related to the callout. 
   * 
   * @param limit the suggested text limit (in characters). This value comes from the 
   * Callouts Options (user preferences). Examples: 80 or 160 characters.
   * 
   * @return the limited document content. Can be <code>null</code> if the 
   * content is not relevant for the callout. 
   */
  public abstract String getContentFromTarget(int limit);
    
  /**
   * Provides the review additional data that will be presented in the callout content part. 
   * <br/>
   * The callout additional data must be provided as a map between data type and actual callout data.
   * It will be rendered inside the callout as "data_type: data" strings, separated by new lines. 
   *  
   * @return The review additional data.
   * Can be <code>null</code> if there is no additional information available for this review. 
   */
  public abstract Map<String, String> getAdditionalData();
  
  /**
   * Provides a human readable string representing the callout type that will be rendered
   * as a description of the callout, in the header part. 
   * 
   * @return The human readable string representing the callout type or <code>null</code>
   * if the type is not relevant.
   */
  public abstract String getCalloutType();

  /**
   * Provides color for styling the associated callout box.
   * 
   * @return The color to be used for rendering the callout. Can be
   * <code>null</code> for the default. 
   */
  public abstract Color getColor();
}
