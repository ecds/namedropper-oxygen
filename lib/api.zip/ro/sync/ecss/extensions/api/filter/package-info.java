/**
 * API used to filter the Author content.
 */
package ro.sync.ecss.extensions.api.filter;