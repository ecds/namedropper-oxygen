/*
 *  The Syncro Soft SRL License
 *
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  5. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 *  Descriptor of the plugin.<p>
 * A plugin is characterised by:<p>
 *    - name          The plugin name as it will appear in the oXygen menus.<p>
 *    - description   A short description of what the plugin does.<p>
 *    - vendor        The name of the vendor.<p>
 *    - version       The current version.<p>
 *    - baseDir       The base dir used for file crreation.<p>
 *    - extensions    A set of extensions.
 * 
 * @author mircea
 * 
 */
public class PluginDescriptor {
  /**
   *  Selection processor extension type.
   */
  public static final String SELECTION_PROCESSOR = "selectionProcessor";
  /**
   *  General extension type.
   */
  public static final String GENERAL_EXTENSION = "generalExtension";
  /**
   * Document processor extension type.
   */
  public static final String DOCUMENT_PROCESSOR = "documentProcessor";
  /**
   * URL stream handler extension type.
   * @deprecated
   */
  @Deprecated
  public static final String URL_STREAM_HANDLER = "URLStreamHandler";
  /**
   * URL stream handler extension type.
   */
  public static final String URL_HANDLER = "URLHandler";
  /**
   * Targeted URL stream handler extension type.
   */
  public static final String TARGETED_URL_HANDLER = "TargetedURLHandler";
  /**
   * URL stream handler extension type.
   */
  public static final String URL_CHOOSER = "URLChooser";
  /**
   * URL stream handler extension type.
   */
  public static final String URL_CHOOSER_TOOLBAR = "URLChooserToolbar";
  /**
   * The startup extension.
   */
  public static final String COMPONENTS_VALIDATOR_EXTENSION = "componentsValidator";
  /**
   * Open redirector plugin type.
   */
  public static final String OPEN_REDIRECTOR = "OpenRedirect";
  /**
   * Workspace access plugin type.
   */
  public static final String WORKSPACE_ACCESS = "WorkspaceAccess";
  
  /**
   * A lock handler factory. 
   */
  public static final String LOCK_HANDLER_FACTORY = "LockHandlerFactory";
  
  /**
   *  The extensions hashmap for the current plugin.
   */
  private HashMap<String, PluginExtension> extensions = new HashMap<String, PluginExtension>();
  /**
   *  Maps an extension type to a keyboard shortcut.
   */
  private HashMap<String, String> extensionTypeToKeyShortcut = new HashMap<String, String>();

  /** @link dependency 
   * @stereotype stores*/
  /*#PluginExtension lnkPluginExtension;*/

  /**
   * The description of the plugin.
   */
  private String description;

  /**
   * The name of the plugin.
   */
  private String name;

  /**
   * The vendor of the plugin.
   */
  private String vendor;

  /**
   * The version of the plugin.
   */
  private String version;

  /**
   * The base directory of the plugin.
   */
  private File baseDir;
  
  /**
   * The list of contributed views
   */
  private List<PluginContributedView> contributedViews;
  
  /**
   * The list of contributed toolbars.
   */
  private List<PluginContributedToolbar> contributedToolbars;
  /**
   * An unique ID that identifies this plugin amongst all the loaded plugins.
   */
  private String id;

  /**
   *  Get the extension corresponding to the specified key.<p>
   * Available extensions for the moment are: SELECTION_PROCESSOR & GENERAL_EXTENSION.
   * 
   *@param  key   The extension key.
   *@return       The extension corresponding to the specified key.
   */
  public PluginExtension getExtension(String key) {
    return extensions.get(key);
  }
  
  /**
   *  Get the extension corresponding to the specified key.<p>
   * Available extensions for the moment are: SELECTION_PROCESSOR & GENERAL_EXTENSION.
   * 
   *@param  key   The extension key.
   *@return       The shortcut key corresponding to the specified extension type key.
   */
  public String getExtensionShortcut(String key) {
    return extensionTypeToKeyShortcut.get(key);
  }

  /**
   *  Put an extension corresponding to the specified key.
   * Avaible extensions for the moment are: SELECTION_PROCESSOR & GENERAL_EXTENSION.
   * 
   *@param  key         The extension key.
   *@param  extension   The extension corresponding to the specified key.
   */
  public void putExtension(String key, PluginExtension extension) {
    extensions.put(key, extension);
  }
  
  /**
   *  Put an extension corresponding to the specified key.
   * Avaible extensions for the moment are: SELECTION_PROCESSOR & GENERAL_EXTENSION.
   * 
   *@param  key         The extension key.
   *@param  shortcutKey   The shortcut key corresponding to the specified key.
   */
  public void putExtensionShortcut(String key, String shortcutKey) {
    extensionTypeToKeyShortcut.put(key, shortcutKey);
  }

  /**
   *  Get the description of the plugin.
   * 
   *@return   The description of the plugin.
   */
  public String getDescription() {
    return description;
  }

  /**
   *  Set the description of the plugin.
   *
   *@param  description  The description of the plugin.
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   *  Gets the name of the plugin.
   * 
   *@return   The name of the plugin.
   */
  public String getName() {
    return name;
  }

  /**
   *  Set the name of the plugin.
   * 
   *@param  name   The name of the plugin.
   */
  public void setName(String name) {
    if (name == null) {
      throw new IllegalArgumentException("Name cannot be null");
    }
    this.name = name;
  }
  

  /**
   * Sets the ID of the plugin. Empty string is treated as no ID.
   * 
   * @param id ID of the plugin.
   */
  public void setID(String id) {
    this.id = id != null && id.length() > 0 ? id : null;
  }
  
  /**
   * @return Returns the id of the plugin or <code>null</code> if the plugin doesn't 
   * have an ID.
   */
  public String getID() {
    return id;
  }

  /**
   *  Get the vendor of the plugin.
   * 
   *@return   The vendor name.
   */
  public String getVendor() {
    return vendor;
  }

  /**
   *  Set the vendor of the plugin.
   *
   *@param  vendor   The vendor of the plugin.
   */
  public void setVendor(String vendor) {
    this.vendor = vendor;
  }

  /**
   *  Get the version of the plugin.
   * 
   *@return   The plugin version.
   */
  public String getVersion() {
    return version;
  }

  /**
   *  Set the version of the plugin.
   *
   *@param  version  The version of the plugin.
   */
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   *  Get the base directory of the plugin.
   * 
   *@return   The plugin base directory.
   */
  public File getBaseDir() {
    return baseDir;
  }

  /**
   *  Set the base dir of the plugin.
   *
   *@param  baseDir  The base dir of the plugin.
   */
  public void setBaseDir(File baseDir) {
    this.baseDir = baseDir;
  }
  
  /**
   * Add a contributed view
   * @param viewInfo Information about the view
   */
  public void addPluginContributedView(PluginContributedView viewInfo) {
    if(contributedViews == null) {
      contributedViews = new ArrayList<PluginContributedView>();
    }
    contributedViews.add(viewInfo);
  }
  
  /**
   * @return Returns the contributedViews.
   */
  public List<PluginContributedView> getContributedViews() {
    return contributedViews;
  }
  
  /**
   * Add a toolbar.
   *
   * @param toolbarInfo Information about the new toolbar.
   */
  public void addPluginContributedToolbar(PluginContributedToolbar toolbarInfo) {
    if (contributedToolbars == null) {
      contributedToolbars = new ArrayList<PluginContributedToolbar>();
    }
    contributedToolbars.add(toolbarInfo);
  }
  
  /**
   * Gets the toolbars contributed by this plugin.
   *
   * @return The list of contributed toolbars.
   */
  public List<PluginContributedToolbar> getContributedToolbars() {
    return contributedToolbars;
  }
  
  /**
   *  The string representation of the plugin descriptor.
   * 
   *@return   The string representation.
   */
  @Override
  public String toString() {
    StringBuffer buf = new StringBuffer();
    buf.append("Name: ");
    buf.append(name);
    buf.append("\nDescription: ");
    buf.append(description);
    buf.append("\nVersion: ");
    buf.append(version);
    buf.append("\nVendor: ");
    buf.append(vendor);
    buf.append("\nBaseDir: ");
    buf.append(baseDir);
    buf.append("\nExtensions: {");
    Iterator iter = extensions.keySet().iterator();
    while (iter.hasNext()) {
      String key = (String) iter.next();
      String extensionName = extensions.get(key).getClass().getName();
      buf.append('\n');
      buf.append(key);
      buf.append(" - ");
      buf.append(extensionName);
    }
    buf.append("\n}");
    
    return buf.toString();
  }
}
