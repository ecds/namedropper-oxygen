@SkipObfuscate(classes = SkipLevel.NOT_SPECIFIED, fields = SkipLevel.NOT_SPECIFIED, methods = SkipLevel.PUBLIC)
package ro.sync.exml.plugin.document;

import ro.sync.annotations.obfuscate.SkipObfuscate;
import ro.sync.annotations.obfuscate.SkipLevel;