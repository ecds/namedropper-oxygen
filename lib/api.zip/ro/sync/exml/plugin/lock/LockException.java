/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.plugin.lock;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Thrown when could not lock or unlock properly
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class LockException extends Exception {

  /**
   * True if the exception occurred while trying to acquire the lock.
   */
  private final boolean acquire;
  /**
   * The detailed exception message.
   */
  private final String detailedMessage;

  /**
   * Constructor.
   * 
   * @param message The error message.
   * @param acquire True if the exception occurred while trying to acquire the lock.
   * @param detailedMessage The detailed exception message.
   */
  public LockException(String message, boolean acquire, String detailedMessage) {
    super(message);
    this.acquire = acquire;
    this.detailedMessage = detailedMessage;
  }

  /**
   * @return The main cause for the exception.
   */
  public String getCauseMessage() {
    return acquire ? "Problem while trying to acquire lock"
        : "Problem while trying to unlock";
  }
  /**
   * @see java.lang.Throwable#getMessage()
   */
  public String getMessage() {
    return getCauseMessage() + ":\n\n" + super.getMessage();
  };
  
  /**
   * @return Returns the detailedMessage.
   */
  public String getDetailedMessage() {
    return detailedMessage;
  }
  
  /**
   * @param close <code>true</code> if must advise to close the editor. Otherwise will advise 
   * to cancel the operation.
   * 
   * @return Error message to show to user on open if lock failed.
   */
  public String getOpenErrorMessage(boolean close) {
    StringBuffer messageBuffer = new StringBuffer(getMessage());
    messageBuffer.append("\nIf the current lock expires").
    append(" during editing you could overwrite changes made by the current lock owner.\n");
    if (close) {
      messageBuffer.append("It is strongly recommended to close the editor.");
    } else {
      messageBuffer.append("It is strongly recommended to cancel the open operation.");
    }
    return messageBuffer.toString();
  }
}