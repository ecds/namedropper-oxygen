/*
 *  The Syncro Soft SRL License
 *
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  5. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.plugin;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import ro.sync.exml.OxygenSystemProperties;
import ro.sync.exml.plugin.urlstreamhandler.TargetedURLStreamHandlerPluginExtension;
import ro.sync.exml.plugin.urlstreamhandler.URLStreamHandlerPluginExtension;
import ro.sync.io.ExceptCVSAndSVNFileFilter;
import ro.sync.util.ClassLoadersRegistry;
import ro.sync.util.PreferencesDirectoryDetector;
import ro.sync.util.SortedList;

/**
 *  The plugin manager is responsable to find and instantiate plugins.
 *
 *@author     george
 *@author     mircea
 *@created     September 9, 2002
 *@version    $Revision: 1.38 $
 */
public class PluginManager {
  /**
   * Marker exception that signals the fact that a plugin was already loaded.
   * Loading the plugin twice would lead to instability so the the plugin will not 
   * be loaded the second time.
   * 
   * @author alex_jitianu
   */
  private class PluginAlreadyLoadedException extends Exception {

    /**
     * Constructor.
     * 
     * @param pluginId The id of the plugin that was already loaded.
     */
    public PluginAlreadyLoadedException(String pluginId) {
      super(pluginId);
    }
  }
  
  /**
   *  Logger for logging.
   */
  private static final Logger logger = Logger.getLogger(PluginManager.class.getName());

  /**
   *  The plugin manager's instance.
   */
  public static PluginManager instance;

  /**
   *  The list with plugins instances.
   */
  private List<Plugin> plugins = new Vector<Plugin>();

  /**
   *  The list with exception raised during plugin loading process.
   */
  private List<String> exceptions = new Vector<String>();

  /**
   *  The directory where the plugins are stored.
   */
  private static String defaultPluginsDir;
  
  /**
   * The directories where plugins reside.
   */
  private final List<File> allPluginDirs = new ArrayList<File>();

  /**
   *  Present the list of warnings?
   */
  private boolean showWarnings = true;
  
  /**
   * True if the plugin manager is about to be created but the process was not yet finished.
   * See EXM-10691.
   */
  private static boolean updateInProgress = false;

  /**
   * Disable/enable late delegation class loader for tests
   */
  private static boolean disableLateDelegationCL = false;
  
  /**
   * Map between protocol and targeted URL stream handlers for that protocol.
   */
  private Map<String, List<Plugin>> targetedURLHandlersMap = null;

  /**
   *  This method is used only for tests.
   *
   * @param pluginsDir The custom plugins directory.
   */
  public static void setPluginsDir(String pluginsDir) {
    if(pluginsDir != null) {
      System.setProperty(OxygenSystemProperties.COM_OXYGENXML_EDITOR_PLUGINS_DIR, pluginsDir);
    } else {
      //Remove it 
      System.getProperties().remove(OxygenSystemProperties.COM_OXYGENXML_EDITOR_PLUGINS_DIR);
    }
  }

  /** @link dependency
   * @stereotype loads*/
  /*#Plugin lnkPluginDescriptor;*/

  /**
   *  Private constructor for avoiding outside instanciating.
   */
  private PluginManager() {
    try {
      updateInProgress = true;
      //EXM-21917 Do not use a default for the plugins directory.
      defaultPluginsDir = System.getProperty(OxygenSystemProperties.COM_OXYGENXML_EDITOR_PLUGINS_DIR);
      if(defaultPluginsDir != null) {
        // Add the plugins directory from user.prefs.
        File[] userPrefsPluginsDirs = getUserPrefsPluginsDirs();
        // The user.prefs  must be added first. See EXM-24128.
        if (userPrefsPluginsDirs != null) {
          allPluginDirs.addAll(Arrays.asList(userPrefsPluginsDirs));
        }
        
        // The default must be added last. See EXM-24128.
        allPluginDirs.add(new File(defaultPluginsDir));
        
        showWarnings =
          Boolean.valueOf(System.getProperty(
              OxygenSystemProperties.COM_OXYGENXML_EDITOR_PLUGINS_SHOWWARNING, "true")).booleanValue();
        updatePluginList();
      }
    } finally {
      updateInProgress = false;
    }
  }

  /**
   *  Get the singleton instance of the plugin manager.
   *
   *@return    The instance value
   */
  public static PluginManager getInstance() {
    if (instance == null) {
      instance = new PluginManager();
    }
    return instance;
  }
  
  /**
   * Gets the plugins root directory from user preferences.
   * 
   * @return The directory from the user preferences where we look for plugins. 
   */
  public static File getUserPrefsPluginsDir() {
    File extensionsPrefsDirectory = PreferencesDirectoryDetector.getInstance().getCurrentExtensionsDirectory();
    File additionalPluginsDir = new File(extensionsPrefsDirectory, "plugins");
    
    return additionalPluginsDir;
  }

  /**
   * Get plugins directories from the user preferences.
   * 
   * @return Plugins directories from the user preferences.
   */
  public static File[] getUserPrefsPluginsDirs() {
    File rootPluginsDir = getUserPrefsPluginsDir();
    return rootPluginsDir.listFiles(new ExceptCVSAndSVNFileFilter() {
      @Override
      public boolean accept(File pathname) {
        return pathname.isDirectory() && super.accept(pathname);
      }
    });
  }

  /**
   *  Get the registered plugins.
   *
   *@return             a List of Plugin objects.
   */
  public List<Plugin> getPlugins() {
    return plugins;
  }
  
  /**
   * Get all plugin installation directories.
   * 
   * @return All plugin installation directories.
   */
  public List<File> getAllPluginDirs() {
    return allPluginDirs;
  }
  
  /**
   * Get all contributed view IDs.
   *
   * @return A list with all contributed view IDs.
   */
  public List<PluginContributedView> getAllContributedViewIDs(){
    List<PluginContributedView> allContributedViewIDs = new ArrayList<PluginContributedView>();
    //Add views.
    for (Iterator iter = plugins.iterator(); iter.hasNext();) {
      Plugin plugin = (Plugin) iter.next();
      List<PluginContributedView> contributedViewIDs = plugin.getDescriptor().getContributedViews();
      if(contributedViewIDs != null) {
        for (int i = 0; i < contributedViewIDs.size(); i++) {
          allContributedViewIDs.add(contributedViewIDs.get(i));
        }
      }
    }
    return allContributedViewIDs;
  }
  
  /**
   * Get the plugins directory.
   * 
   * @return  The plugins directory.
   */
  public String getDefaultPluginsDir() {
    return defaultPluginsDir;
  }

  /**
   * Disable/enable late delegation class loader for tests
   * @param disableLateDelegationCL <code>true</code> to disable late delegation
   */
  public static void disableLateDelegationCLForTests(boolean disableLateDelegationCL) {
    PluginManager.disableLateDelegationCL = disableLateDelegationCL;
  }
  
  /**
   *  Get the exceptions raised durring the plugin initialization.
   *
   *@return             a List of exceptions.
   */
  public List getExceptions() {
    if (showWarnings) {
      return exceptions;
    } else {
      return new ArrayList(0);
    }
  }

  /**
   * Updates the list of plugins.
   *
   * @return A list with updated instances.
   */
  private List<Plugin> updatePluginList() {
    // Obtain the list of presumptive plugins...
    List<File> pluginDirs = getPluginDirs();

    // Iterate over it.
    Iterator<File> iter = pluginDirs.iterator();
    HashSet<String> collectedViewIds = new HashSet();
    HashSet<String> collectedToolbarIds = new HashSet();
    Set<String> loadedPluginIds = new HashSet<String>();
    while (iter.hasNext()) {
      File pluginDir = iter.next();

      // Obtain the plugin from the specified directory.
      Plugin plugin = getPlugin(
          pluginDir, 
          collectedViewIds, 
          collectedToolbarIds,
          loadedPluginIds);

      if (plugin != null) {
        if (logger.isDebugEnabled()) {
          logger.debug("Adding plugin: " + plugin.getDescriptor());
        }
        plugins.add(plugin);
      }
    }
    return plugins;
  }

  /**
   * Gets a plugin.
   *
   * @param  pluginDir         The directory where the plugin is located.
   * @param  collectedViewIds  The collected view IDs.
   * @param loadedPluginIds    The ids of all the already loaded plugins.
   *
   * @return The plugin obtained from the specified plugin directory.
   */
  private Plugin getPlugin(
      File pluginDir, 
      HashSet<String> collectedViewIds, 
      HashSet<String> collectedToolbarIds, 
      Set<String> loadedPluginIds) {
    Plugin plugin = null;

    try {
      if(
          //Disable running some plugins from the classes. 
          !new File(pluginDir, "plugin.disable").exists()) {
          //Some error reporting
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(true);
        DocumentBuilder docBuilder = dbf.newDocumentBuilder();
        docBuilder.setErrorHandler(
            new ErrorHandler() {
              @Override
              public void warning(SAXParseException exception) throws SAXException {
                logger.warn(exception.getMessage());
                if (logger.isDebugEnabled()) {
                  logger.debug(exception, exception);
                }
              }
              @Override
              public void fatalError(SAXParseException exception) throws SAXException {
                logger.warn(exception.getMessage());
                if (logger.isDebugEnabled()) {
                  logger.debug(exception, exception);
                }
              }
              @Override
              public void error(SAXParseException exception) throws SAXException {
                logger.warn(exception.getMessage());
                if (logger.isDebugEnabled()) {
                  logger.debug(exception, exception);
                }
              }
            });
        // If we parse a plugin.xml from user.prefs directory use the plugin.dtd 
        // that valides the xml from default plugins directory.
        // A plugin.dtd might not exist in user.prefs directory.
        docBuilder.setEntityResolver(new EntityResolver() {
          @Override
          public InputSource resolveEntity(String publicId, String systemId) throws SAXException,
              IOException {
            if (systemId != null && systemId.endsWith("/plugin.dtd")) {
              return new InputSource(new File(defaultPluginsDir, "plugin.dtd").toURL().toString());
            }
            return null;
          }
        });
        Document pluginDoc =  docBuilder.parse(new File(pluginDir, "plugin.xml"));
        Element pluginRoot = pluginDoc.getDocumentElement();
        
        if ("plugin".equals(pluginRoot.getNodeName())) {
          //EXM-19923 Developer may choose late delegation
          boolean lateDelegation = false;
          PluginDescriptor descriptor = new PluginDescriptor();
          // Set the descriptor fields.
          descriptor.setBaseDir(pluginDir);
          descriptor.setDescription(pluginRoot.getAttribute("description"));
          descriptor.setName(pluginRoot.getAttribute("name"));
          String id = pluginRoot.getAttribute("id");
          if (id != null && id.length() != 0) {
            // EXM-24128 Ensure we don't load the same plugin twice.
            if (loadedPluginIds.contains(id)) {
              // Avoid loading the same plugin twice.
              throw new PluginAlreadyLoadedException(id);
            } else {
              // It is the first time this plugin gets loaded.
              loadedPluginIds.add(id);
              descriptor.setID(id);
            }
          }
          
          descriptor.setVendor(pluginRoot.getAttribute("vendor"));
          descriptor.setVersion(pluginRoot.getAttribute("version"));
          
          //EXM-19923 Developer may choose late delegation
          String clType = pluginRoot.getAttribute("classLoaderType");
          if("preferReferencedResources".equals(clType)) {
            lateDelegation = true;
          }
          
          // Find libraries to be loaded.
          NodeList libraries = pluginRoot.getElementsByTagName("library");
          ClassLoader classLoader;
          URL[] urls = new URL[0];
          
          if (libraries != null && libraries.getLength() > 0) {
            List<URL> urlList = new Vector<URL>();
            for (int i = 0; i < libraries.getLength(); i++) {
              String libraryPath = ((Element) libraries.item(i)).getAttribute("name");
              urlList.add(getLibraryURL(pluginDir, libraryPath));
            }
            if (logger.isDebugEnabled()) {
              logger.debug("The URL list is: " + urlList);
            }
            urls = new URL[urlList.size()];
            for (int i = 0; i < urlList.size(); i++) {
              urls[i] = urlList.get(i);
            }
          }
          // Build the new classLoader from the specified libraries if any, and the used classLoader.
          classLoader = ClassLoadersRegistry.requestClassLoader(
              this.getClass().getClassLoader(),
              urls,
              lateDelegation && !disableLateDelegationCL ? ClassLoadersRegistry.LATE_CL_TYPE
                                                         : ClassLoadersRegistry.URL_CL_TYPE);
          
          // Build extension of the plugin. If the plugin has no extensions specified, then it won't
          // be initialized.
          NodeList extensions = pluginRoot.getElementsByTagName("extension");
          
          if (extensions != null && extensions.getLength() > 0) {
            for (int i = 0; i < extensions.getLength(); i++) {
              Element ext = (Element) extensions.item(i);
              String type = ext.getAttribute("type");
              String className = ext.getAttribute("class");
              
              Class extension = classLoader.loadClass(className);
              try {
                descriptor.putExtension(
                    type,
                    (PluginExtension) extension.getConstructor(new Class[0]).newInstance(new Object[0]));
              } catch (NoSuchMethodException ex) {
                addException(className, ex);
              } catch (java.lang.reflect.InvocationTargetException ex) {
                addException(className, ex);
              } catch (IllegalAccessException ex) {
                addException(className, ex);
              } catch (InstantiationException ex) {
                addException(className, ex);
              } catch (ClassCastException ex) {
                addException(className, ex);
              }
              String keySequence = ext.getAttribute("keyboardShortcut");
              if(keySequence != null && keySequence.length() > 0) {
                descriptor.putExtensionShortcut(type, keySequence);
              }
            }
            
            //All provided view IDs
            NodeList views = pluginRoot.getElementsByTagName("view");
            
            //Iterate the contributed view IDs.
            Set<String> currentViewIds = new HashSet<String>();
            if (views != null && views.getLength() > 0) {
              for (int i = 0; i < views.getLength(); i++) {
                Element elem = ((Element) views.item(i));
                String viewID = elem.getAttribute("id");
                if(viewID != null) {
                  if(collectedViewIds.contains(viewID) || currentViewIds.contains(viewID)) {
                    //Conflict. Disable loading of this plugin.
                    throw new Exception("Contributed view ID " + viewID + " is already declared.");
                  } else {
                    descriptor.addPluginContributedView(
                        new PluginContributedView(
                            viewID,
                            elem.getAttribute("initialRow"),
                            elem.getAttribute("initialSide")));
                    currentViewIds.add(viewID);
                  }
                }
              }
            }
            //Add the current view IDs
            collectedViewIds.addAll(currentViewIds);
            
            //All provided toolbar IDs
            NodeList toolbars = pluginRoot.getElementsByTagName("toolbar");
            
            //Iterate the contributed toolbar IDs.
            Set<String> currentToolbarIds = new HashSet<String>();
            if (toolbars != null && toolbars.getLength() > 0) {
              for (int i = 0; i < toolbars.getLength(); i++) {
                Element elem = ((Element) toolbars.item(i));
                String toolbarID = elem.getAttribute("id");
                if(toolbarID != null) {
                  if(collectedToolbarIds.contains(toolbarID) || currentToolbarIds.contains(toolbarID)) {
                    //Conflict. Disable loading of this plugin.
                    throw new Exception("Contributed toolbar ID " + toolbarID + " is already declared.");
                  } else {
                    descriptor.addPluginContributedToolbar(
                        new PluginContributedToolbar(
                            toolbarID,
                            elem.getAttribute("initialRow"),
                            elem.getAttribute("initialSide")));
                    currentToolbarIds.add(toolbarID);
                  }
                }
              }
            }
            //Add the current toolbar IDs
            collectedToolbarIds.addAll(currentToolbarIds);
            
            String pluginClassName = pluginRoot.getAttribute("class");
            Class pluginClass = classLoader.loadClass(pluginClassName);
            
            try {
              plugin =
                (Plugin) pluginClass.getConstructor(
                    new Class[] { PluginDescriptor.class }).newInstance(new Object[] { descriptor });
            } catch (NoSuchMethodException ex) {
              addException(pluginClassName, ex);
            } catch (java.lang.reflect.InvocationTargetException ex) {
              addException(pluginClassName, ex);
            } catch (IllegalAccessException ex) {
              addException(pluginClassName, ex);
            } catch (InstantiationException ex) {
              addException(pluginClassName, ex);
            } catch (ClassCastException ex) {
              addException(pluginClassName, ex);
            }
          }
        }
      }
    } catch (PluginAlreadyLoadedException e) {
      logger.warn("Plugin already loaded. Skip plugin " + e.getMessage() + " from " + pluginDir.getAbsolutePath());
    } catch (Throwable t) {
      addException(pluginDir.getPath(), t);
    }

    return plugin;
  }

  /**
   * Gets the url for a library path. The path can be relative value or an 
   * absolute file/URL. 
   * 
   * @param pluginDir The directory where the plugin is placed. Will be used for relative paths.
   * @param libraryPath The path of the library.
   * 
   * @return The url for the given path.
   * 
   * @throws MalformedURLException Unable to build an URL form the given path.
   */
  static URL getLibraryURL(File pluginDir, String libraryPath) throws MalformedURLException {
    URL url = null;
    try {
      // Try to create the url directly from the library path
      url = new URL(libraryPath);
    } catch (MalformedURLException e) {
      File file = new File(libraryPath);
      if (file.isAbsolute()) {
        // If the file is absolute, create the url from it
        url = file.toURL();
      } else {
        // Create file from plugin's directory and library path and the get the 
        // url from that file
        File libFile = new File(pluginDir, libraryPath);
        url = libFile.toURL();
      }
    } 
    
    return url;
  }
  
  /**
   * Check if there are any custom URL handler plugin registered...
   * 
   * @param protocol The protocol to be checked.
   * @return <code>true</code> If the protocol is known, <code>false</code> otherwise.
   */
  @SuppressWarnings("deprecation")
  public boolean hasCustomURLHandlerPlugin(String protocol) {
    Iterator iter = plugins.iterator();
    while (iter.hasNext()) {
      try {
        Plugin plugin = (Plugin) iter.next();
        PluginDescriptor descriptor = plugin.getDescriptor();                

        // Check the URL_HANDLER extension point.
        PluginExtension extension = descriptor.getExtension(PluginDescriptor.URL_HANDLER);
        if (extension instanceof URLStreamHandlerPluginExtension) {
          URLStreamHandlerPluginExtension ush = (URLStreamHandlerPluginExtension) extension;
          URLStreamHandler handler = ush.getURLStreamHandler(protocol);
          if (handler != null) {
            // The plugin knows to handle this protocol.
            return true;
          }
        }
        // Check the OLD, DEPRECATED URL_STREAM_HANDLER extension point.
        extension = descriptor.getExtension(PluginDescriptor.URL_STREAM_HANDLER);
        if (extension instanceof URLStreamHandlerPluginExtension) {
          URLStreamHandlerPluginExtension ush = (URLStreamHandlerPluginExtension) extension;
          URLStreamHandler handler = ush.getURLStreamHandler(protocol);
          if (handler != null) {
            // The plugin knows to handle this protocol.
            return true;
          }
        }
      } catch(Throwable t) {
        //Problem in the plugin.
        logger.fatal(t, t);
      } 
    }
    
    return false;
  }
  
  /**
   * Get the list of targeted URL handlers plugins that can handle the specified protocol.
   * 
   * @param protocol The protocol.
   * @return The list of targeted URL handler plugins
   */
  private List<Plugin> getTargetedURLHandlersForProtocol(String protocol) {
    List<Plugin> protocolPluginsList = null;
    //EXM-10691 If the plugin manager is updating the plugins
    //no need to try to instantiate it. This could lead to recursivity.
    if(! pluginsUpdateInProgress()){
      if (targetedURLHandlersMap != null && targetedURLHandlersMap.containsKey(protocol)) {
        // Try to obtain the list from cache   
        protocolPluginsList = targetedURLHandlersMap.get(protocol);
      } else {
        // This is the first time when the list of plugin extension for this protocol
        // is retreived
        for (Plugin plugin : plugins) {
          PluginDescriptor descriptor = plugin.getDescriptor();                
          PluginExtension extension = descriptor.getExtension(PluginDescriptor.TARGETED_URL_HANDLER);

          if (extension instanceof TargetedURLStreamHandlerPluginExtension) {
            TargetedURLStreamHandlerPluginExtension pluginExtension = 
              (TargetedURLStreamHandlerPluginExtension) extension;
            try {
              if (pluginExtension.canHandleProtocol(protocol)) {
                // Found a plugin that can handle this protocol
                if (protocolPluginsList == null) {
                  // Create the list
                  protocolPluginsList = new ArrayList<Plugin>();
                }
                // Add the plugin in the plugins list
                protocolPluginsList.add(plugin);
              }
            } catch (Throwable e) {
              logger.fatal(
                  "Exception when asking the TargetedURLHandler plugin " + descriptor.getName()
                  + " if it can handle the " + protocol + " protocol.");
            }
          }
        }      
        if (targetedURLHandlersMap == null) {
          targetedURLHandlersMap = new HashMap<String, List<Plugin>>();
        }
        // Cache the list of targeted plugins that can handle this protocol
        targetedURLHandlersMap.put(protocol, protocolPluginsList);
      }
    }
    return protocolPluginsList;
  }

  /**
   *  Add exception to the exceptions list.
   */
  private void addException(String location, Throwable t) {
    t.printStackTrace();
    StringBuilder buf = new StringBuilder();

    buf.append(t.getClass().getName());
    buf.append('\n');
    if (t instanceof SAXParseException) {
      buf.append(((SAXParseException) t).getSystemId());
      buf.append(':');
      buf.append(((SAXParseException) t).getLineNumber());
      buf.append(':');
      buf.append(((SAXParseException) t).getColumnNumber());
      buf.append(':');
      buf.append(((SAXParseException) t).getMessage());
    } else {
      buf.append(location);
      buf.append(" - ");
      buf.append(t.getMessage());
    }

    if (logger.isDebugEnabled()) {
      logger.debug(t, t);
    }

    exceptions.add(buf.toString());
  }

  /**
   * Get PluginDirs.
   *
   * @return   a List with the plugin directories found.
   */
  private List<File> getPluginDirs() {
    List<File> pluginDirs = new Vector<File>();
    if (logger.isDebugEnabled()) {
      logger.debug("Plugin dir: " + defaultPluginsDir);
    }
    Comparator<File> comparator = new Comparator<File>() {
      @Override
      public int compare(File o1, File o2) {
        return o1.compareTo(o2);
      }
    };
    for (File pDir : allPluginDirs) {
      //Sort to ensure some kind of platform-independent order.
      SortedList<File> sortedList = new SortedList<File>(comparator);
      File[] pDirs = pDir.listFiles(new FileFilter() {
        @Override
        public boolean accept(File pathname) {
          return pathname.isDirectory()
          && !"CVS".equalsIgnoreCase(pathname.getName())
          && !".svn".equalsIgnoreCase(pathname.getName())
          && new File(pathname, "plugin.xml").exists();
        }
      });
      if (pDirs != null) {
        for (int i = 0; i < pDirs.length; i++) {
          sortedList.add(pDirs[i]);
          if (logger.isDebugEnabled()) {
            logger.debug(pDirs[i]);
          }
        }
      }
      pluginDirs.addAll(sortedList);
    }

    if (logger.isDebugEnabled()) {
      logger.debug("PluginDirs: " + pluginDirs);
    }

    return pluginDirs;
  }
  
  /**
   * @return <code>true</code> if the plugin manager is updating plugins and cannot yet return them.
   */
  public static boolean pluginsUpdateInProgress() {
    return updateInProgress;
  }

  /**
   * Get all contributed toolbar IDs.
   * 
   * @return All contributed toolbar IDs.
   */
  public List<PluginContributedToolbar> getAllContributedToolbarIDs(){
      List<PluginContributedToolbar> allContributedToolbarIDs =
        new ArrayList<PluginContributedToolbar>();

      // Add toolbars.
      for (Iterator iter = plugins.iterator(); iter.hasNext();) {
        Plugin plugin = (Plugin) iter.next();
        List<PluginContributedToolbar> contributedToolbarIDs =
          plugin.getDescriptor().getContributedToolbars();

        if (contributedToolbarIDs != null) {
          for (int i = 0; i < contributedToolbarIDs.size(); i++) {
            allContributedToolbarIDs.add(contributedToolbarIDs.get(i));
          }
        }
      }
      return allContributedToolbarIDs;
    }

  /**
   * Open the URL connection with the URL handlers provided by the Targeted URL Stream Handlers. 
   * 
   * @param url The URL to open connection for.
   *
   * @return The URL connection or <code>null</code> if there is no of
   *         PluginDescriptor.TARGETED_URL_HANDLER plugin type that can handle this URL open connection.
   * 
   * @throws IOException
   */
  public URLConnection openConnectionWithTargetedURLHandler(URL url) throws IOException {
    URLConnection connection = null;
    if(! pluginsUpdateInProgress()){
      // Get the list of targeted URL stream handler that can handle the URL protocol
      List<Plugin> plugins = getTargetedURLHandlersForProtocol(url.getProtocol());
      if (plugins != null) {
        for (Plugin plugin : plugins) {
          PluginDescriptor descriptor = plugin.getDescriptor();        
          // Get the plugin extension
          PluginExtension extension = descriptor.getExtension(PluginDescriptor.TARGETED_URL_HANDLER);
          // Must be of targeted URL stream handler type
          if (extension instanceof TargetedURLStreamHandlerPluginExtension) {
            TargetedURLStreamHandlerPluginExtension pluginExtension = 
              (TargetedURLStreamHandlerPluginExtension) extension;
            try {
              URLStreamHandler handler = pluginExtension.getURLStreamHandler(url);
              // Open connection
              if (handler != null) {
                Method method =
                  handler.getClass().getDeclaredMethod("openConnection", new Class[] { java.net.URL.class });
                if (method != null) {
                  method.setAccessible(true);
                  // Invoke openConnection
                  connection =(URLConnection) method.invoke(handler, url);
                  break;
                }
              }
            } catch (Throwable e) {
              if (e.getCause() instanceof IOException) {
                throw (IOException)e.getCause();
              } else {
                logger.fatal(
                    "Exception when handling openConnection by the " + descriptor.getName()
                    + " TargetedURLHandler plugin: ", e);
              }
            }
          }
        }
      }
    }
    return connection;
  }
}