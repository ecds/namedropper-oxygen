/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2011 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.plugin.urlstreamhandler;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

import java.net.URL;
import java.net.URLStreamHandler;

import ro.sync.exml.plugin.PluginExtension;

/**
 * Usually oXygen has specific fixed URL stream handlers for http and https protocols. 
 * This URL stream handler plugin extension provides the possibility to impose 
 * custom stream handlers for specific URLs.
 * <br/>
 * <br/>
 * If the plugin decides that it could handle connections for a particular protocol
 * ({@link #canHandleProtocol(String)}), it will be asked to provide the handler 
 * for each opened connection of an URL having that protocol({@link #getURLStreamHandler(URL)}).
 * <br/>
 * <br/>
 * This extension can be useful in situations when opened connections from a 
 * specific host must be handled in a particular way. 
 * <br/>
 * For example, the Oxygen HTTP URLStreamHandler may not be compatible for sending 
 * and receiving SOAP using the SUN Webservices implementation. 
 * In this case you can override the stream handler set by Oxygen for HTTP to 
 * use the default SUN URLStreamHandler which is more compatible with sending 
 * and receiving SOAP requests.
 * <br/>
 * <br/>
 * This extension can handle the following protocols: <code>http</code>, <code>https</code>, 
 * <code>ftp</code> or <code>sftp</code>. 
 * <br/>
 * <br/>
 * If it is necessary to impose the application stream URL handlers for  
 * protocols different than the one handled by the application, the 
 * {@link URLStreamHandlerPluginExtension} can be used.
 * 
 * @since 13.2
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface TargetedURLStreamHandlerPluginExtension
       extends PluginExtension, URLStreamHandlerPluginExtensionConstants {
  
  /**
   * Check if the plugin can handle a specific protocol. 
   * If this method returns <code>true</code> for a specific protocol,
   * the {@link #getURLStreamHandler(URL)} method will be called for each opened 
   * connection of an URL having this protocol.
   * <br/>
   * The plugin can handle multiple protocols like: <code>http</code>, <code>https</code>, 
   * <code>ftp</code>, <code>sftp</code>.
   * 
   * @param protocol The protocol.
   * @return <code>true</code> if this plugin extension can handle this protocol type.
   */
  public boolean canHandleProtocol(String protocol);
  
  /**
   * Get the URL handler for the specified URL.
   * This method is called for each opened connection of an URL with a protocol 
   * for which the {@link #canHandleProtocol(String)} method returns <code>true</code>.
   * If this method returns <code>null</code>, the Oxygen {@link URLStreamHandler} 
   * is used.
   *  
   * @param url The URL to provide a handler for.
   * @return The URL stream handler.
   */
  public URLStreamHandler getURLStreamHandler(URL url);
}