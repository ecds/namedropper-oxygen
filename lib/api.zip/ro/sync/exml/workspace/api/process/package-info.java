/**
 * Control a process started using the API.
 */
package ro.sync.exml.workspace.api.process;