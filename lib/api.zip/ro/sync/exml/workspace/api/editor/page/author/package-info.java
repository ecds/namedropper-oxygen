/**
 * API for accessing the Author page in the editor.
 */
package ro.sync.exml.workspace.api.editor.page.author;