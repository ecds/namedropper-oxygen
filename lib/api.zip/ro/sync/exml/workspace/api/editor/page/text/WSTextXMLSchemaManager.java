/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.editor.page.text;

import java.net.URL;
import java.util.List;

import javax.swing.text.BadLocationException;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.contentcompletion.xml.CIAttribute;
import ro.sync.contentcompletion.xml.CIElement;
import ro.sync.contentcompletion.xml.CIValue;
import ro.sync.contentcompletion.xml.Context;
import ro.sync.contentcompletion.xml.NameValue;
import ro.sync.contentcompletion.xml.WhatAttributesCanGoHereContext;
import ro.sync.contentcompletion.xml.WhatElementsCanGoHereContext;
import ro.sync.contentcompletion.xml.WhatPossibleValuesHasAttributeContext;

/**
 * Text page XML schema manager. Provides support for obtaining information about what elements, attributes can be inserted 
 * in a given context.
 * 
 * @since 12.1
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public abstract class WSTextXMLSchemaManager {
  /**
   * Create an element context for the given offset.
   * 
   * @param offset Offset in document for which to create an element context.
   * @return The element context. Null value will be returned if node at given offset is not an element.
   * @throws BadLocationException When the offset is below zero or greater than the content.
   */
  public abstract WhatElementsCanGoHereContext createWhatElementsCanGoHereContext(int offset) throws BadLocationException;
  /**
   * Create a context for the given element that can be used to obtain the list with attributes that element accepts.
   * 
   * @param offset The current offset
   * @return An attribute context.
   * @see #whatAttributesCanGoHere(WhatAttributesCanGoHereContext)
   */
  public abstract WhatAttributesCanGoHereContext createWhatAttributesCanGoHereContext(int offset);
  /**
   * Create an attribute values context for the given element and attribute name.
   * 
   * @param offset The offset of the attribute name on the element whose attribute values interest us.
   * @return An attribute values context.
   */
  public abstract WhatPossibleValuesHasAttributeContext createWhatPossibleValuesHasAttributeContext(int offset);
  /**
   * Examines the grammar and decides what attributes can be inserted in the
   * parent element, after the list of attributes names.
   *
   * @param whatAttributesCanGoHereContext the context for the call. It must
   * have:
   * <ul>
   *  <li>elementName              the name of the element in which will be
   *      done the insertion.</li>
   *  <li>proxyNamespaceMapping    the proxy - uri mappings defined before the
   *      insertion point.</li>
   *  <li>previousAttributesNames  the names of the existing attributes in the
   *      element, attributes that are before the insertion point.</li>
   * </ul>
   *@return                     a list of attributes or null if there is none. 
   *Null value is also returned when schema is not specified.
   */
  public abstract List<CIAttribute> whatAttributesCanGoHere(WhatAttributesCanGoHereContext whatAttributesCanGoHereContext);
  /**
   * Examines the grammar and decides what elements can be inserted in the
   * parent element, after the list of child names.
   *
   * @param whatElementsCanGoHereContext the context for the call. It must have:
   * <ul>
   *  <li>parentElementName the qName of the parent element</li>
   *  <li>previousElementNames the list of qNames of the previous elements</li>
   *  <li>previousElementNamespaces the list of qNames of the previous elements</li>
   *  <li>proxyNamespaceMapping    the proxy - uri mappings defined before the
   *      insertion point.</li>
   *@return                      a list of CIElement representing the elements,
   * or null if there is none. Null value is also returned when schema is not specified.
   */
  public abstract List<CIElement> whatElementsCanGoHere(WhatElementsCanGoHereContext whatElementsCanGoHereContext);
  /**
   * Queries the possible values of an element attribute. If the
   * attribute type was an enumeration, then a list with the tokens of the
   * enumeration will be returned.
   * @param ctxt The context WhatPossiBleValuesHasAttributeContext.
   *
   * @return the list of CIValue representing possible values of 
   * the attribute or null if they are not known. Null value is also returned when schema is not specified.
   */
  public abstract List<CIValue> whatPossibleValuesHasAttribute(WhatPossibleValuesHasAttributeContext ctxt);
  /**
   * Queries the possible values of an element. If the element type was an enumeration,
   * then a list with the tokens of the enumeration will be returned.
   * 
   * @param ctxt The context.
   * @return a list of attribute values as CIValue or null if there is none or no schema is specified.
   * The list of values can contain duplicates.
   */
  public abstract List<CIValue> whatPossibleValuesHasElement(WhatElementsCanGoHereContext ctxt);
  
  /**
   * Get the array of URLs of the loaded DTD or XML Schema. These URLs were set
   * using one of the update methods, and includes the URLs that were collected from the calls
   * of the <code>update(InputSource[])</code> methods.
   *
   *@return The URLs of the schemas loaded, or null if there was nothing loaded.
   */
  public abstract URL[] getGrammarURLs();
  
  /**
   * Get the description of an attribute. This model must be human readable.
   *
   * @param ctxt the context describing the target attribute.
   * @return a hash describing the model of the element.
   */
  public abstract CIAttribute getAttributeDescription(WhatPossibleValuesHasAttributeContext ctxt);
  
  /**
   * Gets the context-independent list of entities declared in the document's 
   * DOCTYPE declaration.<p> 
   * If the DOCTYPE declaration is not changed, the document should not be
   * processed each time this method is called.
   *
   * @return a list of name value representing the entities, or null if
   *          there is none. The reference of the list is changed on update.
   */
  public abstract List<NameValue> getEntities();
  
  /**
   * Get the description of an element. This model must be human readable.
   *
   * @param ctxt the context describing the target element. It contains:<ul>
   *  <li>The element names stack, having at top the current element name.</li>
   *  <li>The element namespaces stack, having at top the current element namespace.</li>
   * </ul>
   * @return a description the model of the element, or null.
   */
  public abstract CIElement getElementDescription(Context ctxt);
  
  /**
   * If true the element description(model) support is available, otherwise not.
   * @return True if element description is supported by the SM.
   */
  public abstract boolean isElementDescriptionSupported();
  
  /**
   * Get the elements that can be children of the element for
   * which the context was built.
   * 
   * @param context The element context.
   * @return A list with CIElements that are allowed as children.
   */
  public abstract List<CIElement> getChildrenElements(WhatElementsCanGoHereContext context);
  
  /**
   * @return Return true if schema was learned by Oxygen from the structure of the document.
   */
  public abstract boolean isLearnSchema();
  
  /**
   * @return Return true if there were errors when loading schema document(missing, not wellformed, not valid schema).
   */
  public abstract boolean hasLoadingErrors();
  
  /**
   * Get all the names of global elements defined in the associated grammar.
   *
   * @return A list of CIElements.
   * @since 11.2
   */
  public abstract List<CIElement> getGlobalElements();
}
