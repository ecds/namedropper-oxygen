/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.editor.page.author.actions;

import java.util.Map;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Provides access to actions defined in the Author page.
 * 
 * @since 12.1
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface AuthorActionsProvider {
  /**
   * Get the map of author common actions (undo, redo, cut, copy, paste, etc).
   * 
   * @return The map with (action id, Action) pairs with the actions defined for working in the Author.
   * If the standalone Oxygen implementation is used, the actions are instance of javax.swing.Action
   * If the eclipse plugin Oxygen implementation is used, the actions are instance of org.eclipse.jface.action.Action
   * 
   */
  public Map<String, Object> getAuthorCommonActions();
  
  /**
   * Get the map of author extension actions.  Can be null if the author page does not have an associated document type.
   * This should get called after each load as the extension actions depend on the loaded document type.
   * 
   * @return The map with (action id, Action) pairs with the actions defined in the Author framework.
   * Can be null if no actions available.
   * If the standalone Oxygen implementation is used, the actions are instance of javax.swing.Action
   * If the eclipse plugin Oxygen implementation is used, the actions are instance of org.eclipse.jface.action.Action
   * 
   * @since 12.1
   */
  public Map<String, Object> getAuthorExtensionActions();
  
  /**
   * If an action was obtained using one of the methods in this interface this method  
   * provides means to invoke an action on AWT thread (for the standalone distribution) or SWT thread (for the eclipse distribution).
   *  
   * @param action The action to invoke
   * 
   * @since 12.1
   */
  public void invokeAction(Object action);
  
  /**
   * Get an unique ID (which does not depend on the action name) for an action Oxygen has mounted on the main JMenuBar or on the toolbars.
   * If the action appears on a contextual menu but is not installed on a main menu it will pe prefixed with the constant "ACTION_WITH_NO_SHORTCUT/"
   * 
   * @param action The action for which to retrieve the ID.
   * @return The unique ID or <code>null</code> if the action is not one provided by Oxygen. 
   * 
   * 
   * @since 13.2
   */
  public String getActionID(Object action);
}
