/**
 * API for accessing the Text page in the editor. 
 */
package ro.sync.exml.workspace.api.editor.page.text;