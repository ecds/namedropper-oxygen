/**
 * API for accessing the DITA Map page in the editor.
 */
package ro.sync.exml.workspace.api.editor.page.ditamap;