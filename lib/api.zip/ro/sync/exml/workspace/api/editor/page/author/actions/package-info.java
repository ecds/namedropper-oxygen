/**
 * Provides access to all actions available in the Author page.
 */
package ro.sync.exml.workspace.api.editor.page.author.actions;