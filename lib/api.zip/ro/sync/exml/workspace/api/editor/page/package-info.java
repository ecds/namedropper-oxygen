/**
 * API for accessing a certain page in the editor.
 */
package ro.sync.exml.workspace.api.editor.page;