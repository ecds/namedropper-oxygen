/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2012 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.editor.page.text.xml;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.workspace.api.editor.page.text.WSTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.WSTextXMLSchemaManager;

/**
 * Contains methods specific to XML editors.
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface WSXMLTextEditorPage extends WSTextEditorPage {
  
  /**
   * Finds the nodes selected by the given XPath expression.
   * The result of this function is an array of {@link WSXMLTextNodeRange} selected 
   * by the given XPath expression.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the node ranges in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   *
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * 
   * @return The node ranges selected by the XPath expression.
   *         It does not return a <code>null</code> array of nodes.
   *         If the evaluation of the XPath expression fails it will return an empty array.
   * @throws XPathException  If the XPath expression failed to be evaluated.
   */
  WSXMLTextNodeRange[] findElementsByXPath(String xpathExpression) throws XPathException;
  
  /**
   * Evaluates an XPath expression.
   * This function returns the result of the given XPath expression as an array of {@link Object}.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the DOM Nodes created over the XML structure.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all DOM Nodes and having as last component
   * the total number of nodes.
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * @return An array of objects representing the XPath result.
   *         It does not return a <code>null</code> array. If the XPath evaluation fails it will return
   *         an empty array.
   * @throws XPathException  If the XPath expression failed to be evaluated.
   */
  Object[] evaluateXPath(String xpathExpression) throws XPathException;
  
  /**
   * Get the schema manager used to ask useful information about allowed elements and the context of the current offset.
   * @return the XML Schema Manager used to ask useful information about allowed elements and the context of the current offset.
   */
  WSTextXMLSchemaManager getXMLSchemaManager();
}
