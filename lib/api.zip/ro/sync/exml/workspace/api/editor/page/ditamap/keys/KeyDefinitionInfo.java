/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.editor.page.ditamap.keys;

import java.util.HashMap;
import java.util.Map;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Information about a key definition.
 * 
 * This is filled on the API side.
 * 
 * @since 14
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public class KeyDefinitionInfo {
  /**
   * The key name.
   */
  public static final String NAME = "name";
  
  /**
   * The href value of the topic ref which defines the key. Can be null.
   * 
   * If the defined key points indirectly (using a keyref) to other definitions,
   * it is the reponsability of the developer to set here the resolved final href value.
   */
  public static final String HREF = "href";
  
  /**
   * This could be the navigation title on the topic ref which defines the key.
   *  
   * It is used for display purposes when a key reference is inserted. Can be null.
   */
  public final static String DESCRIPTION = "description";
  
  /**
   * The location of the DITA Map where the key definition was defined. This must be given as an URL in the Oxygen standalone version.
   * In the Oxygen plugin for Eclipse this can be also given as a native resource like IResource.
   * 
   * The location is useful in order for Oxygen to determine the absolute location where the keyref is pointing.
   * When the user clicks a keyref or a conkeyref in the Author page Oxygen has to open the target location corresponding to it. 
   */
  public final static String DEFINITION_LOCATION = "definitionLocation";
  
  /**
   * May return a "ro.sync.exml.workspace.api.editor.page.ditamap.keys/MetaContentProvider" implementation 
   * which returns the text which should appear on an element which has the keyref if the element has no content.
   * 
   * The provider is useful in order for Oxygen to show the static text in place in the Author page.
   */
  public final static String META_CONTENT_PROVIDER = "metaContentProvider";
  
  /**
   * A map of accepted properties.
   */
  private final Map<String, Object> properties = new HashMap<String, Object>();
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #DESCRIPTION}</li>
   *  <li>{@link #NAME}</li>
   *  <li>{@link #HREF}</li>
   *  <li>{@link #DEFINITION_LOCATION}</li>
   * </ul>
   * @return The property value or <code>null</code> if not available.
   */
  public Object getProperty(String propertyName) {
    return properties.get(propertyName);
  }
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #DESCRIPTION}</li>
   *  <li>{@link #NAME}</li>
   *  <li>{@link #HREF}</li>
   *  <li>{@link #DEFINITION_LOCATION}</li>
   * </ul>
   * @param propertyValue The value of the property.
   * @throws IllegalArgumentException If the property name is not one of the constants in this class.
   */
  public void setProperty(String propertyName, Object propertyValue) throws IllegalArgumentException {
    if (propertyName == null || (!propertyName.equals(DESCRIPTION) && !propertyName.equals(NAME)
        && !propertyName.equals(HREF) && !propertyName.equals(DEFINITION_LOCATION))) {
      throw  new IllegalArgumentException("Invalid property name: " + propertyName);
    }
    properties.put(propertyName, propertyValue);
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "KeyDefInfo:" + properties;
  }
}
