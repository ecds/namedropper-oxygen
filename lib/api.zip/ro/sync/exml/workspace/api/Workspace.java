/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Map;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.workspace.api.license.LicenseInformationProvider;
import ro.sync.exml.workspace.api.options.DataSourceAccess;
import ro.sync.exml.workspace.api.process.ProcessController;
import ro.sync.exml.workspace.api.process.ProcessListener;

/**
 * Provides access to workspace specific information and actions. 
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface Workspace {
  /**
   * Get the parent main frame.
   * 
   * @return The parent frame ({@link javax.swing.JFrame or @link java.awt.Frame (when running as a JApplet)}) of the Oxygen application or the parent shell 
   * ({@link org.eclipse.swt.widgets.Shell}) if this is the Eclipse implementation.
   */
  Object getParentFrame();
  
  /**
   * Set a title on the parent frame. This is available only in the standalone Oxygen version (not available in the Oxygen Eclipse plugin).
   * If NULL, will reset to the default title.
   * 
   * @param parentFrameTitle The new title to set on the parent frame.
   * If NULL, will reset to the default title.
   * 
   * @since 12.1
   */
  void setParentFrameTitle(String parentFrameTitle);
  
  /**
   * Displays a file chooser for selecting a {@link File}.
   * 
   * @param title             The file chooser title.
   * @param allowedExtensions Allowed file extensions. Can be <code>null</code> if you want all
   *                          files filter. Example:  new String[] {"xml", "dita"}.
   * @param filterDescr       Description for the file filter.
   * @param openForSave       <code>true</code> when the file chooser is used for saving,
   *                          <code>false</code> if it is used for opening an existing file.
   * 
   * @return The chosen file or <code>null</code> if the user canceled the dialog.
   */
  File chooseFile(String title, String[] allowedExtensions, String filterDescr, boolean openForSave);
  
  /**
   * Displays a file chooser for selecting a {@link File}.
   * @param currentFileContext      The file which will be selected in the file chooser.
   *                                If it is a directory, it will be used as a default directory.
   *                                If it is a file (even non-existing) and the file chooser is shown for a save operation its name will also be selected in the chooser.
   *                                Can be set <code>null</code> in order to use the default behavior.
   * @param proposedFileName The proposed file name, will be used if the file chooser is used for save operations.
   *                         Can be set <code>null</code> in order to use the default behavior.
   * @param title             The file chooser title.
   * @param allowedExtensions Allowed file extensions. Can be <code>null</code> if you want all
   *                          files filter. Example:  new String[] {"xml", "dita"}.
   * @param filterDescr       Description for the file filter.
   * @param usedForSave       <code>true</code> when the file chooser is used for saving,
   *                          <code>false</code> if it is used for opening an existing file.
   * 
   * @return The chosen file or <code>null</code> if the user canceled the dialog.
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions,
   * comments about it, please let us know.</p>
   */
  File chooseFile(File currentFileContext, String title, String[] allowedExtensions, String filterDescr, boolean usedForSave);
  
  /**
   * Displays a file chooser for selecting a {@link File}.
   * 
   * @param title             The file chooser title.
   * @param allowedExtensions Allowed file extensions. Can be <code>null</code> if you want all
   *                          files filter. Example:  new String[] {"xml", "dita"}.
   * @param filterDescr       Description for the file filter.
   *
   * @return The chosen file or <code>null</code> if the user canceled the dialog.
   */
  File chooseFile(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Displays an URL chooser for selecting an {@link URL}.
   * 
   * @param title The chooser dialog title.
   * @param allowedExtensions Allowed extensions.
   * @param filterDescr Description for the filter.
   * @return The chosen URL or <code>null</code> if the user canceled the dialog.
   */
  URL chooseURL(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Displays an URL chooser for selecting an {@link URL}. If the user sets a 
   * relative path in the chooser, that path will be returned.
   * 
   * @param title The chooser dialog title.
   * @param allowedExtensions Allowed extensions.
   * @param filterDescr Description for the filter.
   * 
   * @return The chosen URL as String or <code>null</code> if the user canceled the dialog.
   * 
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions,
   * comments about it, please let us know.</p>
   */
  String chooseURLPath(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Check if the extension is used in the Oxygen stand alone or Eclipse plugin version.
   * 
   * @return <code>true</code> if this is the stand-alone Oxygen version or
   * <code>false</code> if it is the Oxygen Eclipse plug-in version.
   */
  boolean isStandalone();
  
  /**
   * Get the current version of the Oxygen/Author product.
   * Can be used to decide if some extension functions are available or not.
   * @return The version of the Oxygen application in which the extension runs.
   * Returns a string like: 11.2
   * @since 12
   */
  String getVersion();
  
  /**
   * Get the language used to display the GUI controls (buttons, label) in Oxygen.
   * Examples of format: <b>en_US</b>, <b>fr_FR</b>, <b>de_DE</b>, <b>jp_JP</b>, <b>it_IT</b>, <b>nl_NL</b>
   * 
   * @return The language used to display the GUI controls (buttons, label) in Oxygen.
   *
   * @since 12.1
   */
  String getUserInterfaceLanguage();
  
  /**
   * Get the directory where the Oxygen preferences are saved.
   * Can be used to save additional user data there.
   * @return the directory where the Oxygen preferences are saved.
   * Returns a string like: c:\\Documents and Settings\\username\\com.oxygenxml
   * 
   * @since 12.1
   */
  String getPreferencesDirectory();
  
  /**
   * Shows a question message dialog.
   * 
   * @param title The dialog title.
   * @param message The message to be presented to the user.
   * @param buttonNames The names of the buttons representing the choices in the dialog.
   * @param buttonIds The id for each button. Used to identify which button was pressed.
   * All Ids must be greater or equal to 0.
   * 
   * @return the id of the pressed button or -1 if the dialog was closed by other means.
   */
  int showConfirmDialog(String title, String message, String[] buttonNames, int[] buttonIds);
  
  /**
   * Shows a question message dialog.
   * 
   * @param title The dialog title.
   * @param message The message to be presented to the user.
   * @param buttonNames The names of the buttons representing the choices in the dialog.
   * @param buttonIds The id for each button. Used to identify which button was pressed.
   * @param initialSelectedIndex The index of the initial selected button. 0 based.
   * All Ids must be greater or equal to 0.
   *
   * @return the id of the pressed button or -1 if the dialog was closed by other means.
   * 
   * @since 13.1
   */
  int showConfirmDialog(String title, String message, String[] buttonNames, int[] buttonIds, int initialSelectedIndex);
  
  /**
   * Presents an error message dialog.
   * 
   * @param message The error message.
   */
  void showErrorMessage(String message);
  
  /**
   * Presents an information message dialog.
   * 
   * @param message The information message.
   */
  void showInformationMessage(String message);
  
  /**
   * Show a status message. 
   * 
   * @param statusMessage The status message
   */
  void showStatusMessage(String statusMessage);
  
  /**
   * Opens the file at the specified {@link URL} in a new editor.
   * 
   * @param url The URL of the file to be opened.
   * @return <code>true</code> if the operation has succeeded.
   */
  boolean open(URL url);
  
  /**
   * Opens the file at the specified {@link URL} in a new editor.
   * 
   * @param url         The URL of the file to be opened.
   * @param imposedPage The imposed page for opening the URL.
   *
   * @return <code>true</code> if the operation has succeeded.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  boolean open(URL url, String imposedPage);
  
  /**
   * Open in the associated system application
   * @param url The URL to open.
   * @param preferAssociatedApplication 
   * If true will prefer the system associated application and if this fails, open in the browser
   * if false will open in the browser.
   * 
   *  @since 12
   */
  void openInExternalApplication(URL url, boolean preferAssociatedApplication);
  
  /**
   * Saves the content of all opened and unsaved editors.
   */
  void saveAll();
  
  /**
   * Closes the editor specified by the URL.
   * <p>
   * If the editor has unsaved content, the user will be given the opportunity to save it.
   * </p>
   * 
   * @param url The url of the editor to be closed.
   * @return <code>true</code> if the editor was successfully closed, and
   *         <code>false</code> if the editor could not be closed.
   */
  boolean close(URL url);
  
  /**
   * Closes all the editors.
   * <p>
   * If there are editors with unsaved content, the user will be given the opportunity to save them.
   * </p>
   * 
   * @return <code>true</code> if the editors were successfully closed, and
   *         <code>false</code> if the editors are still open.
   */
  boolean closeAll();
  
  /**
   * Delete the resource identified by the specified {@link URL}.
   * Currently supported protocols are:
   * <ul>
   * <li>file://</li>
   * <li>zip://</li>
   * <li>ftp://</li>
   * <li>sftp://</li>
   * <li>http://</li>
   * <li>https://</li>
   * </ul>
   * 
   * @param url The URL from where to delete a resource.
   * @throws IOException
   */
  void delete(URL url) throws IOException;
  
  /**
   * In a new file appeared as a child of a folder in the project, use this method to 
   * refresh the parent folder.
   * @param url The new resource
   */
  void refreshInProject(URL url);
  
  /**
   * Prepare a Java process for execution.
   * It also sets on the Java process the Oxygen HTTP proxy configuration.
   * 
   * @param additionalJavaArguments Additional Java arguments like "-Xmx256m"
   * @param classpath The classpath.
   * @param mainClass The main class
   * @param additionalArguments The additional process arguments
   * 
   * @param commandLine The entire command line. Not <code>null</code>.
   * @param environmentalVariables Additional environmental variables. Can be <code>null</code> 
   * @param startDirectory The directory where the process should start.  Can be <code>null</code>
   * @param processListener The process listener.  Can be <code>null</code>
   * @return Access to the process.
   * 
   * <br><br><br>Sample usage:
   * <blockquote>   
   * ProcessListener processListener = new ProcessListener() {<br>
   *  public void newErrorLine(String line) {<br>
   *    System.err.println("Error from process " + line);<br>
   *  }<br>
   *  public void processCouldNotStart(String message) {<br>
   *    System.err.println("Could not start process " + message);<br>
   *  }<br>
   *  public void processEnded(int exitCode) {<br>
   *    System.err.println("Process ended " + exitCode);<br>
   *  }<br>
   *  public void newOutputLine(String line) {<br>
   *    System.out.println("Output from process: " + line);<br>
   *  }<br>
   *};<br>
   *final ProcessController processController = standalonePluginWorkspace.createJavaProcess("-Xmx256m",<br> 
   *    new String[] {"lib/oxygen.jar", "classes"}, <br>
   *    //The main Oxygen class<br>
   *    "ro.sync.exml.Oxygen", <br>
   *    //The URL which Oxygen will attempt to load on startup<br>
   *    "file:/D:/projects/eXml/samples/dita/flowers/topics/copyright.xml",<br>
   *    //Environmental variables to set to the process, none in mu case<br>
   *    null, new File("."), processListener);<br>
   *  //You can start a new thread here and send messages to the process using the ProcessControler<br> 

   *  //Start the process, will block until process has finished<br>
   * processController.start();</blockquote>
   * 
   * @since 12.1
   */
  ProcessController createJavaProcess(String additionalJavaArguments, String[] classpath, String mainClass, String additionalArguments, Map<String, String> environmentalVariables, File startDirectory, ProcessListener processListener);
  
  /**
   * This is available only in the standalone Oxygen version (not available in the Oxygen Eclipse plugin).<br/>
   * Create a new "Untitled" editor. The editor content is not saved on disk, this method is equivalent to using the "File->New" action.
   * @param extension The editor extension ("xml" or "dita" or "xsl" or "xsd", etc...)
   * @param contentType The content type which can take values like: "text/xml" or "text/xsl" or "text/xsd", etc...
   * If NULL, the content type will be automatically detected from the extension. 
   * @param content The XML content will be used to load the new editor from.
   * @return The URL of the created new editor.
   * 
   * 
   * @since 12.1
   */
  URL createNewEditor(String extension, String contentType, String content);
  
  /**
   * Get information about the license used in the current Oxygen application.
   * 
   * @return The license information provider
   * 
   * 
   * @since 12.1
   */
  LicenseInformationProvider getLicenseInformationProvider();
  
  /**
   * Clear the cache of images used to display images fast in the Author page.
   * 
   * @since 13
   */
  void clearImageCache();
  
  /**
   * Get information about the configured data source connections.
   * 
   * @return The {@link DataSourceAccess} capable of providing information about the data source connections.
   * 
   * @since 14.1
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  DataSourceAccess getDataSourceAccess();
}