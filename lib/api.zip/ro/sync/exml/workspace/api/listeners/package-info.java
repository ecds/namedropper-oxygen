/**
 * Workspace and Editor listeners.
 */
package ro.sync.exml.workspace.api.listeners;