/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.util;

import java.io.File;
import java.net.URL;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Provides access to utility methods.
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface UtilAccess {
  
  /**
   * Make the child URL relative to the base URL. 
   * The query and fragment identifier are preserved if the initial reference contains them.
   * <p>
   * The child URL is relatively expressed to the base URL. If it is
   * not possible, the child URL is returned.</p> 
   * <p>
   * For example if the base URL is "file://c:/projects/exml/base.prx" and the child
   * URL is "file://c:/projects/exml/test/someTest.xml" the result will be: "test/someTest.xml"</p> 
   * 
   * @param baseURL The base URL.
   * @param childURL The child URL.
   * @return The relative path or the <code>childURL</code> if a relative path cannot be computed.
   */
  String makeRelative(URL baseURL, URL childURL);
  
  /**
   * Corrects the given URL by converting not allowed characters to their escaped representation.
   * The URL correction takes an URL like:<br>
   *   http://path to directory/file.xml<br>
   * and escapes illegal URL characters like spaces to:<br>
   *   http://path%20to%20directory/file.xml
   * 
   * @param url The URL to be corrected.
   * @return The corrected URL. It does not return <code>null</code>.
   */
  String correctURL(String url);
  
  /**
   * Removes the user name and password from the URL if they are present.
   * 
   * @param url The URL from which the user credentials will be removed.
   * @return The URL having the user credentials removed.
   * 
   * @since 12.1
   */
  URL removeUserCredentials(URL url);
  
  /**
   * Locate the file on disk corresponding to the URL.
   * 
   * @param url The {@link URL} to be checked.
   * @return The corresponding {@link File} from the local file system 
   * or <code>null</code> if the URL is remote.
   */
  File locateFile(URL url);
  
  /**
   * Get the file extension for this URL. The extension is lower cased.
   * @param url The URL to extract the extension for.
   * @return the file extension for this URL. The extension is lower cased.
   */
  String getExtension(URL url);
  
  /**
   * Get the file name from a file or URL path 
   * @param urlPath An URL path
   * @return the file name from a file or URL path 
   */
  String getFileName(String urlPath);

  /**
   * Check if this URL points to a supported image. The image extension is used
   * @param url The URL
   * @return true if this URL points to a supported image. The image extension is used
   */
  boolean isSupportedImageURL(URL url);
  
  /**
   * Try to expand the editor variables in a path. 
   * 
   * If there's an external framework associated with the current editor, any $framework, $frameworks,
   * $frameworkDir or $frameworksDir variable will be expanded in the context of 
   * that framework.
   * 
   * @param pathWithEditorVariables The path containing editor variables
   * @param currentEditedURL The current edited URL
   * @return The path with editor variables expanded.
   * @since 12.1
   */
  String expandEditorVariables(String pathWithEditorVariables, URL currentEditedURL);
  
  /**
   * Encrypts a string using the Oxygen internal encryption system.
   * The encryption/decryption is application-specific so a string encrypted in one Oxygen installation cannot be decrypted in another.
   * You can use this method if you want to store user-specific data on disk with a moderate level of security.
   *  
   * @param toEncrypt The string to encrypt.
   * @return The string encrypted using the Oxygen internal encryption system.
   * 
   * @since 12.1
   */
  String encrypt(String toEncrypt);
  
  /**
   * Decrypts a string using the Oxygen internal encryption system.
   * The encryption/decryption is application-specific so a string encrypted in one Oxygen installation cannot be decrypted in another.
   * You can use this method if you want to store user-specific data on disk with a moderate level of security.
   *  
   * @param toDecrypt The string to decrypt.
   * @return The string decrypted using the Oxygen internal encryption system or NULL if the string format is not understood.
   * 
   * @since 12.1
   */
  String decrypt(String toDecrypt);
}