/**
 * Utilities to resolve through the catalogs, 
 * to create SAX Parsers and XSLT transformers with the same configuration as in the application
 */
package ro.sync.exml.workspace.api.util;