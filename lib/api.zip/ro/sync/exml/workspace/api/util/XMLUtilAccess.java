/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.util;

import java.net.URL;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.URIResolver;

import net.sf.saxon.lib.ExtensionFunctionDefinition;

import org.xml.sax.EntityResolver;
import org.xml.sax.XMLReader;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * XML Utilities
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface XMLUtilAccess {
  /**
   * Xalan transformer
   */
  final int TRANSFORMER_XALAN = 0;
  /**
   * Saxon 6 transformer
   */
  final int TRANSFORMER_SAXON_6 = 1;
  /**
   * Saxon 9 Home Edition transformer type (no extensions support).
   */
  final int TRANSFORMER_SAXON_HOME_EDITION = 2;
  /**
   * Saxon 9 Professional Edition transformer type (full extensions support).
   */
  final int TRANSFORMER_SAXON_PROFESSIONAL_EDITION = 3;
  /**
   * Saxon 9 Enterprise Edition transformer type (full extensions support + schema aware).
   */
  final int TRANSFORMER_SAXON_ENTERPRISE_EDITION = 4;
  
  /**
   * Create a new XSLT transformer.
   * The options set in the oXygen preferences are used.
   * 
   * @param styleSource     The source XSL
   * @param extensionJars   Jars with extension libraries which can be used by the transformer, can be <code>null</code>
   * @param transformerType The type of the transformer to create, one of the constants defined in this class starting with TRANSFORMER_
   * 
   * @return The new transformer.
   * @throws TransformerConfigurationException An <code>Exception</code>
   *   is thrown if an error occurs during parsing of the
   *   <code>source</code>.
   */
  Transformer createXSLTTransformer(Source styleSource, URL[] extensionJars, int transformerType) throws TransformerConfigurationException;

  /**
   * Create a new XSLT transformer.
   * 
   * @param styleSource       The source XSL
   * @param extensionJars     Jars with extension libraries which can be used by the transformer. Can be <code>null</code>.
   * @param transformerType   The type of the transformer to create, one of the constants defined in this class starting with TRANSFORMER_
   * @param useOxygenOptions  If <code>true</code> the options set in the oXygen preferences are used. Otherwise no options are set to the transformers.
   * 
   * @return The new transformer.
   *
   * @throws TransformerConfigurationException An <code>Exception</code> is thrown if an error
   *         occurs during parsing of the <code>source</code>.
   *         
   * @since 12.2
   */
  Transformer createXSLTTransformer(Source styleSource, URL[] extensionJars, int transformerType, boolean useOxygenOptions) throws TransformerConfigurationException;
  
  /**
   * <p>Create a Saxon 9 Home Edition transformer with the specified extension functions. This is 
   * necessary when the extension functions cannot be called by reflection because 
   * there is no license for the commercial version of Saxon 9.</p>
   * 
   * <p>The Saxon 9 options set in the oXygen preferences are not used.</p>
   * 
   * @param styleSource       The source XSL
   * @param saxonExtensions   The list of Saxon 9 extensions.
   * 
   * @return The new transformer.
   *
   * @throws TransformerConfigurationException An <code>Exception</code> is thrown if an error
   *         occurs during parsing of the <code>source</code>.
   *   
   * @since 12.2
   */
  Transformer createSaxon9HEXSLTTransformerWithExtensions(Source styleSource, ExtensionFunctionDefinition[] saxonExtensions) throws TransformerConfigurationException;
  
  /**
   * Create a new XQuery transformer.
   * The options set in the oXygen preferences are used.
   * 
   * @param xquerySource    The source XQuery file
   * @param extensionJars   Jars with extension libraries which can be used by the transformer, can be <code>null</code>
   * @param transformerType The type of the transformer to create, one of the constants:
   * <ul>
   * <li>{@link #TRANSFORMER_SAXON_HOME_EDITION},
   * <li>{@link #TRANSFORMER_SAXON_PROFESSIONAL_EDITION} or
   * <li>{@link #TRANSFORMER_SAXON_ENTERPRISE_EDITION}
   * </ul>
   * 
   * @return The new transformer.
   * @throws TransformerConfigurationException An <code>Exception</code> is thrown if an error
   *                                           occurs during parsing of the <code>source</code>.
   */
  Transformer createXQueryTransformer(Source xquerySource, URL[] extensionJars, int transformerType) throws TransformerConfigurationException;
  
  /**
   * Create a new XQuery transformer.
   * 
   * @param xquerySource      The source XQuery file
   * @param extensionJars     Jars with extension libraries which can be used by the transformer.
   *                          Can be <code>null</code>.
   * @param transformerType   The type of the transformer to create, one of the constants:
   * <ul>
   * <li>{@link #TRANSFORMER_SAXON_HOME_EDITION},
   * <li>{@link #TRANSFORMER_SAXON_PROFESSIONAL_EDITION} or
   * <li>{@link #TRANSFORMER_SAXON_ENTERPRISE_EDITION}
   * </ul>
   * @param useOxygenOptions  If <code>true</code> the options set in the oXygen preferences are used.
   *                          Otherwise no options are set to the transformers.
   * 
   * @return The new transformer.
   *
   * @throws TransformerConfigurationException An <code>Exception</code> is thrown if an error
   *                                           occurs during parsing of the <code>source</code>.
   * 
   * @since 12.2
   */
  Transformer createXQueryTransformer(Source xquerySource, URL[] extensionJars, int transformerType, boolean useOxygenOptions) throws TransformerConfigurationException;
  
  /**
   * Reset the loaded XML catalogs. This way next time the catalogs are needed
   * they will first be rebuilt.
   */
  void resetXMLCatalogs();
  
  /**
   * Try to resolve a relative location to an absolute path by using the XML catalogs.
   * 
   * @param baseURL The URL of the current opened XML file.
   * @param relativeLocation The relative location to be resolved.
   * @param entityResolve <code>true</code> if the catalog entity resolver should be used.
   * @param uriResolve <code>true</code> if the catalog URI resolver should be used.
   * @return The absolute URL. It returns null only for URLs with unknown protocols for which an URL object cannot be constructed.
   */
  URL resolvePathThroughCatalogs(URL baseURL, String relativeLocation, boolean entityResolve, boolean uriResolve);
  
  /**
   * Escape an attribute value so that the XML document remains well-formed.
   * 
   * @param attributeValue The attribute value.
   * @return The escaped value. It does not return <code>null</code>.
   */
  String escapeAttributeValue(String attributeValue);
  
  /**
   * Creates an {@link XMLReader} without validation.
   * 
   * @return A new XML Reader.
   */
  XMLReader newNonValidatingXMLReader();
  
  /**
   * Creates an {@link XMLReader} without validation and with the possibility to reuse the grammar pool.
   * If you are parsing XML fragments with DOCTYPE many times in your operation this method will be faster than
   *  the <code>newNonValidatingXMLReader()</code> method.
   * <br>
   * <i>Usage example:</i>
   * <code><pre> String xml = new String("&lt;!DOCTYPE map PUBLIC \"-//OASIS//DTD DITA Map//EN\" \"map.dtd\">\n" +
   *     "&lt;map/>");
   * Object grammarToken = null;
   * for (int i = 0; i < 100000; i++) {
   *   XMLReaderWithGrammar readerAndCache = authorAccess.getXMLUtilAccess().newNonValidatingXMLReader(grammarToken);
   *   XMLReader reader = readerAndCache.getXmlReader();
   *   grammarToken = readerAndCache.getGrammarCache();
   *   reader.parse(new InputSource(new StringReader(xml)));
   * }
   * </pre></code>
   * 
   * @param grammarCacheToken The grammar cache token, if not null, it will be used to cache the grammar pool.
   * 
   * @return A new XML Reader with a grammar cache token which can be then reused on the same method to provide grammar caching.
   */
  XMLReaderWithGrammar newNonValidatingXMLReader(Object grammarCacheToken);
  
  /**
   * Get the same entity resolver Oxygen sets to its constructed SAX Parsers 
   * (which looks into the Oxygen options and document types for catalogs).
   * The resolver also looks at the additionally set priority entity resolvers.
   * 
   * @return  the same entity resolver Oxygen sets to its constructed SAX Parsers 
   * (which looks into the Oxygen options and document types for catalogs).
   * 
   * @since 12.1
   */
  EntityResolver getEntityResolver();
  
  /**
   * Get the same URI resolver Oxygen sets to its constructed XSLT transformers
   * (which looks into the Oxygen options and document types for catalogs).
   * The resolver also looks at the additionally set priority URI resolvers.
   * 
   * @return  the same URI resolver Oxygen sets to its constructed XSLT transformers
   * (which looks into the Oxygen options and document types for catalogs).
   * 
   * @since 12.1
   */
  URIResolver getURIResolver();
  
  /**
   * Add a priority entity resolver.
   * 
   * @param entityResolver The entity resolver which will be called with priority before Oxygen calls the standard resolvers which are
   * based on the catalog files specified in the preferences catalogs list and in each document type association. 
   * 
   * @since 13
   */
  void addPriorityEntityResolver(EntityResolver entityResolver);
  
  /**
   * Remove a priority entity resolver.
   * 
   * @param entityResolver The entity resolver which will be called with priority before Oxygen calls the standard resolvers which are
   * based on the catalog files specified in the preferences catalogs list and in each document type association. 
   * 
   * @since 13
   */
  void removePriorityEntityResolver(EntityResolver entityResolver);
  
  /**
   * Add a priority URI resolver.
   * 
   * @param uriResolver The URI resolver which will be called with priority before Oxygen calls the standard resolvers which are
   * based on the catalog files specified in the preferences catalogs list and in each document type association. 
   * 
   * @since 13
   */
  void addPriorityURIResolver(URIResolver uriResolver);
  
  /**
   * Remove a priority URI resolver.
   * 
   * @param uriResolver The URI resolver which will be called with priority before Oxygen calls the standard resolvers which are
   * based on the catalog files specified in the preferences catalogs list and in each document type association. 
   * 
   * @since 13
   */
  void removePriorityURIResolver(URIResolver uriResolver);
}
