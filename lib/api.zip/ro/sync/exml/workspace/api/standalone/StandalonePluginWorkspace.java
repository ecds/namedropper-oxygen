/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone;

import javax.swing.Action;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.author.WSAuthorEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.WSTextEditorPage;
import ro.sync.exml.workspace.api.standalone.ditamap.TopicRefTargetInfoProvider;


/**
 * The <b>Plugin Workspace</b> offers the possibility to customize the Workspace toolbars,
 * menu bars or views, to access utility methods or to access (and add listeners for)
 * all opened editors from the Main editing area or from the DITA Maps editing area.
 * <br>
 * Each opened editor contains one or more pages.
 * <br/>
 * The current editor page can be accessed trough the {@link WSEditor#getCurrentPage()}
 * method that returns specific editor implementations for Author and Text pages:
 * <ul>
 *  <li>
 * {@link WSAuthorEditorPage} that provides access to Author editor page document controller or change tracking 
 * controller 
 *  </li>
 *  <li>
 *  {@link WSTextEditorPage} that offers access to the edited document.
 *  </li>
 *  </ul>
 * Both text based editor pages provides informations and actions regarding the 
 * caret position or the document current selection. 
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface StandalonePluginWorkspace extends PluginWorkspace, ReferencesCustomizer{
  /**
   * Adds a customizer which can contribute to or modify existing toolbars or contribute to the reserved <b>Plugins</b> toolbar.
   * <br>
   * <b>IMPORTANT</b> This customizer must be set early, when the plugin extension's <b>applicationStarted</b> method gets called.
   * <br>
   * <b>NOTICE</b> You will also receive notification for the Author extension toolbars (which are dynamically constructed based on the document type of the current selected XML file).
   * The notifications will be received before the toolbars are constructed after an XML editor which is opened in the Author page was selected.  
   * Such toolbar IDs have the prefix "Author_custom_actions" and the suffix is a number depending on how many toolbars were created for that specific document type.
   * In this way you can dynamically filter or add to toolbar buttons already declared in the document type associated to the XML editor.
   * 
   * @param componentsCustomizer The tool bar components customizer.
   */
  public void addToolbarComponentsCustomizer(ToolbarComponentsCustomizer componentsCustomizer);
  
  /**
   * Adds a customizer which can contribute to or modify existing views or contribute to the reserved custom view.
   * <br>
   * <b>IMPORTANT</b> This customizer must be set early, when the plugin extension's <b>applicationStarted</b> method gets called.
   * 
   * @param viewComponentCustomizer The views component customizer.
   */
  public void addViewComponentCustomizer(ViewComponentCustomizer viewComponentCustomizer);
  
  /**
   * Adds a customizer which can contribute to or modify existing menu components.
   * <br>
   * <b>IMPORTANT</b> This customizer must be set early, when the plugin extension's <b>applicationStarted</b> method gets called.
   * 
   * @param menuBarCustomizer The menu bar components customizer.
   */
  public void addMenuBarCustomizer(MenuBarCustomizer menuBarCustomizer);
  
  /**
   * Add a target information provider to the DITA Maps Manager view.
   * This method can be used by a CMS implementor to take control over the way Oxygen is gathering information about each topic reference.
   * The protocol is the protocol of the URL of the opened DITA Map.
   * 
   * For example when a DITA Map is opened in the DITA Maps Manager view the CMS can get called to compute titles for all topic references 
   * instead of the default Oxygen behavior (requesting the entire content for the referenced URL).
   * @param protocol The custom protocol of the opened DITA Map for which the plugin will compute the topic reference titles and auxiliary information.
   * @param targetInfoProvider Gets called to resolve the title for the topic references in the DITA Map.
   * 
   * @since 12.2
   */
  public void addTopicRefTargetInfoProvider(String protocol, TopicRefTargetInfoProvider targetInfoProvider);
  
  /**
   * Show a view specified by the view ID. If the view is hidden, this method brings it to front. 
   * @param viewID The view ID.
   * @param requestFocus True to request the focus inside the view after show.
   * 
   * @since 12
   */
  public void showView(String viewID, boolean requestFocus);
  
  /**
   * Show a toolbar specified by the toolbar ID.  If the toolbar is hidden, this method shows it.
   * 
   * @param toolbarID The toolbar ID. You can install a toolbar component customizer and see all available IDs.
   * 
   * @since 12
   */
  public void showToolbar(String toolbarID);
  
  /**
   * Get an unique ID (which does not depend on the action name) for an action Oxygen has mounted on the main JMenuBar or on the toolbars.
   * If the action appears on a contextual menu but is not installed on a main menu it will pe prefixed with the constant "ACTION_WITH_NO_SHORTCUT/"
   * 
   * @param action The action for which to retrieve the ID.
   * @return The unique ID or <code>null</code> if the action is not one provided by Oxygen. 
   * 
   * 
   * @since 12.2
   */
  public String getOxygenActionID(Action action);
  
  /**
   * Set a fixed key for licensing the MathFlow editor dialog used to edit embedded MathML equations.
   * @param fixedKey  The fixed key. The key needs to be obtained from MathFlow:
   * 
   * http://dessci.com/
   * 
   * and has the following format:
   * 
   * MFSCKKK-KKKKKK-KKKKK
   * 
   * If no editor key will be given then MathFlow will be used neither for editing nor for rendering.
   * 
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p> 
   */
  public void setMathFlowFixedLicenseKeyForEditor(String fixedKey);
  
  /**
   * Set a fixed key for licensing the MathFlow composer used to view embedded MathML equations.
   * @param fixedKey  The fixed key. The key needs to be obtained from MathFlow:
   * 
   * http://dessci.com/
   * 
   * and has the following format:
   * 
   * MFSEKKK-KKKKKK-KKKKK
   * 
   * If no composer key will be given then the fallback for rendering will be the Apache JEuclid library.
   * 
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p> 
   */
  public void setMathFlowFixedLicenseKeyForComposer(String fixedKey);
}
