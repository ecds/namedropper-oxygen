/**
 * Simple components which can be extended by the customizer in order
 * to make new buttons/dialogs look like the ones in the application.
 */
package ro.sync.exml.workspace.api.standalone.ui;