/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone.ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.EXMLResourceBoundle;
import ro.sync.exml.MessageBundle;
import ro.sync.exml.Tags;
import ro.sync.ui.application.OkCancelAndOtherDialogConstants;
import ro.sync.util.PlatformDetector;

/** 
 * Dialog with OK and Cancel buttons.
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class OKCancelDialog extends JDialog {

  /**
   * Dialog was canceled.  
   */
  public static final int RESULT_CANCEL = 0;

  /**
   * 'Ok' button was pressed.  
   */
  public static final int RESULT_OK = 1;

  /**
   * The result of the dialog. 
   * If 'Ok' was pressed the dialog data can be questioned, 
   * otherwise does not matter.
   */
  private int result = RESULT_CANCEL;

  /**
   *  The ok button.
   */
  private JButton okButton = new JButton();

  /**
   *  The cancel button.
   */
  private JButton cancelButton = new JButton();
  
  /**
   * The content panel
   */
  private JPanel contentPanel = new JPanel(new BorderLayout());
  
  /**
   * Default buttons size.
   */
  private Dimension buttonsSize = new Dimension(PlatformDetector.isMacOS() ? 80 : 75, PlatformDetector.isMacOS() ? 26 : 23);
  
  /** 
   * The messages resource bundle. 
   */
  protected static final MessageBundle messages = EXMLResourceBoundle.getResourceBundleInstance();

  /**
   * Constructor.
   *
   * @param parentFrame The parent frame.
   * @param title       The dialog title.
   * @param modal       <code>true</code> if modal.
   */
  public OKCancelDialog(JFrame parentFrame, String title, boolean modal) {
    this((Frame) parentFrame, title, modal);
  }

  /**
   * Constructor.
   * 
   * @param parentFrame The parent frame.
   * @param title       The dialog title.
   * @param modal       <code>true</code> if modal.
   */
  public OKCancelDialog(Frame parentFrame, String title, boolean modal) {
    super(parentFrame, title, modal);

    //Listener for ENTER pressed
    this.getRootPane().registerKeyboardAction(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        enterKeyPressed();
      }
    }, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

    addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
        if (e.getKeyChar() == '\n') {
          enterKeyPressed();
        }
      }
    });
    //For tests
    okButton.setName("Ok button");
    setOkButtonText(messages.getString(Tags.OK));
    //The OK button
    getRootPane().setDefaultButton(okButton);
    
    //Listener for ESC pressed
    AbstractAction cancelAction = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        if(cancelButton.isEnabled()) {
          doCancel();
        }
      }
    };
    getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
        KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), cancelAction);
    getRootPane().getActionMap().put(cancelAction, cancelAction);

    int bw = PlatformDetector.isMacOS() ? OkCancelAndOtherDialogConstants.DLG_MARGIN_GAP_MAC : OkCancelAndOtherDialogConstants.DLG_MARGIN_GAP_WIN;

    JPanel mainPanel = new JPanel(new GridBagLayout());
    mainPanel.setBorder(BorderFactory.createEmptyBorder(bw, bw, bw, bw));
    GridBagConstraints gridBagConstr = new GridBagConstraints();
    gridBagConstr.gridx = 0;
    gridBagConstr.gridy = 0;
    gridBagConstr.fill = GridBagConstraints.BOTH;
    gridBagConstr.weightx = 1;
    gridBagConstr.weighty = 1;
    gridBagConstr.anchor = GridBagConstraints.WEST;
    gridBagConstr.gridwidth = 2;
    mainPanel.add(contentPanel, gridBagConstr);

    // Control buttons panel
    JPanel controlButtonsPanel = new JPanel();
    controlButtonsPanel.setLayout(new BoxLayout(controlButtonsPanel, BoxLayout.X_AXIS));
    okButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doOK();
      }
    });
    setCancelButtonText(messages.getString(Tags.CANCEL));
    cancelButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doCancel();
      }
    });
    
    controlButtonsPanel.add(Box.createHorizontalGlue());
    if (PlatformDetector.isMacOS()) {
      controlButtonsPanel.add(cancelButton);
      controlButtonsPanel.add(Box.createHorizontalStrut(OkCancelAndOtherDialogConstants.HGAP_MAC));
      controlButtonsPanel.add(okButton);
    } else {
      controlButtonsPanel.add(okButton);
      controlButtonsPanel.add(Box.createHorizontalStrut(OkCancelAndOtherDialogConstants.HGAP_WIN));
      controlButtonsPanel.add(cancelButton);
    }

    gridBagConstr.gridx = 0;
    gridBagConstr.gridy++;
    gridBagConstr.gridwidth = 2;
    gridBagConstr.weightx = 1;
    gridBagConstr.weighty = 0;
    gridBagConstr.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstr.insets = new Insets(5, 0, 0, 0);
    mainPanel.add(controlButtonsPanel, gridBagConstr);

    setContentPane(mainPanel);

    pack();
    setResizable(false);
  }

  /**
   * OK pressed.
   */
  protected void doOK() {
    result = RESULT_OK;
    setVisible(false);
  }
  
  /**
   * Enter key pressed. If ok button is enabled call doOk method.<p>
   * Subclasses can overwrite this method to make default action.
   */
  protected void enterKeyPressed() {
    // EXM-19851, EXM-19861 Do ok action only if ok button is present and enabled.
    if (okButton.isEnabled() && okButton.isVisible() && okButton.getParent() != null) {
      doOK();
    }
  }

  /**
   * Cancel pressed.
   */
  protected void doCancel() {
    result = RESULT_CANCEL;
    setVisible(false);
  }

  /**
   * Gets the result of the the dialog. Used after show.
   *
   * @return The result value.
   */
  public int getResult() {
    return result;
  }

  /**
   *  Sets the text on the ok button.
   *
   *@param  text  The text value.
   */
  public void setOkButtonText(String text) {
    setButtonText(okButton, text);
  }

  /**
   *  Sets the text on the cancel button.
   *
   *@param  text  The text value.
   */
  public void setCancelButtonText(String text) {
    setButtonText(cancelButton, text);
  }
  
  /**
   * @see javax.swing.JDialog#getContentPane()
   */
  @Override
  public Container getContentPane() {
    return contentPanel;
  }
  
  /**
   * Sets the text for a button.
   * If possible it imposes a preferred size.
   * 
   * @param button The button to set text for.
   * @param text The button text.
   */
  private void setButtonText(JButton button, String text) {
    if (text != null && text.length() > 0) {
      int textWidth = button.getFontMetrics(button.getFont()).stringWidth(text);
      int textHeight = button.getFontMetrics(button.getFont()).getHeight();
      int allocW = buttonsSize.width - button.getMargin().left - button.getMargin().right;
      int allocH = buttonsSize.height - button.getMargin().top - button.getMargin().bottom;
      if (PlatformDetector.isMacOS()) {
        allocW -= 15;
        allocH -= 4;
      }
      if (textWidth <= allocW - 4 && textHeight <= allocH) {
        button.setPreferredSize(buttonsSize);
      } else {
        button.setPreferredSize(null);
      }
      button.setText(text);
    }
  }
  
  /**
   * @return Returns the okButton.
   */
  public JButton getOkButton() {
    return okButton;
  }
  
  /**
   * @return Returns the cancelButton.
   */
  public JButton getCancelButton() {
    return cancelButton;
  }
  
  /**
   * Test main method
   * 
   * @param args
   * @throws Exception
   */
  public static void main(String[] args) throws Exception {
    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    OKCancelDialog dialog = new OKCancelDialog(null, "Titlu", false);
    dialog.setSize(400, 150);
    JLabel label = new JLabel("Ok Cancel Dialog");
    dialog.getContentPane().add(label, BorderLayout.CENTER);
    dialog.setDefaultCloseOperation(OKCancelDialog.EXIT_ON_CLOSE);
    dialog.setVisible(true);
  }
}
