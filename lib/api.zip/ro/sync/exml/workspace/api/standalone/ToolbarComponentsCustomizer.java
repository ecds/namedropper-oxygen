/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.MainFrameComponentsConstants;

/**
 * Customizes components for the toolbar
 * 
 * @since 11.2 
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public interface ToolbarComponentsCustomizer {
  
  /**
   * The reserved plugins toolbar ID
   * 
   * @deprecated Since Oxygen 12.2 toolbar IDs are defined in the "plugin.xml".
   */
  @Deprecated
  String CUSTOM = MainFrameComponentsConstants.TOOLBAR_CUSTOM;
  
  /**
   * Customize the components which get displayed on a certain toolbar.
   * <br>
   * <b>NOTICE</b> You will also receive notification for the Author extension toolbars (which are dynamically constructed based on the document type of the current selected XML file).
   * The notifications will be received before the toolbars are constructed after an XML editor which is opened in the Author page was selected.  
   * Such toolbar IDs have the prefix "Author_custom_actions" and the suffix is a number depending on how many toolbars were created for that specific document type.
   * In this way you can dynamically filter or add to toolbar buttons already declared in the document type associated to the XML editor.
   * <br>
   * <b>NOTICE</b> Notifications will arrive for the Dita Map Manager toolbars too. These toolbars have the IDs:
   * <ul>
   *  <li>{@link ro.sync.exml.MainFrameComponentsConstants#TOOLBAR_DITA_MAP_GLOBAL}</li>
   *  <li>{@link ro.sync.exml.MainFrameComponentsConstants#TOOLBAR_DITA_MAP_EXTEND}</li>
   *  <li>{@link ro.sync.exml.MainFrameComponentsConstants#TOOLBAR_DITA_MAP_CUSTOM}</li>
   * </ul>
   * 
   * @param toolbarInfo Information about the toolbar (id, default components to add, title).
   * The toolbar ID is either the ID of an existing Oxygen toolbar or the reserved <b>CUSTOM</b> toolbar.
   * All Oxygen toolbars IDs are found in {@link ro.sync.exml.MainFrameComponentsConstants} and begin with TOOLBAR_ prefix. 
   * 
   * You can set new components in the toolbar and change its title.
   */
  public void customizeToolbar(ToolbarInfo toolbarInfo);
}
