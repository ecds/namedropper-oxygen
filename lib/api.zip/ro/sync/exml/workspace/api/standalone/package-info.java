/**
 * Customizers which can be set by implementing a WorkspaceAccess-type plugin.
 */
package ro.sync.exml.workspace.api.standalone;