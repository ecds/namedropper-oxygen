/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone;

import javax.swing.Icon;
import javax.swing.JComponent;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;

/**
 * Information about a view.
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public class ViewInfo {

  /**
   * The ID of the view
   */
  private String viewID;
  
  /**
   * The component which will get added
   */
  private JComponent component;
  
  /**
   * The title of the toolbar
   */
  private String title;
  
  /**
   * The view icon
   */
  private Icon icon;
  
  /**
   * <code>true</code> if the view info has been customized.
   */
  private boolean isCustomized;
  
  /**
   * Constructor
   * 
   * @param viewID The unique view ID
   * @param component The component which will be placed inside
   * @param title Title for the view
   * @param icon The view's icon
   */
  public ViewInfo(String viewID, JComponent component, String title, Icon icon) {
    this.viewID = viewID;
    this.component = component;
    this.title = title;
    this.icon = icon;
    this.isCustomized = false;
  }
  
  /**
   * Gets the ID of the view.
   * 
   * @return The ID of the view.
   */
  public String getViewID() {
    return viewID;
  }
  
  /**
   * Get the current component this view will display
   * 
   * @return Returns the component.
   */
  public JComponent getComponent() {
    return component;
  }
  
  /**
   * Get the view title
   * 
   * @return Returns the title.
   */
  public String getTitle() {
    return title;
  }
  
  /**
   * Set a new component to be displayed in the view
   * 
   * @param component The component to set.
   */
  public void setComponent(JComponent component) {
    this.component = component;
    this.isCustomized = true;
  }
  
  /**
   * Set a new view title.
   * 
   * @param title The title to set.
   */
  public void setTitle(String title) {
    this.title = title;
    this.isCustomized = true;
  }
  
  /**
   * Get the current view icon
   * 
   * @return Returns the icon.
   */
  public Icon getIcon() {
    return icon;
  }
  
  /**
   * Set the current view icon
   * 
   * @param icon The icon to set.
   */
  public void setIcon(Icon icon) {
    this.icon = icon;
    this.isCustomized = true;
  }
  
  /**
   * Check if the view information has been customized.
   * 
   * @return <code>true</code> if the view information has been customized.
   */
  public boolean isCustomized() {
    return isCustomized;
  }
}