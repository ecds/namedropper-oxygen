/**
 * Provide custom resolve capabilities for the topic
 * titles and other information displayed in the DITA Maps Manager
 */
package ro.sync.exml.workspace.api.standalone.ditamap;