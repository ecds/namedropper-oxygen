/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2011 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.node.customizer;

import java.net.URL;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.util.editorvars.EditorVariables;


/**
 * The rendering information used to display a node in the Outline view, Author bread crumb, 
 * Content Completion popup window, Elements view and DITA Map view. 
 * 
 * @author Iulian Velea
 * @author Alina Iordache
 * 
 * @since 13.2
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
public class BasicRenderingInformation {
  /**
   * The rendered text, usually the node name.
   * If <code>null</code> the default text value will be used for rendering.
   */
  private String renderedText;
  /**
   * The tooltip text which will appear in the tooltip associated with the node.
   */
  private String tooltipText;
  /**
   * The path of the icon used to render the node.
   */
  private String iconPath;
  
  /**
   * Set the text to be rendered for a node. 
   * If the rendered text is <code>null</code> then the default node rendering will be used.
   * 
   * @param renderedText The rendered text, usually the node name. If <code>null</code> the default text will be used for rendering.
   */
  public void setRenderedText(String renderedText) {
    this.renderedText = renderedText;
  }
  
  /**
   * The tooltip text which will appear in the tooltip associated with the node.
   * If the tooltip text is <code>null</code> then the default tooltip text will be used for the node.
   * 
   * @param tooltipText The tooltip text which will appear in the tooltip associated with the node.
   * If <code>null</code> the default tooltip text will be used for the node.
   */
  public void setTooltipText(String tooltipText) {
    this.tooltipText = tooltipText;
  }
  
  /**
   * Set the path of the icon used to render a node. 
   * The path can be an icon file path, the string representation of an icon {@link URL} 
   * or can contain editor variables as defined in the {@link EditorVariables} class.
   * The editor variables will be expanded at runtime.
   * If the icon path is <code>null</code> the default icon will be used for the node.
   * <br/><br/>
   * If the custom used images are located in the same <b>jar</b> file as the {@link XMLNodeRendererCustomizer}
   * then you can use as the return value for this function the following code sequence:
   * <br/><br/>
   * <code>
   * this.getClass().getResource("/images/Icon.gif").toExternalForm();
   * </code>
   * <br/><br/>
   * The previous sequence assumes that <em>Icon.gif</em> icon image is located in the <em>images</em> folder inside
   * your <b>jar</b> file.  
   * 
   * @param iconPath The path of the icon. If <code>null</code> the default icon will be used for the node.
   */
  public void setIconPath(String iconPath) {
    this.iconPath = iconPath;
  }
  
  /**
   * Get the text to be rendered for a node.
   * 
   * @return Returns the rendered text.
   */
  public String getRenderedText() {
    return renderedText;
  }
  
  /**
   * The tooltip text which will appear in the tooltip associated with the node.
   * 
   * @return the tooltip text which will appear in the tooltip associated with the node.
   */
  public String getTooltipText() {
    return tooltipText;
  }
  
  /**
   * Get the path of the icon used to render a node.
   * The path can be an icon file path, the string representation of an icon {@link URL} 
   * or can contain editor variables as defined in the {@link EditorVariables} class.
   * The editor variables will be expanded at runtime.
   * 
   * @return Returns the path of the icon.
   */
  public String getIconPath() {
    return iconPath;
  }
}