/**
 * Find information about the license of the current installation.
 */
package ro.sync.exml.workspace.api.license;