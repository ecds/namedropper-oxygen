/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api;

import java.net.URL;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.ditamap.keys.KeyDefinitionManager;
import ro.sync.exml.workspace.api.listeners.WSEditorChangeListener;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.util.UtilAccess;
import ro.sync.exml.workspace.api.util.XMLUtilAccess;

/**
 * Access the entire workspace of Oxygen.
 * 
 * @since 11.2 
 */
@API(type=APIType.NOT_EXTENDABLE, src=SourceType.PUBLIC)
public interface PluginWorkspace extends Workspace {
  
  /**
   * The main editing area in Oxygen
   */
  public static final int MAIN_EDITING_AREA = 0;
  /**
   * The DITA Maps editing area
   */
  public static final int DITA_MAPS_EDITING_AREA = 1;

  /**
   * Get all the editor locations.
   * 
   * @param editingArea One of the constants in this class:
   * <br>
   * {@link #MAIN_EDITING_AREA} - for the editors in the main Oxygen workspace area.
   * <br>
   * {@link #DITA_MAPS_EDITING_AREA} - for the editors in the DITA Maps Manager view workspace area.
   * <br>
   * @return All the editor locations or empty array if no editor is opened
   */
  URL[] getAllEditorLocations(int editingArea);
  
  /**
   * Find an editor access by location
   * 
   * @param location The editor location
   * @param editingArea One of the constants in this class:
   * <br>
   * {@link #MAIN_EDITING_AREA} - for the editors in the main Oxygen workspace area.
   * <br>
   * {@link #DITA_MAPS_EDITING_AREA} - for the editors in the DITA Maps Manager view workspace area.
   * <br>
   * @return access to the found editor or <code>null</code> if no editor found with that location URL.
   */
  WSEditor getEditorAccess(URL location, int editingArea);
  
  /**
   * Get access to the current selected editor.
   * 
   * @param editingArea One of the constants in this class:
   * <br>
   * {@link #MAIN_EDITING_AREA} - for the editors in the main Oxygen workspace area.
   * <br>
   * {@link #DITA_MAPS_EDITING_AREA} - for the editors in the DITA Maps Manager view workspace area.
   * <br>
   * @return access to the current editor or <code>null</code> if no editor is opened.
   */
  WSEditor getCurrentEditorAccess(int editingArea);
  
  /**
   * Access to XML utilities.
   * 
   * @return Access to XML utilities.
   */
  XMLUtilAccess getXMLUtilAccess();
  
  /**
   * Get access to utility methods.
   * 
   * @return access to utility methods.
   */
  UtilAccess getUtilAccess();
  
  /**
   * Add listener for editor related events(for example editor opened, closed, page changed).
   * 
   * @param editingArea One of the constants in this class:
   * <br>
   * {@link #MAIN_EDITING_AREA} - for the editors in the main Oxygen workspace area.
   * <br>
   * {@link #DITA_MAPS_EDITING_AREA} - for the editors in the DITA Maps Manager view workspace area.
   * <br>
   * @param editorListener The listener notified when an editor is added, removed or the editor page is changed.
   */
  void addEditorChangeListener(WSEditorChangeListener editorListener, int editingArea);
  
  /**
   * Remove listener for editor related events.
   * 
   * @param editingArea One of the constants in this class:
   * <br>
   * {@link #MAIN_EDITING_AREA} - for the editors in the main Oxygen workspace area.
   * <br>
   * {@link #DITA_MAPS_EDITING_AREA} - for the editors in the DITA Maps Manager view workspace area.
   * <br>
   * @param editorListener The listener notified when an editor is added, removed or the editor page is changed.
   */
  void removeEditorChangeListener(WSEditorChangeListener editorListener, int editingArea);
  
  /**
   * This interface can be used to save and persist in the Oxygen preferences user-defined keys and values. 
   * It is also responsible for adding and removing listeners that are notified
   * about the option changes.
   * These keys are common to all plugin implementations.
   * 
   * @return The object that manages the custom user options stored in the Oxygen preferences from the plugin implementations.
   * 
   * @since 12.1
   */
  WSOptionsStorage getOptionsStorage();
  
  /**
   * By default key definitions are gathered from DITA Maps opened in the DITA Maps Manager.
   * This API can be used by the developer to take control over the key definitions which will be used to resolve keyrefs and conkeyrefs for
   * topics opened in the Author page.
   * @param keyDefitionManager The key definition manager
   * 
   * @since 14
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p> 
  */
  void setDITAKeyDefinitionManager(KeyDefinitionManager keyDefitionManager);
}
