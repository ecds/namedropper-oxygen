/**
 * Persist simple (key,value) String pairs in the application preferences.
 */
package ro.sync.exml.workspace.api.options;