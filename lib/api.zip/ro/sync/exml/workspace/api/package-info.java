/**
 * API for accessing the application workspace.
 */
@SkipObfuscate(classes = SkipLevel.PRIVATE, fields = SkipLevel.PRIVATE, methods = SkipLevel.PRIVATE, recursive = true)
package ro.sync.exml.workspace.api;

import ro.sync.annotations.obfuscate.SkipLevel;
import ro.sync.annotations.obfuscate.SkipObfuscate;
