/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml;

import ro.sync.annotations.api.API;
import ro.sync.annotations.api.APIType;
import ro.sync.annotations.api.SourceType;
import ro.sync.annotations.obfuscate.SkipLevel;
import ro.sync.annotations.obfuscate.SkipObfuscate;
import ro.sync.exml.editor.EditorTemplate;

/**
 * Validator interface for menus, toolbars and their actions.
 * 
 * @author mircea
 * @author alex
 */
@API(type=APIType.EXTENDABLE, src=SourceType.PUBLIC)
@SkipObfuscate(classes = SkipLevel.NOT_SPECIFIED, fields = SkipLevel.NOT_SPECIFIED, methods = SkipLevel.PUBLIC)
public abstract class ComponentsValidator {
  /**
   * Separator for menus and actions.
   */
  public static final String SEP = "/";
  
  /**
   * Check if an menu or a tag action from a menu is allowed.
   * 
   * @param menuOrActionPath The tag of the menu/action and the tags of its parent menus if any. 
   * The last component is the current one. 
   * A menu path is an array of {@link String}s representing the Tags, ending with the 
   * current menu tag, or <code>null</code>.
   *
   * @return <code>true</code> if the action is allowed.
   */
  public abstract boolean validateMenuOrTaggedAction(String[] menuOrActionPath);
  
  /**
   * Check if an action from a toolbar is allowed.
   * 
   * @param toolbarOrAction The tag of the action from a toolbar and the tag of its parent toolbar if any.
   * 
   * @return <code>true</code> if the action is allowed.
   */
  public abstract boolean validateToolbarTaggedAction(String[] toolbarOrAction);
  
  /**
   * Check if the given component is allowed.
   * 
   * @param key Tag identifying the view. Usually one of the constants from MainFrameComponentProvider 
   * 
   * @return <code>true</code> if the view is allowed.
   */
  public abstract boolean validateComponent(String key);
  
  /**
   * Check if the given accel action is allowed. An accel action can be uniquely identified so it
   * doesn't matter if it is from a toolbar or menu.
   * 
   * @param category The category of the action.
   * @param tag The tag of the action.
   * 
   * @return <code>true</code> if the action is allowed.
   */
  public abstract boolean validateAccelAction(String category, String tag);
  
  /**
   * Validate the given content type.
   * 
   * @param contentType The content type. A constant from ContentTypes interface.
   * 
   * @return <code>true</code> if in the current distribution we support the given content type.
   */
  public abstract boolean validateContentType(String contentType);
  
  /**
   * Validate the given option pane.
   * 
   * @param optionPaneKey The option pane key. A constant defined in OptionTags.
   * 
   * @return <code>true</code> if in the current distribution we should add the given option pane 
   * in the option tree.
   */
  public abstract boolean validateOptionPane(String optionPaneKey);
  
  /**
   * Validate the given option.
   * 
   * @param optionKey The option key. A constant defined in OptionTags.
   * 
   * @return <code>true</code> if in the current distribution we should add the given option 
   * in the option page.
   */
  public abstract boolean validateOption(String optionKey);
  
  /**
   * Validate the given library.
   * 
   * @param library The library.
   * 
   * @return <code>true</code> if in the current distribution we should add the given library 
   * in the about dialog.
   */
  public abstract boolean validateLibrary(String library);
  
  /**
   * Validate the given template for a new editor in the current distribution.
   * 
   * @param editorTemplate The editor template.
   * 
   * @return <code>true</code> if it is allowed.
   */
  public abstract boolean validateNewEditorTemplate(EditorTemplate editorTemplate);
  
  /**
   * Check if the debugger perspective is allowed in the current distribution.
   * 
   * @return <code>true</code> if the debugger functionality is allowed.
   */
  public abstract boolean isDebuggerPerspectiveAllowed();
  
  /**
   * Check if this marker is allowed in the current distribution.
   * 
   * @param marker The marker to be checked. A constant from SHMarker class.
   * 
   * @return <code>true</code> if the marker is allowed.
   */
  public abstract boolean validateSHMarker(String marker);
  
  
  /**
   * Get a path from all the tags.
   * 
   * @param path The tags for the action/menu/toolbar and its menu/toolbar ancestors.
   * 
   * @return A path that can be used to identify it.
   */
  public String canonicalize(String[] path) {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < path.length; i++) {
      if (i > 0) {
        buf.append(SEP);
      }
      buf.append(path[i]);
    }
    return buf.toString();
  }
  
  /**
   * Return <code>true</code> if master files support is available or not.
   * 
   * @return Return <code>true</code> if master files support is available or not.
   */
  public boolean isMasterFilesSupportAvailable() {
    return true;
  }
}